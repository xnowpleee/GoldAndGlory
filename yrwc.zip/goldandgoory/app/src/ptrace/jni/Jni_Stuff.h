#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <cstdlib>
#include <ctime>

#include "curl/curl.h"
#include "enc/json.hpp"
#include "Oxorany/oxorany.h"

using json = nlohmann::json;

struct MemoryStruct {
    char* memory;
    size_t size;
};

static size_t WriteMemoryCallback(void* contents, size_t size, size_t nmemb, void* userp) {
    size_t realsize = size * nmemb;
    MemoryStruct* mem = (MemoryStruct*)userp;

    char* ptr = (char*)realloc(mem->memory, mem->size + realsize + 1);
    if (ptr == NULL) return 0;

    mem->memory = ptr;
    memcpy(&(mem->memory[mem->size]), contents, realsize);
    mem->size += realsize;
    mem->memory[mem->size] = 0;

    return realsize;
}

std::string GetHWID() {
    std::ifstream fin(oxorany("/sys/class/android_usb/android0/iSerial"));
    std::string serial;
    getline(fin, serial);
    return serial.empty() ? oxorany("unknown_hw") : serial;
}

std::string validate_key(const std::string& user_key, const std::string& UUID) {
    CURL* curl = curl_easy_init();
    CURLcode res;
    MemoryStruct chunk = { (char*)malloc(1), 0 };
    std::string errMsg = oxorany("Gagal melakukan request.");
    bool bValid = false;

    if (curl) {
        std::string api_url = oxorany("https://starcool.my.id/connect");

        curl_easy_setopt(curl, CURLOPT_URL, api_url.c_str());
        curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
        curl_easy_setopt(curl, CURLOPT_DEFAULT_PROTOCOL, oxorany("https"));

        struct curl_slist* headers = NULL;
        headers = curl_slist_append(headers, oxorany("Content-Type: application/x-www-form-urlencoded"));
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

        std::string postdata = oxorany("game=BS&user_key=") + user_key + oxorany("&serial=") + UUID;
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, postdata.c_str());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteMemoryCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void*)&chunk);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);

        res = curl_easy_perform(curl);

        if (res == CURLE_OK) {
            json result = json::parse(chunk.memory, nullptr, false);  // no-throw
            if (result.is_discarded()) {
                errMsg = oxorany("JSON parse error!");
            } else if (result["status"] == true) {
                time_t rng = result["data"]["rng"].get<time_t>();
                if (rng + 30 > time(0)) {
                    bValid = true;
                } else {
                    errMsg = oxorany("Token expired!");
                }
            } else {
                errMsg = result.value("reason", oxorany("Unknown error"));
            }
        } else {
            errMsg = curl_easy_strerror(res);
        }

        curl_easy_cleanup(curl);
        curl_slist_free_all(headers);
        free(chunk.memory);
    }

    return bValid ? oxorany("OK") : errMsg;
}
