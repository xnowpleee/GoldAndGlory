#pragma once
#include "Oxorany/oxorany.h"
#include "ByNameModding/Tools.h"
JNIEnv *genv;

bool bInitDone;

#define g_LogTag oxorany("Hello-LOGGER")

jboolean (*old_nativeInjectEvent)(JNIEnv *env, jobject m_obj, jobject inputEvent);
jboolean nativeInjectEvent(JNIEnv *env, jobject thiz, jobject inputEvent) {
	
	jclass motionEventClass = env->FindClass(oxorany("android/view/MotionEvent"));
	
	if (env->IsInstanceOf(inputEvent, motionEventClass)) {
		
		jmethodID getX = env->GetMethodID(motionEventClass, oxorany("getRawX"), oxorany("()F"));
		jmethodID getY = env->GetMethodID(motionEventClass, oxorany("getRawY"), oxorany("()F"));
		jmethodID getAction = env->GetMethodID(motionEventClass, oxorany("getAction"), oxorany("()I"));
		
		jfloat x = env->CallFloatMethod(inputEvent, getX);
		jfloat y = env->CallFloatMethod(inputEvent, getY);
		jint action = env->CallIntMethod(inputEvent, getAction);
		
		//ImGuiIO& io = ImGui::GetIO();
		
	return old_nativeInjectEvent(env, thiz, inputEvent);
}
}
jint (*old_RegisterNatives)(JNIEnv* env, jclass klazz, const JNINativeMethod*, jint);
jint hook_RegisterNatives(JNIEnv* env, jclass klazz, const JNINativeMethod* methods, jint methodcount) {
	
	for (int i = 0; i < methodcount; ++i) {
		
		if (strcmp(methods[i].name, oxorany("nativeInjectEvent")) == 0) {
			Tools::Hook((void *) methods[i].fnPtr, (void *) nativeInjectEvent, (void **) &old_nativeInjectEvent);
		}
		
	}
	return old_RegisterNatives(env, klazz, methods, methodcount);
}

std::string getPublicStaticString(JNIEnv *env, const char *className, const char *fieldName) {
    jclass clazz = env->FindClass(className);
    if (clazz != nullptr) {
        jfieldID fid = env->GetStaticFieldID(clazz, fieldName, oxorany("Ljava/lang/String;"));
        if (fid != nullptr) {
            jstring GladioReceiver = (jstring) env->GetStaticObjectField(clazz, fid);
            jboolean blnIsCopy;
            std::string mystr = env->GetStringUTFChars(GladioReceiver, &blnIsCopy);
            return mystr;
        }
    }
    return oxorany("ERROR");
}

std::string CreateDeviceUniqueID(JNIEnv *env) {
    std::string strReturn;
    std::string board = getPublicStaticString(env, oxorany("android/os/Build"), oxorany("BOARD"));
    std::string brand = getPublicStaticString(env, oxorany("android/os/Build"), oxorany("BRAND"));
    std::string display = getPublicStaticString(env, oxorany("android/os/Build"), oxorany("DISPLAY"));
    std::string device = getPublicStaticString(env, oxorany("android/os/Build"), oxorany("DEVICE"));
    std::string manufacturer = getPublicStaticString(env, oxorany("android/os/Build"), oxorany("MANUFACTURER"));
    std::string model = getPublicStaticString(env, oxorany("android/os/Build"), oxorany("MODEL"));
    std::string product = getPublicStaticString(env, oxorany("android/os/Build"), oxorany("PRODUCT"));

    int mod = 10;
    int a1 = ((int) board.size()) % mod;
    int a2 = ((int) brand.size()) % mod;
    int a3 = ((int) display.size()) % mod;
    int a4 = ((int) device.size()) % mod;
    int a5 = ((int) manufacturer.size()) % mod;
    int a6 = ((int) model.size()) % mod;
    int a7 = ((int) product.size()) % mod;

    strReturn = "699" +
            std::to_string(a1) +
            std::to_string(a2) +
            std::to_string(a3) +
            std::to_string(a4) +
            std::to_string(a5) +
            std::to_string(a6) +
            std::to_string(a7);

    return strReturn;
}

