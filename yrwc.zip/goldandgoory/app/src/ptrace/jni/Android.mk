LOCAL_PATH := $(call my-dir)

# =========================
# PREBUILT: libdobby
# =========================
include $(CLEAR_VARS)
LOCAL_MODULE := libdobby
LOCAL_SRC_FILES := Dobby/libraries/$(TARGET_ARCH_ABI)/libdobby.a
include $(PREBUILT_STATIC_LIBRARY)

# =========================
# PREBUILT: libcurl
# =========================
include $(CLEAR_VARS)
LOCAL_MODULE := libcurl
LOCAL_SRC_FILES := curl/curl-android-$(TARGET_ARCH_ABI)/lib/libcurl.a
include $(PREBUILT_STATIC_LIBRARY)

# =========================
# PREBUILT: libssl
# =========================
include $(CLEAR_VARS)
LOCAL_MODULE := libssl
LOCAL_SRC_FILES := curl/openssl-android-$(TARGET_ARCH_ABI)/lib/libssl.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := libcrypto
LOCAL_SRC_FILES := curl/openssl-android-$(TARGET_ARCH_ABI)/lib/libcrypto.a
include $(PREBUILT_STATIC_LIBRARY)

# =========================
# MAIN MODULE
# =========================
include $(CLEAR_VARS)

# =========================
# MAIN MODULE
# =========================
include $(CLEAR_VARS)

LOCAL_MODULE := GNG_VENDORA.sh

LOCAL_CFLAGS := -Wno-error=format-security -fvisibility=hidden -ffunction-sections -fdata-sections -w
LOCAL_CFLAGS += -fno-rtti -fno-exceptions -fpermissive

LOCAL_CPPFLAGS := -Wno-error=format-security -fvisibility=hidden -ffunction-sections -fdata-sections -w -Werror -s
LOCAL_CPPFLAGS += -std=c++17 -fexceptions -fno-rtti -Wno-error=c++11-narrowing -fms-extensions -fpermissive

LOCAL_LDFLAGS += -Wl,--gc-sections,--strip-all
LOCAL_ARM_MODE := arm

LOCAL_C_INCLUDES += $(LOCAL_PATH)/curl/curl-android-$(TARGET_ARCH_ABI)/include
LOCAL_C_INCLUDES += $(LOCAL_PATH)/curl/openssl-android-$(TARGET_ARCH_ABI)/include

LOCAL_SRC_FILES := \
    inject.cpp \
    ByNameModding/Tools.cpp \
    Oxorany/oxorany.cpp

# Link to prebuilt static libraries
LOCAL_STATIC_LIBRARIES := libdobby libcurl libssl libcrypto

# System dynamic libraries
LOCAL_LDLIBS := -llog -lz -landroid

include $(BUILD_EXECUTABLE)
