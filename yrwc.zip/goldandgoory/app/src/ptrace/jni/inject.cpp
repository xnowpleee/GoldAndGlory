
//CREATED BY @EXSTARCOOL//


#include <cstdio>
#include <cstdlib>
#include <unistd.h>
#include <string>
#include <sys/stat.h>
#include <iostream>
#include "inject.h"     
#include "arm64-v8a.h"   
#include "Jni_Stuff.h"  
#include "Oxorany/oxorany.h" 

extern std::string validate_key(const std::string& user_key, const std::string& hwid);

void dump_file(const char* path, const unsigned char* data, size_t len) {
    FILE* fp = fopen(path, "wb");
    if (!fp) {
        perror(oxorany("fopen"));
        return;
    }
    fwrite(data, 1, len, fp);
    fclose(fp);
    chmod(path, 0755); 
}


#include <iostream>
#include <string>
#include <unistd.h> 
#include <cstdlib>


void type_effect(const std::string& text, int delay_us = 40000) {
    for (char c : text) {
        std::cout << c << std::flush;
        usleep(delay_us);
    }
}


void banner_star() {
    const char* cyan = "\033[36m";
    const char* yellow = "\033[33m";
    const char* reset = "\033[0m";

    std::cout << yellow;
    type_effect("             BY VENDORA \n\n", 20000);
    std::cout << reset;
}
	
	int main() {
    const char* blue = "\033[34m";
    const char* reset = "\033[0m";


    banner_star();

    std::cout << blue << "Join Telegram: \033[36mhttps://t.me/VHL_GROUP\033[0m\n\n";



    std::cout << "\033[32m[+] Ready!\033[0m\n";
    /*
	std::string key;
    std::cout << oxorany("ENTER KEY: ");
    std::getline(std::cin, key);

    std::string hwid = GetHWID();
    std::string result = validate_key(key, hwid);

    if (result != oxorany("OK")) {
        std::cout << oxorany("[-] ERROR: ") << result << std::endl;
        return 1;
    }

    std::cout << oxorany("[+] Key valid.\n");
	*/
	
    static std::string inject_path_str = oxorany("/data/local/tmp/inject"); //path
    static std::string lib_path_str    = oxorany("/data/local/tmp/STAR.so"); //path

    std::string pkg_name_str = "com.dois.greedgame"; //target game

    // std::cout << oxorany("[+] Login: ") << pkg_name_str << "\n";

    const char* inject_path = inject_path_str.c_str();
    const char* lib_path    = lib_path_str.c_str();
    const char* pkg_name    = pkg_name_str.c_str();

    dump_file(inject_path, inject, inject_len);
    dump_file(lib_path, LIBVendora_so, LIBVendora_so_len);

    std::string cmd = std::string(inject_path) + " -f -n " + pkg_name + " -so " + lib_path + " > /dev/null 2>&1";

    int status = system(cmd.c_str());
    if (status == 0) {
        std::cout << oxorany("[+]  SUCCES.\n");
        unlink(inject_path);
        unlink(lib_path);
    } else {
        std::cout << oxorany("[-] FAILED.\n");
        unlink(inject_path);
        unlink(lib_path);
    }

    return 0;
}
