LOCAL_PATH := $(call my-dir)
MAIN_LOCAL_PATH := $(call my-dir)
include $(CLEAR_VARS)
LOCAL_MODULE := shadowhook
LOCAL_SRC_FILES := Vendora/Tools/shadowhook/libshadowhook.a
LOCAL_EXPORT_C_INCLUDES := $(LOCAL_PATH)/Vendora/Tools/shadowhook/
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE            := libdobby
LOCAL_SRC_FILES         := Vendora/Tools/Dobby/libraries/$(TARGET_ARCH_ABI)/libdobby.a
LOCAL_EXPORT_C_INCLUDES := $(LOCAL_PATH)/Vendora/Tools/Dobby/
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := keystone
LOCAL_SRC_FILES         := Vendora/Tools/Dobby/libraries/$(TARGET_ARCH_ABI)/libkeystone.a
include $(PREBUILT_STATIC_LIBRARY)
# ============================================================================#

include $(CLEAR_VARS)
LOCAL_MODULE_FILENAME := $(TARGET_ARCH_ABI) 
LOCAL_MODULE := $(TARGET_ARCH_ABI)

LOCAL_CFLAGS := -Wno-error=format-security -fvisibility=hidden -ffunction-sections -fdata-sections -w
LOCAL_CFLAGS += -fno-rtti -fno-exceptions -fpermissive
LOCAL_CFLAGS += -DAY_OBFUSCATE_DEFAULT_KEY=$(OBFUSCATE_KEY)
LOCAL_CPPFLAGS := -Wno-error=format-security -fvisibility=hidden -ffunction-sections -fdata-sections -w -Werror -s -std=c++17
LOCAL_CPPFLAGS += -Wno-error=c++11-narrowing -fms-extensions -fno-rtti -fno-exceptions -fpermissive
LOCAL_LDFLAGS += -Wl,--gc-sections,--strip-all, -llog
LOCAL_STRIP_MODULE := true
LOCAL_LDFLAGS += -Wl,--no-undefined
ifeq ($(TARGET_ARCH_ABI),armeabi-v7a)
  LOCAL_ARM_MODE := arm
endif
LOCAL_LDLIBS           := -llog -landroid -lEGL -lGLESv3 -lGLESv2 -lGLESv1_CM -lz

LOCAL_C_INCLUDES       += $(LOCAL_PATH)
LOCAL_C_INCLUDES       += $(LOCAL_PATH)/ImGui
LOCAL_C_INCLUDES       += $(LOCAL_PATH)/ImGui/backends
LOCAL_C_INCLUDES       += $(LOCAL_PATH)/Vendora
LOCAL_C_INCLUDES       += $(LOCAL_PATH)/KittyMemory
LOCAL_C_INCLUDES       += $(LOCAL_PATH)/KittyMemory/Keystone
LOCAL_C_INCLUDES       += $(LOCAL_PATH)/Vendora/Tools/curl/openssl-android-$(TARGET_ARCH_ABI)/include
FILE_LIST               += $(wildcard $(LOCAL_PATH)/xdl/*.c*)
LOCAL_SRC_FILES        := $(FILE_LIST:$(LOCAL_PATH)/%=%)


LOCAL_SRC_FILES := $(FILE_LIST:$(LOCAL_PATH)/%=%) \
    Includes/oxorany.cpp \
    Main.cpp \
    ImGui/imgui.cpp \
    ImGui/imgui_draw.cpp \
    ImGui/imgui_tables.cpp \
    ImGui/imgui_widgets.cpp \
    ImGui/imgui_stdlib.cpp \
    ImGui/backends/imgui_impl_opengl3.cpp \
    ImGui/backends/imgui_impl_android.cpp \
	Substrate/hde64.c \
	Substrate/SubstrateDebug.cpp \
	Substrate/SubstrateHook.cpp \
	Substrate/SubstratePosixMemory.cpp \
	Substrate/SymbolFinder.cpp \
    KittyMemory/KittyMemory.cpp \
    KittyMemory/MemoryPatch.cpp \
    KittyMemory/MemoryBackup.cpp \
    KittyMemory/KittyUtils.cpp \
    KittyMemory/KittyScanner.cpp \
    KittyMemory/KittyArm64.cpp \
    And64InlineHook/And64InlineHook.cpp \
    Vendora/IL2CppSDKGenerator/fake_dlfcn.cpp \
    Vendora/IL2CppSDKGenerator/Il2Cpp.cpp \
    Vendora/Tools/MonoString.cpp \
    Vendora/Tools/Tools.cpp \
    Vendora/Dump/Il2Cpp/il2cpp_dump.cpp \
     
LOCAL_STATIC_LIBRARIES					:= libdobby libshadowhook keystone
LOCAL_CPP_FEATURES     := exceptions

include $(BUILD_SHARED_LIBRARY)
# ============================================================================

