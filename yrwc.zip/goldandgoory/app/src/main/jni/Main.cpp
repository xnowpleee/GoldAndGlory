#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include "xdl.h"
#include <KittyMemory/KittyMemory.hpp>
#include <KittyMemory/MemoryPatch.hpp>
#include <KittyMemory/KittyScanner.hpp>
#include <KittyMemory/KittyUtils.hpp>
#include "Includes/obfuscate.h"

#include "Includes/Logger.h"

#include "Includes/JNIStuff.h"
#include "Includes/Utils.h"

#include "Vendora/Call_Me.h"
#include "shadowhook.h"
#include "ImGui/Toggle.h"
#include "ImGui/Comic_Sans.h"
#include "monster.h"
#include "style.h"
#include "OpenGL.h"
#include "STARCOOL.h"
#include "TSS.h"
#define RealLibToLoad "librealmain.so"
#include <thread>
#include <dlfcn.h>
#include <pthread.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <cstdlib>
#include <ctime>

#include "Hook.h"
//=========!!!==========
// Main.cpp (potongan lengkap yang sudah diperbaiki)
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>
#include <map>
#include <mutex>
#include <algorithm>
#include <random>
#include <atomic>
#include <cstring>
#include <dlfcn.h>
#include <android/log.h>
#include <cinttypes>

// socket & networking
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>      // addrinfo

// lokal
#include "KittyMemory/KittyMemory.hpp"
#include "TSS.h"  

#define LOG_TAG "vendora_tss"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

JavaVM* vm = nullptr;
JNIEnv* env = nullptr;

jobject getJNIContext(JNIEnv *env) {
    jclass activityThreadCls = env->FindClass(OBFUSCATE("android/app/ActivityThread"));
    jmethodID currentActivityThread = env->GetStaticMethodID(activityThreadCls, OBFUSCATE("currentActivityThread"), OBFUSCATE("()Landroid/app/ActivityThread;"));
    jobject activityThreadObj = env->CallStaticObjectMethod(activityThreadCls, currentActivityThread);
    jmethodID getApplication = env->GetMethodID(activityThreadCls, OBFUSCATE("getApplication"), OBFUSCATE("()Landroid/app/Application;"));
    jobject context = env->CallObjectMethod(activityThreadObj, getApplication);
    return context;
}

inline jint ShowSoftKeyboardInput(JavaVM *vm, bool open) {
    JNIEnv *env;
    vm->AttachCurrentThread(&env, nullptr);
    if (env == nullptr) return -1;
	
    jclass looperClass = env->FindClass(OBFUSCATE("android/os/Looper"));
    auto prepareMethod = env->GetStaticMethodID(looperClass, OBFUSCATE("prepare"), OBFUSCATE("()V"));
    env->CallStaticVoidMethod(looperClass, prepareMethod);

    jclass activityThreadClass = env->FindClass(OBFUSCATE("android/app/ActivityThread"));
    jfieldID sCurrentActivityThreadField = env->GetStaticFieldID(activityThreadClass, OBFUSCATE("sCurrentActivityThread"), OBFUSCATE("Landroid/app/ActivityThread;"));
    jobject sCurrentActivityThread = env->GetStaticObjectField(activityThreadClass, sCurrentActivityThreadField);

    jfieldID mInitialApplicationField = env->GetFieldID(activityThreadClass, OBFUSCATE("mInitialApplication"), OBFUSCATE("Landroid/app/Application;"));
    jobject mInitialApplication = env->GetObjectField(sCurrentActivityThread, mInitialApplicationField);

    jclass contextClass = env->FindClass(OBFUSCATE("android/content/Context"));
    jfieldID fieldINPUT_METHOD_SERVICE = env->GetStaticFieldID(contextClass, OBFUSCATE("INPUT_METHOD_SERVICE"), OBFUSCATE("Ljava/lang/String;"));
    jobject INPUT_METHOD_SERVICE = env->GetStaticObjectField(contextClass, fieldINPUT_METHOD_SERVICE);
    jmethodID getSystemServiceMethod = env->GetMethodID(contextClass, OBFUSCATE("getSystemService"), OBFUSCATE("(Ljava/lang/String;)Ljava/lang/Object;"));
    jobject callObjectMethod = env->CallObjectMethod(mInitialApplication, getSystemServiceMethod, INPUT_METHOD_SERVICE);

    jclass classInputMethodManager = env->FindClass(OBFUSCATE("android/view/inputmethod/InputMethodManager"));
    jmethodID toggleSoftInputId = env->GetMethodID(classInputMethodManager, OBFUSCATE("toggleSoftInput"), OBFUSCATE("(II)V"));

    if (open) {
        env->CallVoidMethod(callObjectMethod, toggleSoftInputId, 2, 0);
    } else {
        env->CallVoidMethod(callObjectMethod, toggleSoftInputId, 0, 0);
    }

    env->DeleteLocalRef(classInputMethodManager);
    env->DeleteLocalRef(callObjectMethod);
    env->DeleteLocalRef(contextClass);
    env->DeleteLocalRef(mInitialApplication);
    env->DeleteLocalRef(activityThreadClass);
    vm->DetachCurrentThread();

    return 0;
}

std::string getClipboardText(JavaVM *vm) {
    std::string result;
    JNIEnv *env;
    vm->AttachCurrentThread(&env, 0);
    {
        auto looperClass = env->FindClass(OBFUSCATE("android/os/Looper"));
        auto prepareMethodID = env->GetStaticMethodID(looperClass, OBFUSCATE("prepare"), OBFUSCATE("()V"));
        env->CallStaticVoidMethod(looperClass, prepareMethodID);
        auto object = getJNIContext(env);
        auto ContextClass = env->FindClass(OBFUSCATE("android/content/Context"));
        auto getSystemServiceMethod = env->GetMethodID(ContextClass, OBFUSCATE("getSystemService"), OBFUSCATE("(Ljava/lang/String;)Ljava/lang/Object;"));
        auto str = env->NewStringUTF(OBFUSCATE("clipboard"));
        auto clipboardManager = env->CallObjectMethod(object, getSystemServiceMethod, str);
        env->DeleteLocalRef(str);
        auto ClipboardManagerClass = env->FindClass(OBFUSCATE("android/content/ClipboardManager"));
        auto getText = env->GetMethodID(ClipboardManagerClass, OBFUSCATE("getText"), OBFUSCATE("()Ljava/lang/CharSequence;"));
        auto CharSequenceClass = env->FindClass(OBFUSCATE("java/lang/CharSequence"));
        auto toStringMethod = env->GetMethodID(CharSequenceClass, OBFUSCATE("toString"), OBFUSCATE("()Ljava/lang/String;"));
        auto text = env->CallObjectMethod(clipboardManager, getText);
        if (text) {
            str = (jstring)env->CallObjectMethod(text, toStringMethod);
            result = env->GetStringUTFChars(str, 0);
            env->DeleteLocalRef(str);
            env->DeleteLocalRef(text);
        }
        env->DeleteLocalRef(CharSequenceClass);
        env->DeleteLocalRef(ClipboardManagerClass);
        env->DeleteLocalRef(clipboardManager);
        env->DeleteLocalRef(ContextClass);
    }
    vm->DetachCurrentThread();

    return result;
}

int as = 0;

uintptr_t address = 0;
uintptr_t touuu;
uintptr_t tto;
struct UnityEngine_Vector2_Fields {
    float x;
    float y;
};

struct UnityEngine_Vector2_o {
    UnityEngine_Vector2_Fields fields;
};


enum TouchPhase : int {
    Began = 0,
    Moved = 1,
    Stationary = 2,
    Ended = 3,
    Canceled = 4,
};



struct UnityEngine_Touch_Fields {
    int32_t m_FingerId;
    Vector2 m_Position;
    Vector2 m_RawPosition;
    Vector2 m_PositionDelta;
    float m_TimeDelta;
    int32_t m_TapCount;
    int32_t m_Phase;
    int32_t m_Type;
    float m_Pressure;
    float m_maximumPossiblePressure;
    float m_Radius;
    float m_RadiusVariance;
    float m_AltitudeAngle;
    float m_AzimuthAngle;
};
#define Input_GetTouch        (uintptr_t) Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.InputLegacyModule.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Input"), OBFUSCATE("GetTouch"), 1)
#define Input_get_touchCount  (uintptr_t) Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.InputLegacyModule.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Input"), OBFUSCATE("get_touchCount"), 0)
#define Input_get_mousePosition (uintptr_t) Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.InputLegacyModule.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Input"), OBFUSCATE("get_mousePosition"), 0)
static int (*orig_get_touchCount)(void* instance);
static Vector2 (*orig_get_mousePosition)(void* instance);
static UnityEngine_Touch_Fields (*orig_GetTouch)(void* instance, int index);

int my_get_touchCount(void* instance) {
    return orig_get_touchCount(instance);
}
Vector2 my_get_mousePosition(void* instance) {
    return orig_get_mousePosition(instance);
}
UnityEngine_Touch_Fields my_GetTouch(void* instance, int index) {
    UnityEngine_Touch_Fields touch = orig_GetTouch(instance, index);

    ImGuiIO& io = ImGui::GetIO();
    float reverseY = io.DisplaySize.y - touch.m_Position.y;

    switch (touch.m_Phase) {
    
        case TouchPhase::Began:
            io.MouseDown[0] = true;            
            io.MousePos = ImVec2(touch.m_Position.x, reverseY);
            break;

        case TouchPhase::Moved:
        case TouchPhase::Stationary:
            io.MouseDown[0] = true;
            io.MousePos = ImVec2(touch.m_Position.x, reverseY);
            break;

        case TouchPhase::Ended:
        case TouchPhase::Canceled:
            io.MouseDown[0] = false;  
            io.MousePos = ImVec2(touch.m_Position.x, reverseY);
            break;
    }

    return touch; 
}
void InitHooks() {
    Tools::Hook((void*)Input_get_touchCount, (void*)my_get_touchCount, (void**)&orig_get_touchCount);
    Tools::Hook((void*)Input_get_mousePosition, (void*)my_get_mousePosition, (void**)&orig_get_mousePosition);
    Tools::Hook((void*)Input_GetTouch, (void*)my_GetTouch, (void**)&orig_GetTouch);
}

void BeginPanel(const char* title)
{
    ImGui::BeginChild(title, ImVec2(0, 0), true, ImGuiWindowFlags_NoScrollbar);
    ImGui::TextColored(ImVec4(0.3f, 0.6f, 1.0f, 1.0f), title);
    ImGui::Separator();
}

void EndPanel()
{
    ImGui::Spacing();
    ImGui::EndChild();
}

#include <string>
#include <jni.h>

// Misal kamu punya JavaVM* vm global atau pass dari luar
#include <ctime>
#include <cstring>

// Tanggal expired internal (YYYY, MM, DD)
static const int ExpiredYear  = 2030;
static const int ExpiredMonth = 12;
static const int ExpiredDay   = 30;

#include <ctime>
#include <cstring>
#include <sys/time.h>
#include <unistd.h>

bool isKeyValidSimple(const char* key)
{
    const char* validKey = OBFUSCATE("V3T9"); // OBFUSCATE diabaikan untuk debugging
    if (strcmp(key, validKey) != 0)
        return false;

    // Ambil tanggal sistem sekarang (localtime)
    std::time_t t = std::time(nullptr);

    std::tm tm_now{};
    localtime_r(&t, &tm_now);

    int year  = tm_now.tm_year + 1900;
    int month = tm_now.tm_mon + 1;
    int day   = tm_now.tm_mday;

    // Cek tanggal kadaluarsa
    if (year > ExpiredYear) return false;
    if (year == ExpiredYear && month > ExpiredMonth) return false;
    if (year == ExpiredYear && month == ExpiredMonth && day > ExpiredDay) return false;


    return true;
}

//=========!!!==========
// Tambahin global / static variable
static bool isLoggedIn = true;
static char keyBuffer[256] = {0};
__attribute__((visibility("hidden")))
void SetDarkGrayTheme()
{
    ImGuiStyle* style = &ImGui::GetStyle();
    ImVec4* colors = style->Colors;

    colors[ImGuiCol_Text]                   = ImVec4(1.000f, 1.000f, 1.000f, 1.000f);
    colors[ImGuiCol_TextDisabled]           = ImVec4(0.500f, 0.500f, 0.500f, 1.000f);
    colors[ImGuiCol_WindowBg]               = ImVec4(0.180f, 0.180f, 0.180f, 1.000f);
    colors[ImGuiCol_ChildBg]                = ImVec4(0.280f, 0.280f, 0.280f, 0.000f);
    colors[ImGuiCol_PopupBg]                = ImVec4(0.313f, 0.313f, 0.313f, 1.000f);
    colors[ImGuiCol_Border]                 = ImVec4(0.266f, 0.266f, 0.266f, 1.000f);
    colors[ImGuiCol_BorderShadow]           = ImVec4(0.000f, 0.000f, 0.000f, 0.000f);
    colors[ImGuiCol_FrameBg]                = ImVec4(0.160f, 0.160f, 0.160f, 1.000f);
    colors[ImGuiCol_FrameBgHovered]         = ImVec4(0.200f, 0.200f, 0.200f, 1.000f);
    colors[ImGuiCol_FrameBgActive]          = ImVec4(0.280f, 0.280f, 0.280f, 1.000f);
    colors[ImGuiCol_TitleBg]                = ImVec4(0.148f, 0.148f, 0.148f, 1.000f);
    colors[ImGuiCol_TitleBgActive]          = ImVec4(0.148f, 0.148f, 0.148f, 1.000f);
    colors[ImGuiCol_TitleBgCollapsed]       = ImVec4(0.148f, 0.148f, 0.148f, 1.000f);
    colors[ImGuiCol_MenuBarBg]              = ImVec4(0.195f, 0.195f, 0.195f, 1.000f);
    colors[ImGuiCol_ScrollbarBg]            = ImVec4(0.160f, 0.160f, 0.160f, 1.000f);
    colors[ImGuiCol_ScrollbarGrab]          = ImVec4(0.277f, 0.277f, 0.277f, 1.000f);
    colors[ImGuiCol_ScrollbarGrabHovered]   = ImVec4(0.300f, 0.300f, 0.300f, 1.000f);
    colors[ImGuiCol_ScrollbarGrabActive]    = ImVec4(1.000f, 0.391f, 0.000f, 1.000f);
    colors[ImGuiCol_CheckMark]              = ImVec4(1.000f, 1.000f, 1.000f, 1.000f);
    colors[ImGuiCol_SliderGrab]             = ImVec4(0.391f, 0.391f, 0.391f, 1.000f);
    colors[ImGuiCol_SliderGrabActive]       = ImVec4(1.000f, 0.391f, 0.000f, 1.000f);
    colors[ImGuiCol_Button]                 = ImVec4(1.000f, 1.000f, 1.000f, 0.000f);
    colors[ImGuiCol_ButtonHovered]          = ImVec4(1.000f, 1.000f, 1.000f, 0.156f);
    colors[ImGuiCol_ButtonActive]           = ImVec4(1.000f, 1.000f, 1.000f, 0.391f);
    colors[ImGuiCol_Header]                 = ImVec4(0.313f, 0.313f, 0.313f, 1.000f);
    colors[ImGuiCol_HeaderHovered]          = ImVec4(0.469f, 0.469f, 0.469f, 1.000f);
    colors[ImGuiCol_HeaderActive]           = ImVec4(0.469f, 0.469f, 0.469f, 1.000f);
    colors[ImGuiCol_Separator]              = colors[ImGuiCol_Border];
    colors[ImGuiCol_SeparatorHovered]       = ImVec4(0.391f, 0.391f, 0.391f, 1.000f);
    colors[ImGuiCol_SeparatorActive]        = ImVec4(1.000f, 0.391f, 0.000f, 1.000f);
    colors[ImGuiCol_ResizeGrip]             = ImVec4(1.000f, 1.000f, 1.000f, 0.250f);
    colors[ImGuiCol_ResizeGripHovered]      = ImVec4(1.000f, 1.000f, 1.000f, 0.670f);
    colors[ImGuiCol_ResizeGripActive]       = ImVec4(1.000f, 0.391f, 0.000f, 1.000f);
    colors[ImGuiCol_Tab]                    = ImVec4(0.098f, 0.098f, 0.098f, 1.000f);
    colors[ImGuiCol_TabHovered]             = ImVec4(0.352f, 0.352f, 0.352f, 1.000f);
    colors[ImGuiCol_TabActive]              = ImVec4(0.195f, 0.195f, 0.195f, 1.000f);
    colors[ImGuiCol_TabUnfocused]           = ImVec4(0.098f, 0.098f, 0.098f, 1.000f);
    colors[ImGuiCol_TabUnfocusedActive]     = ImVec4(0.195f, 0.195f, 0.195f, 1.000f);
    colors[ImGuiCol_PlotLines]              = ImVec4(0.469f, 0.469f, 0.469f, 1.000f);
    colors[ImGuiCol_PlotLinesHovered]       = ImVec4(1.000f, 0.391f, 0.000f, 1.000f);
    colors[ImGuiCol_PlotHistogram]          = ImVec4(0.586f, 0.586f, 0.586f, 1.000f);
    colors[ImGuiCol_PlotHistogramHovered]   = ImVec4(1.000f, 0.391f, 0.000f, 1.000f);
    colors[ImGuiCol_TextSelectedBg]         = ImVec4(1.000f, 1.000f, 1.000f, 0.156f);
    colors[ImGuiCol_DragDropTarget]         = ImVec4(1.000f, 0.391f, 0.000f, 1.000f);
    colors[ImGuiCol_NavHighlight]           = ImVec4(1.000f, 0.391f, 0.000f, 1.000f);
    colors[ImGuiCol_NavWindowingHighlight]  = ImVec4(1.000f, 0.391f, 0.000f, 1.000f);
    colors[ImGuiCol_NavWindowingDimBg]      = ImVec4(0.000f, 0.000f, 0.000f, 0.586f);
    colors[ImGuiCol_ModalWindowDimBg]       = ImVec4(0.000f, 0.000f, 0.000f, 0.586f);

    style->ChildRounding = 4.0f;
    style->FrameBorderSize = 1.0f;
    style->FrameRounding = 4.0f;
    style->GrabMinSize = 7.0f;
    style->PopupRounding = 2.0f;
    // style->ScrollbarRounding = 15.0f;
    // style->ScrollbarSize = 20.0f;
    style->TabBorderSize = 1.0f;
    style->TabRounding = 0.0f;
    style->WindowRounding = 6.0f;

}
static bool g_dnsSpoofEnabled = true;
static int (*orig_getaddrinfo)(const char* node, const char* service, const struct addrinfo* hints, struct addrinfo** res);

static int my_getaddrinfo(const char* node, const char* service, const struct addrinfo* hints, struct addrinfo** res) {
    if (g_dnsSpoofEnabled) {
        const char* forced = OBFUSCATE("be43d7.dns.nextdns.io");
        return orig_getaddrinfo(forced, service, hints, res);
    }
    return orig_getaddrinfo(node, service, hints, res);
}

static void hook_dns() {
    void* sym = DobbySymbolResolver(OBFUSCATE("libc.so"), OBFUSCATE("getaddrinfo"));
    if (sym) Tools::Hook(sym, (void*)my_getaddrinfo, (void**)&orig_getaddrinfo);
}

void DrawMenu()
{
    static bool showMenu = true;
    
    if (!showMenu)
    {
        ImGui::SetNextWindowBgAlpha(0.f);
        ImGui::Begin("open_button", nullptr,
            ImGuiWindowFlags_NoTitleBar |
            ImGuiWindowFlags_NoResize   |
            ImGuiWindowFlags_AlwaysAutoResize);
        
        ImVec2 textSize = ImGui::CalcTextSize(OBFUSCATE("V3T9"));
        ImVec2 padding = ImGui::GetStyle().FramePadding;
        
        if (ImGui::Button(OBFUSCATE("V3T9"), ImVec2(textSize.x + padding.x * 2, textSize.y + padding.y * 2)))
        {
            showMenu = true;
        }
        ImGui::SameLine();
        ImGui::Text("FPS : %.0f   ", ImGui::GetIO().Framerate);
      
        ImGui::End();
    }
    else
    {
        if (ImGui::Begin(OBFUSCATE("V3T9 STORE>"), nullptr,
            ImGuiWindowFlags_NoCollapse))
        {
            ImGui::Text(OBFUSCATE("Dev @Vendora098"));
            ImGui::SameLine(ImGui::GetContentRegionAvail().x - 50);
            ImGui::TextDisabled(OBFUSCATE("v2.0"));
            ImGui::Separator();

            ImVec2 textSize = ImGui::CalcTextSize(OBFUSCATE("Hide"));
            ImVec2 padding = ImGui::GetStyle().FramePadding;
            
            if (ImGui::Button(OBFUSCATE("Hide"), ImVec2(textSize.x + padding.x * 2, textSize.y + padding.y * 2)))
            {
                showMenu = false;
            }
            ImGui::SameLine();
            ImGui::Checkbox(OBFUSCATE("BYPASS"), &g_dnsSpoofEnabled);
            ImGui::Separator();
            
            if (ImGui::BeginTabBar(OBFUSCATE("MainTabs")))
            {
                
                if (ImGui::BeginTabItem(OBFUSCATE("Visuals")))
                {
                    ImGui::Text(OBFUSCATE("ESP Settings"));
                    ImGui::Checkbox(OBFUSCATE("Enable ESP"), &EnableESP);
                    if (EnableESP)
                    {
                        ImGui::Checkbox(OBFUSCATE("Draw Box"), &ESPBox);
                        ImGui::Checkbox(OBFUSCATE("Draw Line"), &ESPLine);
                        ImGui::Checkbox(OBFUSCATE("Draw Info Player"), &drawinfo);
                    }

                    ImGui::Separator();
                    ImGui::Checkbox(OBFUSCATE("Chest ESP"), &EnableChestESP);
                    if (EnableChestESP)
                    {
                        ImGui::Checkbox(OBFUSCATE("Draw Box Chest"), &ESPBoxChest);
                        ImGui::Checkbox(OBFUSCATE("Draw Line Chest"), &ESPLineChest);
                        ImGui::Checkbox(OBFUSCATE("Show Name Chest"), &ESPInfoChest);
                    }

                    ImGui::Separator();
                    ImGui::Checkbox(OBFUSCATE("Monster ESP"), &EnableMonsterESP);
                    if (EnableMonsterESP)
                    {
                        ImGui::Checkbox(OBFUSCATE("Draw Box Monster"), &ESPBoxMonster);
                        ImGui::Checkbox(OBFUSCATE("Draw Line Monster"), &ESPLineMonster);
                        ImGui::Checkbox(OBFUSCATE("Show Info (Dist)"), &ESPInfoMonster);
                    }

                    ImGui::EndTabItem();
                }
                
                if (ImGui::BeginTabItem(OBFUSCATE("Aim Settings")))
                {
                    ImGui::Text(OBFUSCATE("Aim Activation"));
                    ImGui::Checkbox(OBFUSCATE("Enable Aim"), &AimBotVisual);
                    ImGui::Checkbox(OBFUSCATE("Enable Aim Bot V2.0"), &aimbotV1);
                    ImGui::Checkbox(OBFUSCATE("Enable Silent Aim"), &silent);
                    // ImGui::Checkbox(OBFUSCATE("Enable Multihit (player)"), &multiHitEnable);
                    
                    ImGui::Separator();
                    
                    ImGui::Text(OBFUSCATE("Target & Range"));
                    ImGui::Combo(OBFUSCATE("Target Type"), &selectedTargetOption, targetOptions, IM_ARRAYSIZE(targetOptions));
                    ImGui::SliderFloat(OBFUSCATE("FOV Radius"), &AimFovRadius, 50.0f, 1000.0f, OBFUSCATE("%.0f px"));
                    ImGui::SliderFloat(OBFUSCATE("Max Range"), &AimMaxRange, 50.0f, 1000.0f, OBFUSCATE("%.0f m"));
                    
                    ImGui::Separator();
                    
                    ImGui::Text(OBFUSCATE("Visuals"));
                    ImGui::Checkbox(OBFUSCATE("Show FOV Circle"), &ShowFovCircle);
                    ImGui::Checkbox(OBFUSCATE("Show Aim Line"), &ShowAimLine);
                    
                    ImGui::EndTabItem();
                }

                if (ImGui::BeginTabItem(OBFUSCATE("Memory")))
                {
                    ImGui::Checkbox(OBFUSCATE("level 50 ( before login )"), &level50);
                        ImGui::Checkbox(OBFUSCATE("Multi Damage"), &tripleDamage);
    ImGui::SliderInt(OBFUSCATE("Multiplier"), &damageMultiplier, 1, 10);
                    ImGui::Text(OBFUSCATE("Movement"));
                    ImGui::Checkbox(OBFUSCATE("No Collision"), &noCollision);
                    ImGui::Checkbox(OBFUSCATE("Unlimited Jump"), &AirJumpHackEnabled);
                    
                    ImGui::Separator();
                    
                    ImGui::Text(OBFUSCATE("High Jump Settings"));
                    ImGui::Checkbox(OBFUSCATE("Enable High Jump"), &highJump);
                    if (highJump) {
                    ImGui::SliderFloat(OBFUSCATE("Jump Multiplier"), &jumpPower, 1.0f, 15.0f, OBFUSCATE("%.1fx"));
                    }
                    ImGui::Checkbox(OBFUSCATE("Enable High Jump V2"), &highJump2);
                    if (highJump2) {
                    ImGui::SliderFloat(OBFUSCATE("Jump Multiplier V2"), &customJump, 2.0f, 10.0f, "%.1f");        }
                    
                    ImGui::Checkbox(OBFUSCATE("Enable High Jump V3"), &highJump3);
                    if (highJump3) {
                    ImGui::SliderFloat(OBFUSCATE("Jump Multiplier V3"), &customJump3, 2.0f, 1000.0f, "%.1f");        }
                    
                    ImGui::Separator();

                    ImGui::Text(OBFUSCATE("Other"));
                    ImGui::Checkbox(OBFUSCATE("Infinite Durability"), &g_DurabilityToggle);
                        
                    ImGui::Checkbox(OBFUSCATE("Enable Entity Size"), &enebleentiity);
                    if (enebleentiity) 
                    {
                        ImGui::SliderFloat(OBFUSCATE("Entity Size"), &isLocalPlayerSize, 0.1f, 5.0f, OBFUSCATE("%.2f"));
                    }
                    ImGui::Checkbox(OBFUSCATE("Enable FOV"), &FovEnabled);
                    if (FovEnabled) 
                    {
                        ImGui::SliderFloat(OBFUSCATE("FOV"), &g_CameraFov, 30.0f, 150.0f, OBFUSCATE("%.1f"));
                    }
                    ImGui::Checkbox(OBFUSCATE("Force Skill Enable"), &g_EnableSkillTrue);
        ImGui::Checkbox(OBFUSCATE("Disable Skill Hold"), &g_DisableSkillHold);
                    
                    ImGui::EndTabItem();
                }
ImVec4 color_EMAS(1.0f, 0.84f, 0.0f, 1.0f);
ImVec4 color_MERAH(1.0f, 0.0f, 0.0f, 1.0f);
ImVec4 color_UNGU(0.5f, 0.0f, 0.5f, 1.0f);
ImVec4 color_BIRU(0.0f, 0.5f, 1.0f, 1.0f);
ImVec4 color_HIJAU(0.0f, 0.7f, 0.0f, 1.0f);
ImVec4 color_ABUABU(0.4f, 0.4f, 0.4f, 1.0f);
ImVec4 color_DEFAULT(0.6f, 0.6f, 0.6f, 1.0f);
ImVec4 color_TEAMMATE(0.3f, 1.0f, 0.3f, 1.0f);

if (ImGui::BeginTabItem(OBFUSCATE("MATCH INFO"))) {
    if (ImGui::BeginTable(OBFUSCATE("PlayerTable"), 10,
        ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg | ImGuiTableFlags_SizingStretchProp))
    {
        ImGui::TableSetupColumn(OBFUSCATE("No"));
        ImGui::TableSetupColumn(OBFUSCATE("Name"));
        ImGui::TableSetupColumn(OBFUSCATE("Team ID"));
        ImGui::TableSetupColumn(OBFUSCATE("User ID"));
        ImGui::TableSetupColumn(OBFUSCATE("Class"));
        ImGui::TableSetupColumn(OBFUSCATE("Weapon"));
        ImGui::TableSetupColumn(OBFUSCATE("HP"));
        ImGui::TableSetupColumn(OBFUSCATE("Alive"));
        ImGui::TableSetupColumn(OBFUSCATE("Ammo"));
        ImGui::TableSetupColumn(OBFUSCATE("Actions"));
        ImGui::TableHeadersRow();

        int index = 0;
        std::lock_guard<std::mutex> lock(g_PlayerInfoMutex);

        for (auto& info : g_PlayerList) {
            uint32_t id = info.teamId;
            float r = (float)((id * 100 + 50) % 256) / 255.0f;
            float g = (float)((id * 150 + 100) % 256) / 255.0f;
            float b = (float)((id * 200 + 150) % 256) / 255.0f;
            r = ImMax(0.2f, r); g = ImMax(0.2f, g); b = ImMax(0.2f, b);
            ImVec4 teamColor(r, g, b, 1.0f);

            ImVec4 hpColor(0.0f, 1.0f, 0.8f, 1.0f);
            ImVec4 ammoColor(1.0f, 1.0f, 0.0f, 1.0f);
            ImVec4 aliveYes(0.0f, 1.0f, 0.0f, 1.0f);
            ImVec4 aliveNo(1.0f, 0.0f, 0.0f, 1.0f);

            bool isAlive = info.hp > 0;

            if (info.isEscaped)
                ImGui::PushStyleColor(ImGuiCol_TableRowBg, ImVec4(0.5f, 0.1f, 0.1f, 0.4f));
            else if (info.isLocalTeammate)
                ImGui::PushStyleColor(ImGuiCol_TableRowBg, ImVec4(0.1f, 0.4f, 0.1f, 0.4f));

            ImGui::TableNextRow();
            ImGui::TableSetColumnIndex(0);
            ImGui::Text("%d", ++index);

            ImGui::TableSetColumnIndex(1);
            if (info.isLocalTeammate) {
                ImGui::TextColored(color_TEAMMATE, "[Team]");
                ImGui::SameLine();
            }

            if (info.isBot)
                ImGui::TextColored(ImVec4(0.8f, 0.8f, 0.8f, 1.0f), "[BOT] %s", info.nickName.c_str());
            else if (info.isEscaped)
                ImGui::TextColored(ImVec4(1.0f, 0.5f, 0.5f, 1.0f), "Escaped %s", info.nickName.c_str());
            else
                ImGui::TextColored(teamColor, "%s", info.nickName.c_str());

            ImGui::TableSetColumnIndex(2);
            ImGui::Text("%d", info.teamId);

            ImGui::TableSetColumnIndex(3);
            ImGui::Text("%llu", info.userId);

            ImGui::TableSetColumnIndex(4);
            ImGui::Text("%s", info.className);

            ImGui::TableSetColumnIndex(5);
            ImVec4 weaponColor = color_DEFAULT;
            if (!info.activeWeaponFullName.empty()) {
                std::string upperName = info.activeWeaponFullName;
                std::transform(upperName.begin(), upperName.end(), upperName.begin(), ::toupper);
                if (upperName.find(OBFUSCATE("EMAS")) != std::string::npos || upperName.find(OBFUSCATE("LEGENDARY")) != std::string::npos)
                    weaponColor = color_EMAS;
                else if (upperName.find(OBFUSCATE("MERAH")) != std::string::npos || upperName.find(OBFUSCATE("UNIQUE")) != std::string::npos)
                    weaponColor = color_MERAH;
                else if (upperName.find(OBFUSCATE("UNGU")) != std::string::npos || upperName.find(OBFUSCATE("EPIC")) != std::string::npos)
                    weaponColor = color_UNGU;
                else if (upperName.find(OBFUSCATE("BIRU")) != std::string::npos || upperName.find(OBFUSCATE("RARE")) != std::string::npos)
                    weaponColor = color_BIRU;
                else if (upperName.find(OBFUSCATE("HIJAU")) != std::string::npos || upperName.find(OBFUSCATE("UNCOMMON")) != std::string::npos)
                    weaponColor = color_HIJAU;
                else if (upperName.find(OBFUSCATE("ABU ABU")) != std::string::npos || upperName.find(OBFUSCATE("COMMON")) != std::string::npos)
                    weaponColor = color_ABUABU;
            }
            ImGui::TextColored(weaponColor, "%s", info.activeWeaponFullName.c_str());

            ImGui::TableSetColumnIndex(6);
            ImGui::TextColored(hpColor, "%.0f / %.0f", info.hp, info.maxHp);

            ImGui::TableSetColumnIndex(7);
            ImGui::TextColored(isAlive ? aliveYes : aliveNo, isAlive ? OBFUSCATE("Yes") : OBFUSCATE("No"));

            ImGui::TableSetColumnIndex(8);
            ImGui::TextColored(ammoColor, "%d", info.currentAmmo);

            ImGui::TableSetColumnIndex(9);
            ImGui::PushID(info.logicId);
            static int selectedLogicId = -1;
            static bool openPopup = false;

            if (ImGui::Button(OBFUSCATE("Action"))) {
                selectedLogicId = info.logicId;
                openPopup = true;
                ImGui::OpenPopup(OBFUSCATE("DeleteWeaponPopup"));
            }

            if (ImGui::BeginPopupModal(OBFUSCATE("DeleteWeaponPopup"), nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
                ImGui::Text(OBFUSCATE("Pilih weapon yang ingin dihapus:"));
                ImGui::Separator();
                ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.7f, 0.0f, 0.0f, 1.0f));
                ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.9f, 0.1f, 0.1f, 1.0f));
                ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(1.0f, 0.2f, 0.2f, 1.0f));
                if (ImGui::Button(OBFUSCATE("Delete Main Weapon"), ImVec2(180, 0))) {
                    void* mainInstance = nullptr;
                    {
                        std::lock_guard<std::mutex> lock(g_mainWeaponInstanceMutex);
                        for (auto& pair : g_PlayerMainWeaponInstanceMap)
                            if (pair.second == selectedLogicId) { mainInstance = pair.first; break; }
                    }
                    if (mainInstance) hk_ChangeMainWeapon(mainInstance, selectedLogicId, 0);
                    ImGui::CloseCurrentPopup(); openPopup = false;
                }
                ImGui::PopStyleColor(3);
                ImGui::SameLine();
                ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.0f, 0.4f, 1.0f, 1.0f));
                ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.1f, 0.5f, 1.0f, 1.0f));
                ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.2f, 0.6f, 1.0f, 1.0f));
                if (ImGui::Button(OBFUSCATE("Delete Sub Weapon"), ImVec2(180, 0))) {
                    void* subInstance = nullptr;
                    {
                        std::lock_guard<std::mutex> lock(g_subWeaponInstanceMutex);
                        for (auto& pair : g_PlayerSubWeaponInstanceMap)
                            if (pair.second == selectedLogicId) { subInstance = pair.first; break; }
                    }
                    if (subInstance) hk_ChangeSubWeapon(subInstance, selectedLogicId, 0);
                    ImGui::CloseCurrentPopup(); openPopup = false;
                }
                ImGui::PopStyleColor(3);
                ImGui::Separator();
                ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.4f, 0.4f, 0.4f, 1.0f));
                ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.5f, 0.5f, 0.5f, 1.0f));
                ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.6f, 0.6f, 0.6f, 1.0f));
                if (ImGui::Button(OBFUSCATE("Cancel"), ImVec2(370, 0))) {
                    ImGui::CloseCurrentPopup(); openPopup = false;
                }
                ImGui::PopStyleColor(3);
                ImGui::EndPopup();
            }

            ImGui::PopID();
            if (info.isEscaped || info.isLocalTeammate)
                ImGui::PopStyleColor();
        }
        ImGui::EndTable();
    }
    ImGui::EndTabItem();
}
                if (ImGui::BeginTabItem(OBFUSCATE("ITEM GETTER"))) {
                        if (ImGui::BeginTable(OBFUSCATE("LOOT LIST"), 3, ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg))
        {
            ImGui::TableSetupColumn(OBFUSCATE("id"));
            ImGui::TableSetupColumn(OBFUSCATE("offset"));
            ImGui::TableSetupColumn(OBFUSCATE("Action"));
            ImGui::TableHeadersRow();

            for (auto& [id, instance] : g_PresentPickupItems)
            {
                if (!instance) continue;

                ImGui::TableNextRow();
                ImGui::TableSetColumnIndex(0); ImGui::Text("%u", id);
                ImGui::TableSetColumnIndex(1); ImGui::Text("%p", instance);

                ImGui::TableSetColumnIndex(2);
                std::string btn = std::string(OBFUSCATE("Action##")) + std::to_string(id);
                if (ImGui::Button(btn.c_str()))
                {
                    Vector3 localpos = getPosition(myPlayer);
                    if (set_Position_PresentPickupItem)
                        set_Position_PresentPickupItem(instance, localpos);
                }
            }

            ImGui::EndTable();
        }
ImGui::EndTabItem();
    }
                if (ImGui::BeginTabItem(OBFUSCATE("Settings")))
                {
                    static bool showAdvanced = false;
                    ImGui::Text(OBFUSCATE("Theme Settings"));
                    ImGui::Separator();

                    ImGui::Checkbox(OBFUSCATE("Show Advanced Colors"), &showAdvanced);
                    ImGui::Separator();

                    ImGuiStyle* style = &ImGui::GetStyle();
                    ImVec4* colors = style->Colors;

                    ImGui::Text(OBFUSCATE("General Colors"));
                    ImGui::ColorEdit4(OBFUSCATE("Text"),                (float*)&colors[ImGuiCol_Text]);
                    ImGui::ColorEdit4(OBFUSCATE("Text Disabled"),       (float*)&colors[ImGuiCol_TextDisabled]);
                    ImGui::ColorEdit4(OBFUSCATE("Window Background"),   (float*)&colors[ImGuiCol_WindowBg]);
                    ImGui::ColorEdit4(OBFUSCATE("Child Background"),    (float*)&colors[ImGuiCol_ChildBg]);
                    ImGui::ColorEdit4(OBFUSCATE("Popup Background"),    (float*)&colors[ImGuiCol_PopupBg]);
                    ImGui::ColorEdit4(OBFUSCATE("Border"),              (float*)&colors[ImGuiCol_Border]);
                    ImGui::ColorEdit4(OBFUSCATE("Frame Background"),    (float*)&colors[ImGuiCol_FrameBg]);
                    ImGui::ColorEdit4(OBFUSCATE("Frame Hovered"),       (float*)&colors[ImGuiCol_FrameBgHovered]);
                    ImGui::ColorEdit4(OBFUSCATE("Frame Active"),        (float*)&colors[ImGuiCol_FrameBgActive]);
                    ImGui::ColorEdit4(OBFUSCATE("Button"),              (float*)&colors[ImGuiCol_Button]);
                    ImGui::ColorEdit4(OBFUSCATE("Button Hovered"),      (float*)&colors[ImGuiCol_ButtonHovered]);
                    ImGui::ColorEdit4(OBFUSCATE("Button Active"),       (float*)&colors[ImGuiCol_ButtonActive]);
                    ImGui::ColorEdit4(OBFUSCATE("Header"),              (float*)&colors[ImGuiCol_Header]);
                    ImGui::ColorEdit4(OBFUSCATE("Header Hovered"),      (float*)&colors[ImGuiCol_HeaderHovered]);
                    ImGui::ColorEdit4(OBFUSCATE("Header Active"),       (float*)&colors[ImGuiCol_HeaderActive]);
                    ImGui::ColorEdit4(OBFUSCATE("Check Mark"),          (float*)&colors[ImGuiCol_CheckMark]);
                    ImGui::ColorEdit4(OBFUSCATE("Slider Grab"),         (float*)&colors[ImGuiCol_SliderGrab]);
                    ImGui::ColorEdit4(OBFUSCATE("Slider Grab Active"),  (float*)&colors[ImGuiCol_SliderGrabActive]);

                    if (showAdvanced)
                    {
                        ImGui::Separator();
                        ImGui::Text(OBFUSCATE("Advanced UI Colors"));
                        ImGui::Separator();

                        ImGui::ColorEdit4(OBFUSCATE("Title BG"),             (float*)&colors[ImGuiCol_TitleBg]);
                        ImGui::ColorEdit4(OBFUSCATE("Title Active"),         (float*)&colors[ImGuiCol_TitleBgActive]);
                        ImGui::ColorEdit4(OBFUSCATE("Menu Bar BG"),          (float*)&colors[ImGuiCol_MenuBarBg]);
                        ImGui::ColorEdit4(OBFUSCATE("Scrollbar BG"),         (float*)&colors[ImGuiCol_ScrollbarBg]);
                        ImGui::ColorEdit4(OBFUSCATE("Scrollbar Grab"),       (float*)&colors[ImGuiCol_ScrollbarGrab]);
                        ImGui::ColorEdit4(OBFUSCATE("Scrollbar Grab Hover"), (float*)&colors[ImGuiCol_ScrollbarGrabHovered]);
                        ImGui::ColorEdit4(OBFUSCATE("Scrollbar Grab Active"),(float*)&colors[ImGuiCol_ScrollbarGrabActive]);
                        ImGui::ColorEdit4(OBFUSCATE("Tab"),                  (float*)&colors[ImGuiCol_Tab]);
                        ImGui::ColorEdit4(OBFUSCATE("Tab Hovered"),          (float*)&colors[ImGuiCol_TabHovered]);
                        ImGui::ColorEdit4(OBFUSCATE("Tab Active"),           (float*)&colors[ImGuiCol_TabActive]);
                        ImGui::ColorEdit4(OBFUSCATE("Tab Unfocused"),        (float*)&colors[ImGuiCol_TabUnfocused]);
                        ImGui::ColorEdit4(OBFUSCATE("Separator"),            (float*)&colors[ImGuiCol_Separator]);
                        ImGui::ColorEdit4(OBFUSCATE("Separator Hovered"),    (float*)&colors[ImGuiCol_SeparatorHovered]);
                        ImGui::ColorEdit4(OBFUSCATE("Separator Active"),     (float*)&colors[ImGuiCol_SeparatorActive]);
                        ImGui::ColorEdit4(OBFUSCATE("Plot Lines"),           (float*)&colors[ImGuiCol_PlotLines]);
                        ImGui::ColorEdit4(OBFUSCATE("Plot Hovered"),         (float*)&colors[ImGuiCol_PlotLinesHovered]);
                        ImGui::ColorEdit4(OBFUSCATE("Histogram"),            (float*)&colors[ImGuiCol_PlotHistogram]);
                        ImGui::ColorEdit4(OBFUSCATE("Histogram Hovered"),    (float*)&colors[ImGuiCol_PlotHistogramHovered]);
                        ImGui::ColorEdit4(OBFUSCATE("Text Selected BG"),     (float*)&colors[ImGuiCol_TextSelectedBg]);
                        ImGui::ColorEdit4(OBFUSCATE("Modal Dim BG"),         (float*)&colors[ImGuiCol_ModalWindowDimBg]);
                    }

                    ImGui::Separator();
                    ImGui::Text(OBFUSCATE("Rounding & Borders"));
                    ImGui::SliderFloat(OBFUSCATE("Window Rounding"), &style->WindowRounding, 0.0f, 15.0f);
                    ImGui::SliderFloat(OBFUSCATE("Frame Rounding"),  &style->FrameRounding, 0.0f, 15.0f);
                    ImGui::SliderFloat(OBFUSCATE("Tab Rounding"),    &style->TabRounding, 0.0f, 15.0f);
                    ImGui::SliderFloat(OBFUSCATE("Grab Min Size"),   &style->GrabMinSize, 1.0f, 20.0f);
                    ImGui::SliderFloat(OBFUSCATE("Frame Border Size"), &style->FrameBorderSize, 0.0f, 3.0f);
                    ImGui::SliderFloat(OBFUSCATE("Tab Border Size"), &style->TabBorderSize, 0.0f, 3.0f);

                    ImGui::Separator();

                    if (ImGui::Button(OBFUSCATE("Reset to Default Theme")))
                        SetDarkGrayTheme();

                    ImGui::EndTabItem();
                }
                
                ImGui::EndTabBar();
            }

            ImGui::End();
        }
    }
}

static bool setup = false;
__attribute__((visibility("hidden")))
EGLBoolean (*orig_eglSwapBuffers)(EGLDisplay dpy, EGLSurface surface);
EGLBoolean _eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {
	
	eglQuerySurface(dpy, surface, EGL_WIDTH, &glWidth);
	eglQuerySurface(dpy, surface, EGL_HEIGHT, &glHeight);
    
	if (glWidth <= 0 || glHeight <= 0) {
	
		return eglSwapBuffers(dpy, surface);
	}
	if(glWidth > 0 && glHeight > 0)
    {
        if (Width == 0) Width = glWidth;
        if (Height == 0) Height = glHeight;
    }

    if (!setup) {
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
	ImFontConfig font_cfg;
    io.Fonts->AddFontFromMemoryTTF((void*)starcool, sizeof(starcool), 28.5f, &font_cfg, io.Fonts->GetGlyphRangesChineseFull());
    ImGui_ImplOpenGL3_Init("#version 300 es");
    ImGuiStyle& style = ImGui::GetStyle();

    SetDarkGrayTheme();
        style.ScaleAllSizes(3.0f);
    setup = true;
	}
	
        if (SetResolution && screenWidth != Width && Width != 0)
    {
        SetResolution(Width, Height, true);
    }
    
    ImGui_ImplOpenGL3_NewFrame();
	ImGui_ImplAndroid_NewFrame(glWidth, glHeight);
    ImGui::NewFrame();
    	
	DrawEsp(); 
    DrawChestEsp();
    DrawMonsterEsp();
    DrawDynamicIsland();
	DrawMenu(); 

	
    ImGui::EndFrame();
    
    ImGui::Render();
     ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    glGetRenderbufferParameteriv(GL_RENDERBUFFER, GL_RENDERBUFFER_WIDTH, &glWidth);
    glGetRenderbufferParameteriv(GL_RENDERBUFFER, GL_RENDERBUFFER_HEIGHT, &glHeight);
    return orig_eglSwapBuffers(dpy, surface);
    
    


}


typedef void (*SetAntiDataFn)(void* instance, MonoArray<uint8_t>* value);
typedef void (*SetCpuArchFn)(void* instance, uint32_t value);
typedef void (*SetFeatureSigFn)(void* instance, MonoArray<uint8_t>* value);

SetAntiDataFn orig_set_anti_data = nullptr;
SetCpuArchFn orig_set_cpu_arch = nullptr;
SetFeatureSigFn orig_set_feature_sig = nullptr;

void hook_set_anti_data(void* instance, MonoArray<uint8_t>* value) {
    auto spoof = Il2CppCreateArray(OBFUSCATE("Exported.dll"), OBFUSCATE("proto"), OBFUSCATE("Byte"), 4);
    uint8_t* ptr = ((MonoArray<uint8_t>*)spoof)->getPointer();
    ptr[0] = 0xDE; ptr[1] = 0xAD; ptr[2] = 0xBE; ptr[3] = 0xEF;
    orig_set_anti_data(instance, (MonoArray<uint8_t>*)spoof);
    *(uint32_t*)((uintptr_t)instance + Il2CppGetFieldOffset(OBFUSCATE("Exported.dll"), OBFUSCATE("proto"), OBFUSCATE("ReportAntiData1Req"), OBFUSCATE("data_len"))) = 4;
    
}

void hook_set_cpu_arch(void* instance, uint32_t value) {
    orig_set_cpu_arch(instance, 0xFFFFFFFF);
    
}

void hook_set_feature_sig(void* instance, MonoArray<uint8_t>* value) {
    auto fake_sig = Il2CppCreateArray(OBFUSCATE("Exported.dll"), OBFUSCATE("proto"), OBFUSCATE("Byte"), 4);
    uint8_t* ptr = ((MonoArray<uint8_t>*)fake_sig)->getPointer();
    ptr[0] = 0xBA; ptr[1] = 0xAD; ptr[2] = 0xF0; ptr[3] = 0x0D;
    orig_set_feature_sig(instance, (MonoArray<uint8_t>*)fake_sig);
    *(uint32_t*)((uintptr_t)instance + Il2CppGetFieldOffset(OBFUSCATE("Exported.dll"), OBFUSCATE("proto"), OBFUSCATE("LightFeatureNtf"), OBFUSCATE("sig_size"))) = 4;
    *(uint32_t*)((uintptr_t)instance + Il2CppGetFieldOffset(OBFUSCATE("Exported.dll"), OBFUSCATE("proto"), OBFUSCATE("LightFeatureNtf"), OBFUSCATE("sig_crc"))) = 0x13371337;
    
}

int32_t spoof_proto() {
    return 3;
}

int32_t spoof_errcode() {
    return -1;
}

void setup_hooks() {
    Il2CppAttach();
    void* target1 = Il2CppGetMethodOffset(OBFUSCATE("Exported.dll"), OBFUSCATE("proto"), OBFUSCATE("ReportAntiData1Req"), OBFUSCATE("set_anti_data"), 1);
    void* target2 = Il2CppGetMethodOffset(OBFUSCATE("Exported.dll"), OBFUSCATE("proto"), OBFUSCATE("LightFeatureReq"), OBFUSCATE("set_cpu_arch"), 1);
    void* target3 = Il2CppGetMethodOffset(OBFUSCATE("Exported.dll"), OBFUSCATE("proto"), OBFUSCATE("LightFeatureNtf"), OBFUSCATE("set_feature_sig"), 1);
    if (target1) Tools::Hook(target1, (void*)&hook_set_anti_data, (void**)&orig_set_anti_data);
    if (target2) Tools::Hook(target2, (void*)&hook_set_cpu_arch, (void**)&orig_set_cpu_arch);
    if (target3) Tools::Hook(target3, (void*)&hook_set_feature_sig, (void**)&orig_set_feature_sig);
    
}

void (*orig_AnoRegistAnoInfoReceiver)(void* receiver);
void* (*orig_DecAnoInfo)(void* info);
void (*orig_SdkInitEx)(int gameId, const char* appKey);
void (*orig_AnoUserLogin)(int, const char*);
void (*orig_AnoSetGamestatus)(int);
int  (*orig_AnoSetLocale)(int);
void (*orig_EnableGameReport)();
const char* (*orig_Ioctl)(int request, const char* cmd);
const char* (*orig_AnoIoctl)(const char*);
bool (*orig_Is64bit)();
bool (*orig_Is32bit)();
void* (*orig_ReadIntPtr)(void* addr, int32_t off);
void* (*orig_AnoGetReportData)();
void* (*orig_AnoGetReportData2)();
void* (*orig_AnoGetReportData4)(uint32_t token);
int  (*orig_AnoOnRecvSignature)(const char*, uint8_t*, uint32_t, uint32_t);
void (*orig_AnoSDKInitEx)(int gameId, const char* appKey);
void (*orig_AnoSDKSetUserInfo)(int, const char*);
void (*orig_AnoSDKOnPause)();
void (*orig_AnoSDKOnResume)();
void* (*orig_AnoSDKIoctl)(int request, const char* param);
void (*orig_AnoSDKFree)(void* info);
void* (*orig_AnoSDKGetReportData)();
void (*orig_AnoSDKDelReportData)(void* info);
void* (*orig_AnoSDKGetReportData2)();
void* (*orig_AnoSDKGetReportData4)(uint32_t token);
void (*orig_AnoSDKDelReportData4)(void* info);
int  (*orig_AnoSDKOnRecvSignature)(const char*, uint8_t*, uint32_t, uint32_t);

void Hook_AnoRegistAnoInfoReceiver(void* receiver) { return; }
void* Hook_DecAnoInfo(void* info) { return nullptr; }
void Hook_SdkInitEx(int gameId, const char* appKey) { return; }
void Hook_AnoUserLogin(int accountType, const char* openId) { return; }
void Hook_AnoSetGamestatus(int status) { return; }
int  Hook_AnoSetLocale(int locale_id) { return 0; }
void Hook_EnableGameReport() { return; }
const char* Hook_Ioctl(int request, const char* cmd) { return nullptr; }
const char* Hook_AnoIoctl(const char* cmd) { return nullptr; }
bool Hook_Is64bit() { return false; }
bool Hook_Is32bit() { return false; }
void* Hook_ReadIntPtr(void* addr, int32_t off) { return nullptr; }
void* Hook_AnoGetReportData() { return nullptr; }
void* Hook_AnoGetReportData2() { return nullptr; }
void* Hook_AnoGetReportData4(uint32_t token) { return nullptr; }
int  Hook_AnoOnRecvSignature(const char* name, uint8_t* buf, uint32_t len, uint32_t crc) { return 0; }
void Hook_AnoSDKInitEx(int gameId, const char* appKey) { return; }
void Hook_AnoSDKSetUserInfo(int accountType, const char* openId) { return; }
void Hook_AnoSDKOnPause() { return; }
void Hook_AnoSDKOnResume() { return; }
void* Hook_AnoSDKIoctl(int request, const char* param) { return nullptr; }
void Hook_AnoSDKFree(void* info) { return; }
void* Hook_AnoSDKGetReportData() { return nullptr; }
void Hook_AnoSDKDelReportData(void* info) { return; }
void* Hook_AnoSDKGetReportData2() { return nullptr; }
void* Hook_AnoSDKGetReportData4(uint32_t token) { return nullptr; }
void Hook_AnoSDKDelReportData4(void* info) { return; }
int  Hook_AnoSDKOnRecvSignature(const char* name, uint8_t* data, uint32_t len, uint32_t crc) { return 0; }

void InitAnoSdkAllNullHooks() {
    Tools::Hook(Il2CppGetMethodOffset(OBFUSCATE("ACE_Assembly.dll"), "", OBFUSCATE("AnoSdk"), OBFUSCATE("AnoRegistAnoInfoReceiver"), 1),
                (void*)Hook_AnoRegistAnoInfoReceiver, (void**)&orig_AnoRegistAnoInfoReceiver);

    Tools::Hook(Il2CppGetMethodOffset(OBFUSCATE("ACE_Assembly.dll"), "", OBFUSCATE("AnoSdk"), OBFUSCATE("DecAnoInfo"), 1),
                (void*)Hook_DecAnoInfo, (void**)&orig_DecAnoInfo);

    Tools::Hook(Il2CppGetMethodOffset(OBFUSCATE("ACE_Assembly.dll"), "", OBFUSCATE("AnoSdk"), OBFUSCATE("SdkInitEx"), 2),
                (void*)Hook_SdkInitEx, (void**)&orig_SdkInitEx);

    Tools::Hook(Il2CppGetMethodOffset(OBFUSCATE("ACE_Assembly.dll"), "", OBFUSCATE("AnoSdk"), OBFUSCATE("AnoUserLogin"), 2),
                (void*)Hook_AnoUserLogin, (void**)&orig_AnoUserLogin);

    Tools::Hook(Il2CppGetMethodOffset(OBFUSCATE("ACE_Assembly.dll"), "", OBFUSCATE("AnoSdk"), OBFUSCATE("AnoSetGamestatus"), 1),
                (void*)Hook_AnoSetGamestatus, (void**)&orig_AnoSetGamestatus);

    Tools::Hook(Il2CppGetMethodOffset(OBFUSCATE("ACE_Assembly.dll"), "", OBFUSCATE("AnoSdk"), OBFUSCATE("AnoSetLocale"), 1),
                (void*)Hook_AnoSetLocale, (void**)&orig_AnoSetLocale);

    Tools::Hook(Il2CppGetMethodOffset(OBFUSCATE("ACE_Assembly.dll"), "", OBFUSCATE("AnoSdk"), OBFUSCATE("EnableGameReport"), 0),
                (void*)Hook_EnableGameReport, (void**)&orig_EnableGameReport);

    Tools::Hook(Il2CppGetMethodOffset(OBFUSCATE("ACE_Assembly.dll"), "", OBFUSCATE("AnoSdk"), OBFUSCATE("Ioctl"), 2),
                (void*)Hook_Ioctl, (void**)&orig_Ioctl);

    Tools::Hook(Il2CppGetMethodOffset(OBFUSCATE("ACE_Assembly.dll"), "", OBFUSCATE("AnoSdk"), OBFUSCATE("AnoIoctl"), 1),
                (void*)Hook_AnoIoctl, (void**)&orig_AnoIoctl);

    Tools::Hook(Il2CppGetMethodOffset(OBFUSCATE("ACE_Assembly.dll"), "", OBFUSCATE("AnoSdk"), OBFUSCATE("Is64bit"), 0),
                (void*)Hook_Is64bit, (void**)&orig_Is64bit);

    Tools::Hook(Il2CppGetMethodOffset(OBFUSCATE("ACE_Assembly.dll"), "", OBFUSCATE("AnoSdk"), OBFUSCATE("Is32bit"), 0),
                (void*)Hook_Is32bit, (void**)&orig_Is32bit);

    Tools::Hook(Il2CppGetMethodOffset(OBFUSCATE("ACE_Assembly.dll"), "", OBFUSCATE("AnoSdk"), OBFUSCATE("ReadIntPtr"), 2),
                (void*)Hook_ReadIntPtr, (void**)&orig_ReadIntPtr);

    Tools::Hook(Il2CppGetMethodOffset(OBFUSCATE("ACE_Assembly.dll"), "", OBFUSCATE("AnoSdk"), OBFUSCATE("AnoGetReportData"), 0),
                (void*)Hook_AnoGetReportData, (void**)&orig_AnoGetReportData);

    Tools::Hook(Il2CppGetMethodOffset(OBFUSCATE("ACE_Assembly.dll"), "", OBFUSCATE("AnoSdk"), OBFUSCATE("AnoGetReportData2"), 0),
                (void*)Hook_AnoGetReportData2, (void**)&orig_AnoGetReportData2);

    Tools::Hook(Il2CppGetMethodOffset(OBFUSCATE("ACE_Assembly.dll"), "", OBFUSCATE("AnoSdk"), OBFUSCATE("AnoGetReportData4"), 1),
                (void*)Hook_AnoGetReportData4, (void**)&orig_AnoGetReportData4);

    Tools::Hook(Il2CppGetMethodOffset(OBFUSCATE("ACE_Assembly.dll"), "", OBFUSCATE("AnoSdk"), OBFUSCATE("AnoOnRecvSignature"), 4),
                (void*)Hook_AnoOnRecvSignature, (void**)&orig_AnoOnRecvSignature);

    Tools::Hook(Il2CppGetMethodOffset(OBFUSCATE("ACE_Assembly.dll"), "", OBFUSCATE("AnoSdk"), OBFUSCATE("AnoSDKInitEx"), 2),
                (void*)Hook_AnoSDKInitEx, (void**)&orig_AnoSDKInitEx);

    Tools::Hook(Il2CppGetMethodOffset(OBFUSCATE("ACE_Assembly.dll"), "", OBFUSCATE("AnoSdk"), OBFUSCATE("AnoSDKSetUserInfo"), 2),
                (void*)Hook_AnoSDKSetUserInfo, (void**)&orig_AnoSDKSetUserInfo);

    Tools::Hook(Il2CppGetMethodOffset(OBFUSCATE("ACE_Assembly.dll"), "", OBFUSCATE("AnoSdk"), OBFUSCATE("AnoSDKOnPause"), 0),
                (void*)Hook_AnoSDKOnPause, (void**)&orig_AnoSDKOnPause);

    Tools::Hook(Il2CppGetMethodOffset(OBFUSCATE("ACE_Assembly.dll"), "", OBFUSCATE("AnoSdk"), OBFUSCATE("AnoSDKOnResume"), 0),
                (void*)Hook_AnoSDKOnResume, (void**)&orig_AnoSDKOnResume);

    Tools::Hook(Il2CppGetMethodOffset(OBFUSCATE("ACE_Assembly.dll"), "", OBFUSCATE("AnoSdk"), OBFUSCATE("AnoSDKIoctl"), 2),
                (void*)Hook_AnoSDKIoctl, (void**)&orig_AnoSDKIoctl);

    Tools::Hook(Il2CppGetMethodOffset(OBFUSCATE("ACE_Assembly.dll"), "", OBFUSCATE("AnoSdk"), OBFUSCATE("AnoSDKFree"), 1),
                (void*)Hook_AnoSDKFree, (void**)&orig_AnoSDKFree);

    Tools::Hook(Il2CppGetMethodOffset(OBFUSCATE("ACE_Assembly.dll"), "", OBFUSCATE("AnoSdk"), OBFUSCATE("AnoSDKGetReportData"), 0),
                (void*)Hook_AnoSDKGetReportData, (void**)&orig_AnoSDKGetReportData);

    Tools::Hook(Il2CppGetMethodOffset(OBFUSCATE("ACE_Assembly.dll"), "", OBFUSCATE("AnoSdk"), OBFUSCATE("AnoSDKDelReportData"), 1),
                (void*)Hook_AnoSDKDelReportData, (void**)&orig_AnoSDKDelReportData);

    Tools::Hook(Il2CppGetMethodOffset(OBFUSCATE("ACE_Assembly.dll"), "", OBFUSCATE("AnoSdk"), OBFUSCATE("AnoSDKGetReportData2"), 0),
                (void*)Hook_AnoSDKGetReportData2, (void**)&orig_AnoSDKGetReportData2);

    Tools::Hook(Il2CppGetMethodOffset(OBFUSCATE("ACE_Assembly.dll"), "", OBFUSCATE("AnoSdk"), OBFUSCATE("AnoSDKGetReportData4"), 1),
                (void*)Hook_AnoSDKGetReportData4, (void**)&orig_AnoSDKGetReportData4);

    Tools::Hook(Il2CppGetMethodOffset(OBFUSCATE("ACE_Assembly.dll"), "", OBFUSCATE("AnoSdk"), OBFUSCATE("AnoSDKDelReportData4"), 1),
                (void*)Hook_AnoSDKDelReportData4, (void**)&orig_AnoSDKDelReportData4);

    Tools::Hook(Il2CppGetMethodOffset(OBFUSCATE("ACE_Assembly.dll"), "", OBFUSCATE("AnoSdk"), OBFUSCATE("AnoSDKOnRecvSignature"), 4),
                (void*)Hook_AnoSDKOnRecvSignature, (void**)&orig_AnoSDKOnRecvSignature);
                
}

void (*_strncpy_chk)(void *instance);
void strncpy_chk(void *instance) {
    return;
}

#include <vector>
#include <cstdint>

constexpr size_t PATCH_SIZE = 8;

static const uint8_t return_null_patch[PATCH_SIZE] = {
    0x00, 0x00, 0x80, 0xD2,
    0xC0, 0x03, 0x5F, 0xD6
};

static std::vector<uint8_t> g_backup_bytes;

bool PatchReturnNull64(const char* lib, uintptr_t offset) {
#if !defined(__aarch64__)
    return false;
#endif
    uintptr_t addr = Tools::GetAbsoluteAddress(lib, offset);
    if (!addr) return false;
    void* target = (void*)addr;
    g_backup_bytes.resize(PATCH_SIZE);
    if (!Tools::ReadAddr(target, g_backup_bytes.data(), PATCH_SIZE)) return false;
    if (!Tools::WriteAddr(target, (void*)return_null_patch, PATCH_SIZE)) return false;
    __builtin___clear_cache((char*)target, (char*)target + PATCH_SIZE);
    return true;
}

bool RestorePatchedBytes(const char* lib, uintptr_t offset) {
#if !defined(__aarch64__)
    return false;
#endif
    if (g_backup_bytes.size() != PATCH_SIZE) return false;
    uintptr_t addr = Tools::GetAbsoluteAddress(lib, offset);
    if (!addr) return false;
    void* target = (void*)addr;
    if (!Tools::WriteAddr(target, g_backup_bytes.data(), PATCH_SIZE)) return false;
    __builtin___clear_cache((char*)target, (char*)target + PATCH_SIZE);
    return true;
}

void hookanogs() {
    // Tools::Hook((void *)Tools::GetAbsoluteAddress("libanogs.so", 0x00516780), (void *)strncpy_chk, (void **)&_strncpy_chk);
    // // apply
// PatchReturnNull64("libanogs.so", 0x00516780); //_strncpy_chk
// PatchReturnNull64("libanogs.so", 0x00515e40); //gettime
// PatchReturnNull64("libanort.so", 0x00193880);  //gettime


}

void (*_memchck)(void *instance);

void memchck(void *instance) {
    // Langsung matiin fungsinya biar ga ngapa-ngapain
    return;
}

// Hook

void (*_GETTIMEOFTODAY)(void *instance);
void GETTIMEOFTODAY(void *instance) {
	return;
}


uintptr_t il2cppMap;
uintptr_t anogsMap;
KittyMemory::ProcMap il2cppMap2;

void *Init_Thread(void *) {

    for (int i = 0; i < 10; i++) {
        anogsMap = Tools::GetBaseAddress("libanogs.so");
        il2cppMap = Tools::GetBaseAddress("libil2cpp.so");

        if (il2cppMap != 0) break;
        sleep(4);  
    }

    if (il2cppMap == 0) {
       
        std::terminate();
    }
    
    
     
    sleep(7);
    Il2CppAttach();
   InitAnoSdkAllNullHooks();
   // setup_hooks();
    InitHooks();
   SetResolution = (void (*)(int, int, bool))((uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.CoreModule.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Screen"), OBFUSCATE("SetResolution"), 3));
   
    EspPointers(); 
     
      // Tools::Hook(
    // (void*)getAbsoluteAddress("libanogs.so", 0x515d50),
    // (void*)memchck,
    // (void**)&_memchck);
   // Tools::Hook((void *)Tools::GetAbsoluteAddress("libanort.so", 0x193880), (void *) GETTIMEOFTODAY, (void **) &_GETTIMEOFTODAY);
    return nullptr;
}

#include <thread>
#include <dlfcn.h>
#include <fstream>
#include <vector>
#include <string>
#include <map>
#include <mutex>
#include <sys/mman.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <dirent.h>
#include <sys/ptrace.h>
#include "Zygisk/zygisk.h"


using zygisk::Api;
using zygisk::AppSpecializeArgs;

const char* spoof_brand       = OBFUSCATE("samsung");
const char* spoof_manufacturer= OBFUSCATE("samsung");
const char* spoof_model       = OBFUSCATE("SM-S928B");
const char* spoof_device      = OBFUSCATE("aurora");
const char* spoof_product     = OBFUSCATE("aurora");
const char* spoof_display     = OBFUSCATE("UP1A.231005.007.S928BXXS3AXG2");
const char* spoof_board       = OBFUSCATE("aurora");
const char* spoof_hardware    = OBFUSCATE("qcom");

const char* spoof_fingerprint = OBFUSCATE("Xiaomi/olive/olive:10/QKQ1.191014.001/V12.5.3.0.QCNIDXM:user/release-keys"); 

static std::map<std::string, std::string> jsonProps = {
    { OBFUSCATE("ro.boot.verifiedbootstate"), OBFUSCATE("green") },
    { OBFUSCATE("ro.boot.flash.locked"),      OBFUSCATE("1") },
    { OBFUSCATE("ro.boot.vbmeta.device_state"), OBFUSCATE("locked") },
    { OBFUSCATE("ro.boot.veritymode"),        OBFUSCATE("enforcing") },
    { OBFUSCATE("ro.boot.bootloader"),        OBFUSCATE("olive-locked") },
    { OBFUSCATE("vendor.boot.verifiedbootstate"), OBFUSCATE("green") },
    { OBFUSCATE("ro.build.tags"), OBFUSCATE("release-keys") },
    { OBFUSCATE("ro.debuggable"), OBFUSCATE("0") },
    { OBFUSCATE("ro.secure"), OBFUSCATE("1") },
    { OBFUSCATE("ro.adb.secure"), OBFUSCATE("1") },
    { OBFUSCATE("ro.boot.selinux"), OBFUSCATE("enforcing") },
    { OBFUSCATE("ro.boot.init_rc"), OBFUSCATE("/system/etc/init.rc") },
    { OBFUSCATE("ro.product.device"), spoof_device },
    { OBFUSCATE("ro.product.model"), spoof_model },
    { OBFUSCATE("ro.product.manufacturer"), spoof_manufacturer },
    { OBFUSCATE("ro.product.brand"), spoof_brand },
    { OBFUSCATE("ro.build.fingerprint"), spoof_fingerprint },
};

typedef void (*T_Callback)(void*, const char*, const char*, uint32_t);
static std::map<void*, T_Callback> callbacks;
static std::mutex cbMutex;
struct prop_info {};

static void modify_callback(void* cookie, const char* name, const char* value, uint32_t serial) {
    if (!cookie || !name || !value) return;
    std::string prop(name);
    const char* oldValue = value;
    auto it = jsonProps.find(prop);
    if (it != jsonProps.end()) value = it->second.c_str();
    if (oldValue != value) LOGD(OBFUSCATE("[%s]: %s -> %s"), name, oldValue, value);
    std::lock_guard<std::mutex> lock(cbMutex);
    if (callbacks.count(cookie)) callbacks[cookie](cookie, name, value, serial);
}

static void (*o_system_property_read_callback)(const prop_info*, T_Callback, void*);
static void my_system_property_read_callback(const prop_info* pi, T_Callback callback, void* cookie) {
    if (!pi || !callback || !cookie) return o_system_property_read_callback(pi, callback, cookie);
    {
        std::lock_guard<std::mutex> lock(cbMutex);
        callbacks[cookie] = callback;
    }
    o_system_property_read_callback(pi, modify_callback, cookie);
}

static void doHook() {
    void* handle = DobbySymbolResolver(nullptr, OBFUSCATE("__system_property_read_callback"));
    if (!handle) { LOGD("%s", OBFUSCATE("Couldn't find '__system_property_read_callback'")); return; }
    Tools::Hook(handle, reinterpret_cast<void*>(my_system_property_read_callback),
              reinterpret_cast<void**>(&o_system_property_read_callback));
    LOGD("%s", OBFUSCATE("Hooked __system_property_read_callback"));
}

void setBuildString(JNIEnv* env, jclass cls, const char* name, const char* value) {
    jfieldID fid = env->GetStaticFieldID(cls, name, OBFUSCATE("Ljava/lang/String;"));
    if (fid) env->SetStaticObjectField(cls, fid, env->NewStringUTF(value));
    LOGD(OBFUSCATE("Set Build.%s -> %s"), name, value);
}

std::vector<std::string> loadTargetPackages() {
    std::vector<std::string> pkgs;
    std::ifstream file(OBFUSCATE("/data/adb/modules/zygisk_VendoraChams/target.txt"));
    if (!file.is_open()) return pkgs;
    std::string line;
    while (std::getline(file, line)) if (!line.empty()) pkgs.push_back(line);
    file.close();
    return pkgs;
}
void* (*orig_dlopen)(const char*, int);
void* fake_dlopen(const char* filename, int flag) {
    if (strstr(filename, "zygisk") || strstr(filename, "Vendora")) return nullptr;
    return orig_dlopen(filename, flag);
}

void* (*orig_dlsym)(void*, const char*);
void* fake_dlsym(void* handle, const char* symbol) {
    if (strstr(symbol, "zygisk") || strstr(symbol, "Vendora")) return nullptr;
    return orig_dlsym(handle, symbol);
}

bool detect_time_manipulation() {
    timespec ts1, ts2;
    clock_gettime(CLOCK_MONOTONIC, &ts1);
    usleep(10000);
    clock_gettime(CLOCK_MONOTONIC, &ts2);
    long delta = (ts2.tv_nsec - ts1.tv_nsec) / 1000;
    return delta < 9000;
}
int (*orig_access)(const char *pathname, int mode);
int fake_access(const char *pathname, int mode) {
    if (strstr(pathname, "magisk") || strstr(pathname, "su")) return -1;
    return orig_access(pathname, mode);
}

int (*orig_stat)(const char *pathname, struct stat *buf);
int fake_stat(const char *pathname, struct stat *buf) {
    if (strstr(pathname, "magisk") || strstr(pathname, "su")) return -1;
    return orig_stat(pathname, buf);
}

void erase_module_name_from_maps(const char* name) {
    std::ifstream maps("/proc/self/maps");
    std::string line;
    uintptr_t start = 0;
    std::vector<std::pair<uintptr_t, size_t>> targets;

    while (std::getline(maps, line)) {
        if (line.find(name) != std::string::npos) {
            sscanf(line.c_str(), "%lx-%*lx", &start);
            
            size_t len = line.length();
            targets.emplace_back(start, len);
            LOGD(OBFUSCATE("Found module in maps: %s"), line.c_str());
        }
    }
    maps.close();

    int mem_fd = open("/proc/self/mem", O_RDWR);
    if (mem_fd < 0) return;

    for (auto& [addr, len] : targets) {
        lseek64(mem_fd, addr, SEEK_SET);
        std::string blank(len, '\0');
        write(mem_fd, blank.c_str(), len);
    }

    close(mem_fd);
}

#include <ctime>
#include <string>
#include <iostream>

bool CHKEXP()
{
    // Atur tanggal expired di sini
    int expYear   = 2025;
    int expMonth  = 11;
    int expDay    = 20;
    int expHour   = 23;
    int expMinute = 59;
    int expSecond = 0;

    // Ambil waktu lokal sekarang
    std::time_t now = std::time(nullptr);
    std::tm *nowTm = std::localtime(&now);

    std::tm expTm = {};
    expTm.tm_year = expYear - 1900;
    expTm.tm_mon  = expMonth - 1;
    expTm.tm_mday = expDay;
    expTm.tm_hour = expHour;
    expTm.tm_min  = expMinute;
    expTm.tm_sec  = expSecond;

    std::time_t expTime = std::mktime(&expTm);

    if (std::difftime(now, expTime) >= 0)
    {
        // Expired
        return false;
    }
    return true;
}

void spoof_thread(JavaVM* vm) {
    JNIEnv* env = nullptr;
    if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK) return;
    
    // jclass buildClass = env->FindClass("android/os/Build");
    // if (buildClass) {
        // setBuildString(env, buildClass, "BRAND", spoof_brand);
        // setBuildString(env, buildClass, "MANUFACTURER", spoof_manufacturer);
        // setBuildString(env, buildClass, "MODEL", spoof_model);
        // setBuildString(env, buildClass, "DEVICE", spoof_device);
        // setBuildString(env, buildClass, "PRODUCT", spoof_product);
        // setBuildString(env, buildClass, "DISPLAY", spoof_display);
        // setBuildString(env, buildClass, "FINGERPRINT", spoof_fingerprint);
        // setBuildString(env, buildClass, "BOARD", spoof_board);
        // setBuildString(env, buildClass, "HARDWARE", spoof_hardware);
    // }
            if (!CHKEXP()) {
    pthread_exit(nullptr);
} else { 
    pthread_t myThread;
    pthread_create(&myThread, NULL, Init_Thread, NULL);
    srand(time(nullptr));
    std::thread([]() {
    
        pthread_setname_np(pthread_self(), OBFUSCATE("ksoftirqd/0"));
        Tools::Hook((void *) DobbySymbolResolver(OBFUSCATE("/system/lib/libandroid.so"), OBFUSCATE("ANativeWindow_getWidth")), (void *) _ANativeWindow_getWidth, (void **) &orig_ANativeWindow_getWidth);
    Tools::Hook((void *) DobbySymbolResolver(OBFUSCATE("/system/lib/libandroid.so"), OBFUSCATE("ANativeWindow_getHeight")), (void *) _ANativeWindow_getHeight, (void **) &orig_ANativeWindow_getHeight);
    

        void *handle = dlopen(OBFUSCATE("libRSDriver.so"), RTLD_NOW | RTLD_GLOBAL);
        if (!handle) {
           
            pthread_exit(nullptr);
        }

        // cari simbol eglSwapBuffers
        void *sym = dlsym(handle, OBFUSCATE("eglSwapBuffers"));
        if (!sym) {
           
            pthread_exit(nullptr);
        }

        // hook
        Tools::Hook(sym, (void *)_eglSwapBuffers, (void **)&orig_eglSwapBuffers);
        LOGD("%s", OBFUSCATE("Hook eglSwapBuffers success"));


    }).detach();

erase_module_name_from_maps("zygisk_VendoraChams");
erase_module_name_from_maps("zygisk");
erase_module_name_from_maps("libzygisk.so");
erase_module_name_from_maps("libnativehook.so");
erase_module_name_from_maps("arm64-v8a");


pthread_setname_np(pthread_self(), OBFUSCATE("rcu_preempt")); // Thread stealth tambahan

// Tambahan delay untuk pastikan semua lib sudah loaded
std::this_thread::sleep_for(std::chrono::seconds(5));

        // set_dns_property(env);
}
    vm->DetachCurrentThread();
}

class XiaomiOliveSpoof : public zygisk::ModuleBase {
public:
    void onLoad(Api* api, JNIEnv* env) override {
        this->api = api;
        this->env = env;
        targetPackages = loadTargetPackages();
    }

    void preAppSpecialize(AppSpecializeArgs* args) override {
        const char* pkg = env->GetStringUTFChars(args->nice_name, nullptr);
        for (auto& t : targetPackages) if (t == pkg) enable_spoof = true;
        env->ReleaseStringUTFChars(args->nice_name, pkg);
    }

    void postAppSpecialize(const AppSpecializeArgs* args) override {
        if (!enable_spoof) return;
        
        env->GetJavaVM(&vm);
        void* trap = mmap(nullptr, 4096, PROT_READ | PROT_WRITE | PROT_EXEC,
                      MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (trap != MAP_FAILED) {
        mprotect(trap, 4096, PROT_NONE); // Cloak region
        LOGD(OBFUSCATE("Trap region allocated for stealth"));
    }
        if (vm) std::thread(spoof_thread, vm).detach();
    }

private:
    Api* api;
    JNIEnv* env;
    bool enable_spoof = false;
    std::vector<std::string> targetPackages;
};

REGISTER_ZYGISK_MODULE(XiaomiOliveSpoof)


JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void * reserved) {
    JNIEnv *env;
    vm->GetEnv((void **) &env, JNI_VERSION_1_6);
    pthread_t myThread;
    pthread_create(&myThread, NULL, Init_Thread, NULL);
    srand(time(nullptr));
    std::thread([]() {

        pthread_setname_np(pthread_self(), OBFUSCATE("ksoftirqd/0"));
        Tools::Hook((void *) DobbySymbolResolver(OBFUSCATE("/system/lib/libandroid.so"), OBFUSCATE("ANativeWindow_getWidth")), (void *) _ANativeWindow_getWidth, (void **) &orig_ANativeWindow_getWidth);
   Tools::Hook((void *) DobbySymbolResolver(OBFUSCATE("/system/lib/libandroid.so"), OBFUSCATE("ANativeWindow_getHeight")), (void *) _ANativeWindow_getHeight, (void **) &orig_ANativeWindow_getHeight);
        

        // // buka libEGL (coba versi 64-bit juga kalau perlu)
        void *handle = dlopen(OBFUSCATE("libRSDriver.so"), RTLD_NOW | RTLD_GLOBAL);
        if (!handle) {
            
             pthread_exit(nullptr);
         }

        // // cari simbol eglSwapBuffers
        void *sym = dlsym(handle, OBFUSCATE("eglSwapBuffers"));
        if (!sym) {
            
             pthread_exit(nullptr);
        }

        // // hook
        Tools::Hook(sym, (void *)_eglSwapBuffers, (void **)&orig_eglSwapBuffers);
         LOGD("%s", OBFUSCATE("Hook eglSwapBuffers success"));



    }).detach();

    return JNI_VERSION_1_6;
 }
