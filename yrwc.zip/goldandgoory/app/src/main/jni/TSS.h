// Author: Mo Ma
//Join us @ MOYINGMA
// https://t.me/MOYINGMA

#ifndef TSS_SDK_H
#define TSS_SDK_H

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

#if !defined(TP_EXPORT)
#if !defined(__ACE_EXPORT__)
#if defined(_MSC_VER) || defined(__SCE__)
#define TP_EXPORT __declspec(dllexport)
#else
#define TP_EXPORT __attribute__((visibility("default")))
#endif
#else
#define TP_EXPORT
#endif
#endif

#ifdef __cplusplus
class TssInfoReceiver
{
public:
    virtual ~TssInfoReceiver(){}
    virtual int getInterfaceVersionCode(){return 1;}
    virtual void onReceive(int tssInfoType,const char* info) = 0;
};
#endif

#pragma pack(push, 1)

/* anti data info*/
struct TssSdkAntiDataInfo
{
    unsigned short anti_data_len_;   /* [in] length of anti data */
    const unsigned char *anti_data_; /* [in] anti data buffer */
};

struct TssSecSignature
{
    const char *name_;
    const unsigned char *buf_;
    size_t buf_len_;
    uint32_t crc_;
};

/* 发送Anti数据，需由游戏实现 */
/* send anti data, need to be implement by game */
typedef bool (*tss_sdk_send_data_to_svr)(const struct TssSdkAntiDataInfo *anti_data);

struct TssSdkInitInfo
{
    unsigned int size_;                           // struct size
    unsigned int game_id_;                        // game id
    tss_sdk_send_data_to_svr send_data_to_svr_;   // callback interface,implement by game
};

enum TssSdkEntryId
{
    ENTRY_ID_QZONE		= 1,       	// QZone
    ENTRY_ID_MM			= 2,       	// wechat
    ENTRT_ID_FACEBOOK	= 3,		// facebook
    ENTRY_ID_TWITTER	= 4,		// twitter
    ENTRY_ID_LINE		= 5,		// line
    ENTRY_ID_WHATSAPP	= 6,		// whatsapp
    ENTRY_ID_GAMECENTER = 7,		// gamecenter
    ENTRY_ID_GOOGLEPLAY = 8,		// googleplay
    ENTRY_ID_VK			= 9,		// vk
    ENTRY_ID_KUAISHOU	= 10,		// kuaishou
    ENTRY_ID_APPLE		= 11,		// apple
    ENTRY_ID_NEXON		= 12,		// nexon
    ENTRY_ID_NAVER		= 13,		// naver
    ENTRY_ID_GARENA		= 14,		// garena
    ENTRY_ID_HUAWEI		= 15,		// huawei
    ENTRY_ID_RIOT		= 16,		// riot
    ENTRY_ID_NINTENDO   = 17,       // nintendo
    ENTRY_ID_PSN        = 18,       // psn
    ENTRY_ID_MICROSOFT  = 19,       // microsoft
    ENTRY_ID_EA         = 20,       // ea
    ENTRY_ID_CUSTOM     = 21,       // custom
    ENTRY_ID_OTHERS		= 99,		// other platform
};

enum TssSdkUinType
{
    UIN_TYPE_INT = 1, // integer format
    UIN_TYPE_STR = 2, // string format
};

enum TssSdkAppIdType
{
    APP_ID_TYPE_INT = 1, // integer format
    APP_ID_TYPE_STR = 2, // string format
};

struct TssSdkUserInfo
{
    unsigned int size_;      // struct size
    unsigned int entry_id_;  // entrance id, wechat/open platform and so on.
    struct
    {
        unsigned int type_;  // type of uin, refer to TssSdkUinType
        union
        {
            unsigned int uin_int_;   // for integer format uin
            char uin_str_[64];       // for string format uin
        };
    }uin_;

    struct
    {
        unsigned int type_;
        union
        {
            unsigned int app_id_int_;   // for integer format appid
            char app_id_str_[64];       // for string format appid
        };
    }app_id_;
};

struct TssSdkUserInfoEx
{
    unsigned int size_;      // struct size
    unsigned int entry_id_;  // entrance id, wechat/open platform and so on.
    struct
    {
        unsigned int type_;  // type of uin, refer to TssSdkUinType
        union
        {
            unsigned int uin_int_;   // for integer format uin
            char uin_str_[64];       // for string format uin
        };
    }uin_;

    struct
    {
        unsigned int type_;
        union
        {
            unsigned int app_id_int_;   // for integer format appid
            char app_id_str_[64];       // for string format appid
        };
    }app_id_;

    unsigned int world_id_;
    char role_id_[64];
};

enum TssSdkGameStatus
{
    GAME_STATUS_FRONTEND = 1,  // runing in front-end
    GAME_STATUS_BACKEND  = 2,  // runing in back-end
    GAME_STATUS_START_PVP = 3,
    GAME_STATUS_END_PVP = 4,
    GAME_STATUS_UPDATE_FINISHED = 5,
};

struct TssSdkGameStatusInfo
{
    unsigned int size_;        // struct size
    unsigned int game_status_; // running in front-end or back-end
};

enum TssSdkAntiEncryptResult
{
    ANTI_ENCRYPT_OK = 0,
    ANTI_NOT_NEED_ENCRYPT = 1,
};

struct TssSdkEncryptPkgInfo
{
    unsigned int cmd_id_;                     /* [in] game pkg cmd */
    const unsigned char *game_pkg_;           /* [in] game pkg */
    unsigned int game_pkg_len;                /* [in] the length of game data packets, maximum length less than 65,000 */
    unsigned char *encrypt_data_;             /* [in/out] assembling encrypted game data package into anti data, memory allocated by the caller, 64k at the maximum */
    unsigned int encrypt_data_len_;           /* [in/out] length of anti_data when input, actual length of anti_data when output */
};

enum TssSdkAntiDecryptResult
{
    ANTI_DECRYPT_OK = 0,
    ANTI_DECRYPT_FAIL = 1,
};

struct TssSdkDecryptPkgInfo
{
    const unsigned char *encrypt_data_;     /* [in] anti data received by game client */
    unsigned int encrypt_data_len;          /* [in] length of anti data received by game client */
    unsigned char *game_pkg_;               /* [out] buffer used to store the decrypted game package, space allocated by the caller */
    unsigned int game_pkg_len_;             /* [out] input is size of game_pkg_, output is the actual length of decrypted game package */
};

struct TssSetOptsInfo
{
    const char *key;
    bool enable;
    const char *sig;
};

struct TssSetKeyValueInfo
{
    const char *key;
    const char *value;
};

struct TssOpenMTCJTask
{
    const char *path;					//Request the file path of the cloud
    uint8_t ignore_flow_limit;			//Do you want to ignore traffic control options
    uint8_t delete_file_after_upload;	//Do I need to delete the file after the cloud file is successful
    uint32_t unused_1;
    uint32_t unused_2;
    uint32_t unused_3;
    uint32_t unused_4;
};

struct TssWinBrigeTask
{
    void *session;			//WinBridge Session pointer
    const char *cmd;		//Command request
    const char *response;	//Command reply, do not release this member's memory
    uint64_t unused_1;
    uint64_t unused_2;
    uint64_t unused_3;
    uint64_t unused_4;
};

struct TssQueryHookInfo
{
    unsigned long addr;
    unsigned long len;
    bool is_hooked;
    uint64_t unused_1;
    uint64_t unused_2;
    uint64_t unused_3;
    uint64_t unused_4;
};


#pragma pack(pop)

enum TssInfoType
{
    TSS_INFO_TYPE_DETECT_RESULT = 1,
    TSS_INFO_TYPE_HEARTBEAT = 2,
    TSS_INFO_TYPE_EVENT = 3,
    TSS_INFO_TYPE_RECV_STUB = 4,
};


#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief game client calls this interface to set initialization information when game starts
 *
 * @param[in] init_info pointing to data of initialization information, defined in TssSdkInitInfo
 *
 */

TP_EXPORT void tss_sdk_init(const struct TssSdkInitInfo* init_info);

/**
 * @brief game client calls this interface to set user information when login in game
 *
 * @param[in] user_info pointing to data of initialization information, defined in TssSdkUserInfo
 *
 * @warning: this interface is expired, call tss_sdk_setuserinfo_ex instead
 *
 */
TP_EXPORT void tss_sdk_setuserinfo(const struct TssSdkUserInfo* user_info);


/**
 * @brief game client calls this interface to set user information when login in game
 *
 * @param[in] user_info pointing to data of initialization information, defined in TssSdkUserInfo
 *
 */
TP_EXPORT void tss_sdk_setuserinfo_ex(const struct TssSdkUserInfoEx* user_info);


/**
 * @brief game client calls this interface to set user information and license when login in game
 *
 * @param[in] entry_id, use the value in TssSdkEntryId
 * @param[in] open_id, user identification
 * @param[in] license, transfer from svr to game client
 *
 */
TP_EXPORT void tss_sdk_setuserinfo_with_license(int entry_id, const char *open_id, const char* license);

/**
 * @brief game client calls this interface to notify the security component game's current status
 *
 * @param[in] game_status if game running in front-end, set it to GAME_STATUS_FRONTEND, if game running in back-end, set it to GAME_STATUS_BACKEND
 */

TP_EXPORT void tss_sdk_setgamestatus(const struct TssSdkGameStatusInfo* game_status);

/**
* @brief Game client calls this interface as soon as receives anti packets from game server
*
* @param[in] anti_data Pointing to anti data, defined in TssSdkAntiDataInfo
*
*/
TP_EXPORT void tss_sdk_rcv_anti_data(const struct TssSdkAntiDataInfo *anti_data);

/**
* @brief Game client calls this interface to encrypt game's packets
*
* @param[in] encrypt_pkg_info Pointing to game's packets need encrypting, defined in ENCRYPTPKGINFO
*
* @return refer to the definition of TssSdkAntiEncryptResult.
*/
TP_EXPORT enum TssSdkAntiEncryptResult tss_sdk_encryptpacket(struct TssSdkEncryptPkgInfo *encrypt_pkg_info);

/**
* @brief Game client calls this interface as soon as receives anti packets from game server
*
* @param[in] decrypt_pkg_info Pointing to game's packets need decrypting, defined in DECRYPTPKGINFO
*
* @return refer to the definition of TssSdkAntiDecryptResult
*/
TP_EXPORT enum TssSdkAntiDecryptResult tss_sdk_decryptpacket(struct TssSdkDecryptPkgInfo *decrypt_pkg_info);

/**
* @brief Game client calls this interface as soon as receives game packets from game server
*
* @param[in] cmd_id Pointing to game's packets cmd
*
* @return If return 0, game client does nothing, if return 1, game client needs to discard this packet.
*/
TP_EXPORT bool tss_sdk_ischeatpacket(const unsigned int cmd_id);

/**
 * @brief Game client calls this interface to retrieve a TssSdkAntiDataInfo struct data
 * [support arm64]
 */
TP_EXPORT uintptr_t tss_get_report_data();

/**
 * @brief Game client calls this interface to release a TssSdkAntiDataInfo struct data which return by tss_get_report_data interface
 */
TP_EXPORT void tss_del_report_data(struct TssSdkAntiDataInfo *data);


TP_EXPORT void tss_enable_get_report_data();


TP_EXPORT void tss_log_str(const char *str);

/**
 * Explanation: The game interacts with TssSdk by calling the tss_sdk_ioctl interface in a manner similar to the ioctl function
 *
 * @request -- Command word, type TssSdkRequestCMDID
 * @param -- Specify the input parameters corresponding to the command word
 * @buf -- Specify the buffer corresponding to the command word for storing the output results
 * @buf_size -- Corresponding to the size of buf
 *
 * Return value: Depending on the command word, it has different meanings
 *
 *
 * TssSdkCmd_GetSdkAntiData:
 *
 * @brief -- Used to obtain the data generated during TssSdk initialization. Generally, games call this interface to obtain TssSdk initialization data when the user logs in or when the game starts,
 * Then the game is responsible for transferring the data to the server's TssSdk or security logs. The game doesn't need to worry about the content of the data retrieved, just complete the transfer.
 * @Request buff size -- 1024
 * @Return value  0: Success -1: Failure
 *
 * TssSdkCmd_RegistSdkEventListener：
 *
 * @brief -- This command is reserved as a command word for TssSdk, please do not call it in the game
 * @Return value  0: Success -1: Failure
 *
 * TssSdkCmd_IsAppOnForeground:
 *
 * @brief -- Used to determine whether the game is in the foreground
 * @Return value -- 1: At the front desk 0: At the back desk
 *
  * TssSdkCmd_GetCommLibValueByKey:
 *
 * @brief -- Retrieve key value pair information saved in comm.dat
 * @返回值 -- Given the value of the key
 *
 * TssSdkCmd_GetShellDyMagicCode:
 *
 * @brief -- Obtain the dynamic magic code injected into libtersafe.so by the shell adding system during the shell adding process
 * @Return value -- -1: Cannot support 0 or 123: Magic code not entered Other (such as MMDDHHmm): Magic code
 *
 * TssSdkCmd_AddMTCJTask
 *
 * @brief -- Add cloud search task
 * @param -- Pointer to the TssOpenMTCJTask structure
 * @Return value 0: Success, other failures
 *
 * eg.
 *
 * TssOpenMTCJTask task = {0};
 *		task.path = "/sdcard/sdk/enable.log";
 *		task.delete_file_after_upload = 0;
 *		task.ignore_flow_limit = 1;
 *
 *		int err = tss_sdk_ioctl(TssSdkCmd_AddMTCJTask, &task, NULL, 0, NULL);
 *		if (err != 0) {
 *			// ..
 *		}
 *
 *	TssSdkCmd_IsEmulator
 *
 *		@brief -- Determine whether it is a simulator
 *		@param -- const char *, key:value|key:value ... Formal string
 *		@buf -- Buf used to store emulator names
 *		@buf_size -- The size of the buf used to store emulator names
 *		@used_buf_len -- The buf length used can be NULL
 *
 *		@Return value -1: emulator, emulator name in buf, 0: not emulator, -1: not supported
 *
 *
 *	TssSdkCmd_GameScreenshot2
 *
 *		@brief -- Add screenshot task
 *		@param -- Corresponding to the MrpcsScreenShotTask structure pointer, please note that only ignore_performance, ignore_flow, and extra_maram will be used in this structure
 *		@retval -- Return value: 0 success, -1 failure
 *
 *		eg
 *
 *		MrpcsScreenShotTask task = {0};
 *		task.ignore_performance = true;	//Do you ignore performance
 *		task.ignore_flow = true;		//Do you want to ignore traffic restrictions
 *		task.extra_param = extra_param;
 *
 *		int err = tss_sdk_ioctl(TssSdkCmd_GameScreenshot2, &task, NULL, 0, NULL);
 *		if (err != 0) {
 *			// ..
 *		}
 *
 *	TssSdkCmd_SetToken
 *	    @brief -- This command word is reserved internally for the single machine protection scheme function interface. Please do not use it directly. If you need to use it, please use the tss_sdk_set_token interface
 *	    @Return value 0 is success, -2 is failure
 *
 *	TssSdkCmd_GenSessionData
 *	    @brief -- This keyword is a function interface keyword for single machine protection solutions. Please do not use it directly. If you need to use it, please use the tss_sdk_gen_dession_data interface
 *	    @Return value 0 is success, -2 is failure
 *
 *	TssSdkCmd_WaitVerify
 *	    @brief -- This keyword is a single machine protection scheme function interface keyword. Please do not use it directly. If you need to use it, please use the tss_sdk_wait-verify interface
 *	    @Return value 0 for success, -1 for failure
 *
 *	TssSDKCmd_CommQuery
 *		@brief -- Universal interface, using string commands to query and return results
 *		@The return value 0 is success, -1 is failure. When successful, the result will be stored in the buf parameter
 *
 * TssSDKCmd_Logout
 * @brief -- Log out interface, called when logging out of the game. After calling, the security SDK no longer sends any data, and the report_data2 interface is still available
 * @Return value 0 for success, -1 for failure
 *
 * TssSDKCmd_InitSwitchStr
 * @brief -- Switch initialization interface. Called before initializing the SDK.
 * @param -- const char*, socket={0}|nn_ro={1}|curl={2}|cache={3}|cache_id={4}|cache_name={5}
 * Fill in 1 or 0 from {0} to {3} to indicate whether the corresponding library has been initialized. {4} Fill in as needed with {5}. Do not use other parameters, just fill in 0.
 * @retval -- 0: Success, -1: Failure
 *
 */
enum TssSdkRequestCmdID
{
    TssSdkCmd_GetSdkAntiData = 1,
    TssSdkCmd_RegistSdkEventListener = 2,
    TssSdkCmd_IsAppOnForeground = 3,
    TssSdkCmd_GameScreenshot = 4,
    TssSdkCmd_InvokeCrashFromShell = 5,
    TssSdkCmd_GetCommLibValueByKey = 6,
    TssSdkCmd_GetShellDyMagicCode = 7,
    TssSdkCmd_AddMTCJTask = 8,
    TssSdkCmd_GameScreenshot2 = 9,
    TssSdkCmd_IsEmulator = 10,
//    TssSdkCmd_SetToken = 11,
//    TssSdkCmd_GenSessionData = 12,
//    TssSdkCmd_WaitVerify = 13,
    TssSdkCmd_QueryTssSdkVer = 14,
    TssSdkCmd_EnableDisableItem = 15,
    TssSdkCmd_QueryOpts = 16,
    TssSdkCmd_ReInitMrpcs = 17,
    TssSDKCmd_CommQuery = 18,
    TssSDKCmd_OpenWBSession = 19,
    TssSDKCmd_SendWBCmd = 20,
    TssSDKCmd_ReleaseWBStrPool = 21,
    TssSDKCmd_CloseWBSession = 22,
    TssSDKCmd_GetUserTag = 23,
    TssSDKCmd_QueryTssLibcAddr = 24,
    TssSDKCmd_RegistLibcSendListener = 25,
    TssSDKCmd_RegistLibcRecvListener = 26,
    TssSDKCmd_RegistLibcConnectListener = 27,
    TssSDKCmd_GetMrpcsData2Ptr = 28,
    TssSDKCmd_GetTPChannelVer = 29,
    TssSDKCmd_SetGameChannelIp = 30,
    TssSDKCmd_SetValueByKey = 31,
    TssSDKCmd_SetChannelHost = 32,
    TssSDKCmd_SetChannelBuiltinIp = 33,
    TssSDKCmd_RecvSecSignature = 34,
    TssSDKCmd_PushAntiData3 = 35,
    TssSDKCmd_QueryRemainsAntiDataCount = 36,
    TssSDKCmd_GetAntiData3 = 37,
    TssSDKCmd_DelAntiData3 = 38,
    TssSDKCmd_SetSecToken = 39,
    TssSDKCmd_GetThreadsInfo = 40,
    TssSDKCmd_RegistLibcCloseListener = 41,
    TssSDKCmd_Logout = 42,
    TssSDKCmd_AddTouchEvent = 44,
    TssSDKCmd_InitSwitchStr = 45,
    TssSDKCmd_SetCDNHost = 46,
    TssSDKCmd_SetEnabledConnector = 47,
    TssSDKCmd_QueryHookInfo = 48,
    TssSDKCmd_SetCSLicense = 49,
    TssSDKCmd_AddAnoTouchEvent = 50,
    TssSDKCmd_GetObjVMFuncAddr = 51,
    TssSDKCmd_UnusualPlayerBehavior = 52,
    TssSDKCmd_NetworkAnomalyDetection = 53,
    TssSDKCmd_AIBasedCheatDetection = 54,
    TssSDKCmd_TimeManipulationDetection = 55,
    TssSDKCmd_UnauthorizedDataInjection = 56,
    TssSDKCmd_AccountRecoveryAbuse = 57,
    TssSDKCmd_AdvancedAimbotDetection = 58,
    TssSDKCmd_ReplayDataAnalysis = 59,
    TssSDKCmd_CrossPlatformCheatPrevention = 60,
    TssSDKCmd_AntiBottingMeasures = 61
};

TP_EXPORT int tss_sdk_ioctl(int request, const void *param, /*[out]*/char *buf, size_t buf_size, /*[out]*/size_t *used_buf_len);

#ifndef TP_MAX_SESSION_DATA_SIZE
#define TP_MAX_SESSION_DATA_SIZE 4096
#endif
/* Explanation: The following is the interface for the single machine protection scheme
 * @brief
 * Block waiting for verification Note that validation will not be completed before calling setToken.
 *
 * @param timeout The longest waiting time, in milliseconds, if set to 0, will be infinite.
 *
 * @return
*1. Verification failed
*0 verification passed
*-1 verification timeout
*-2 did not receive the token
*-3 Insufficient memory
 */
TP_EXPORT int32_t tss_sdk_wait_verify(uint32_t timeout);


/*
 * Attention: This interface is not thread safe!
 *
 * @brief
 * Generate session data
 *
 * @param[out] buff Pass in an empty buff to receive session data. Please upload the received session data to the server for token generation
 * @param[in] buff_size  Enter the size of the buff
 *
 * @return
 * >=0 Return the length of session_data
 * -1 Not logged in
 * -2 parameter error
 */
TP_EXPORT int32_t tss_sdk_gen_session_data(uint8_t *buff, size_t buff_size);

/*
 * @brief
 * Pass the token returned by the server to the verification module.
 *
 * @param[in] token Token returned by the server
 * @param[in] n     Token length
 *
 * @return
 * 0 成功
 * -1 没有生成session_data
 * -2 内存不足
 *
 */
TP_EXPORT int32_t tss_sdk_set_token(const uint8_t *token, size_t n);



/**
 * To obtain TssSDK, data needs to be transferred to TssSvrSDK through game hosting
 *
 * This interface is recommended to be called at the following time points and merged into the buffer of the game's own protocol, and then passed to the TssSvrSDK
 * 1.When the user logs in
 * 2.At the beginning of the game
 * 3.During game settlement
 */
TP_EXPORT uintptr_t tss_get_report_data2();

/**
 * To obtain TssSDK, data needs to be transmitted through the game battle server
 * This interface is recommended to be called during game battles and merged into the Buffer of the game's own battle protocol, and then uploaded through methods such as tlog
 */
TP_EXPORT uintptr_t tss_get_report_data3();

/**
 * The game client calls this interface to release the data obtained from the tss_get_report_data3 interface after sending it
 */
TP_EXPORT void tss_del_report_data3(struct TssSdkAntiDataInfo *data);

/**
 * Light features obtained from transparent games
 */
TP_EXPORT int tss_recv_sec_signature(const char* name, const unsigned char *buf, uint32_t buf_len, uint32_t crc);

#ifdef __cplusplus
/**
 * Register as an MTP information subscriber
 *
 * Note: This interface can only be called before tss_sdk_init
 */
 TP_EXPORT void tss_sdk_regist_tss_info_receiver(TssInfoReceiver* receiver);
#endif

/*
 * Decrypt the string received by TssInfoReceiver's onReceive
 */
TP_EXPORT int tss_sdk_dec_tss_info(const char* src,char* out,size_t len);

enum TP2GameStatus
{
    TP2_GAME_STATUS_FRONTEND = 1,  // reception
    TP2_GAME_STATUS_BACKEND  = 2,  // backend
};
/**
 * MTP interface compatibility, the following interfaces are only compatible with TP1 interface and will not be transferred as upgrade interfaces
 */
TP_EXPORT int tp2_sdk_init(int app_id);
TP_EXPORT int tp2_sdk_init_ex(int app_id, const char* app_key);
TP_EXPORT int tp2_setuserinfo(int account_type, int world_id, const char *open_id, const char *role_id);
TP_EXPORT int tp2_setuserinfowithlicense(int account_type, int world_id, const char *open_id, const char *role_id, const char* license);
TP_EXPORT int tp2_getver(char *ver_buf, size_t buf_size);
TP_EXPORT int tp2_setoptions(int options);
TP_EXPORT int tp2_setgamestatus(int status);
TP_EXPORT uintptr_t tp2_sdk_ioctl(int request, const char *param_str);
TP_EXPORT int tp2_free_anti_data(struct TssSdkAntiDataInfo *data);
TP_EXPORT int tp2_dec_tss_info(const char* src,char* out,size_t len);

#ifdef __cplusplus
TP_EXPORT void tp2_regist_tss_info_receiver(TssInfoReceiver* receiver);
}
#endif


#endif /* TSS_SDK_H */