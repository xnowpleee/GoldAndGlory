#define HOOK(ret, func, ...) \
    ret (*orig##func)(__VA_ARGS__); \
    ret my##func(__VA_ARGS__)

HOOK(void, Input, void *thiz, void *ex_ab, void *ex_ac) { 
    origInput(thiz, ex_ab, ex_ac);
ImGui_ImplAndroid_HandleInputEvent((AInputEvent *)thiz);
    return;
}



int as = 0;

uintptr_t address = 0;
uintptr_t touuu;
uintptr_t tto;
struct UnityEngine_Vector2_Fields {
    float x;
    float y;
};

struct UnityEngine_Vector2_o {
    UnityEngine_Vector2_Fields fields;
};


enum TouchPhase : int {
    Began = 0,
    Moved = 1,
    Stationary = 2,
    Ended = 3,
    Canceled = 4,
};



struct UnityEngine_Touch_Fields {
    int32_t m_FingerId;
    Vector2 m_Position;
    Vector2 m_RawPosition;
    Vector2 m_PositionDelta;
    float m_TimeDelta;
    int32_t m_TapCount;
    int32_t m_Phase;
    int32_t m_Type;
    float m_Pressure;
    float m_maximumPossiblePressure;
    float m_Radius;
    float m_RadiusVariance;
    float m_AltitudeAngle;
    float m_AzimuthAngle;
};

// ========== Offsets ==============
#define Input_GetTouch        (uintptr_t) Il2CppGetMethodOffset("UnityEngine.InputLegacyModule.dll", "UnityEngine", "Input", "GetTouch", 1)
#define Input_get_touchCount  (uintptr_t) Il2CppGetMethodOffset("UnityEngine.InputLegacyModule.dll", "UnityEngine", "Input", "get_touchCount",0)
#define Input_get_mousePosition (uintptr_t) Il2CppGetMethodOffset("UnityEngine.InputLegacyModule.dll", "UnityEngine", "Input", "get_mousePosition",0)
static int (*orig_get_touchCount)(void* instance);
static Vector2 (*orig_get_mousePosition)(void* instance);
static UnityEngine_Touch_Fields (*orig_GetTouch)(void* instance, int index);

int my_get_touchCount(void* instance) {
    return orig_get_touchCount(instance);
}
Vector2 my_get_mousePosition(void* instance) {
    return orig_get_mousePosition(instance);
}
UnityEngine_Touch_Fields my_GetTouch(void* instance, int index) {
    UnityEngine_Touch_Fields touch = orig_GetTouch(instance, index);

    ImGuiIO& io = ImGui::GetIO();
    float reverseY = io.DisplaySize.y - touch.m_Position.y;

    switch (touch.m_Phase) {
    
        case TouchPhase::Began:
            io.MouseDown[0] = true;            
            io.MousePos = ImVec2(touch.m_Position.x, reverseY);
            break;

        case TouchPhase::Moved:
        case TouchPhase::Stationary:
            io.MouseDown[0] = true;
            io.MousePos = ImVec2(touch.m_Position.x, reverseY);
            break;

        case TouchPhase::Ended:
        case TouchPhase::Canceled:
            io.MouseDown[0] = false;  
            io.MousePos = ImVec2(touch.m_Position.x, reverseY);
            break;
    }

    return touch; 
}
void InitHooks() {
    Tools::Hook((void*)Input_get_touchCount, (void*)my_get_touchCount, (void**)&orig_get_touchCount);
    Tools::Hook((void*)Input_get_mousePosition, (void*)my_get_mousePosition, (void**)&orig_get_mousePosition);
    Tools::Hook((void*)Input_GetTouch, (void*)my_GetTouch, (void**)&orig_GetTouch);
}
