#pragma once
#include <android/log.h>
#define LOG_TAG "vendora"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define HOOK(ret, func, ...) \
    ret (*orig##func)(__VA_ARGS__); \
    ret my##func(__VA_ARGS__)

HOOK(void, Input, void *thiz, void *ex_ab, void *ex_ac) { 
    origInput(thiz, ex_ab, ex_ac);
ImGui_ImplAndroid_HandleInputEvent((AInputEvent *)thiz);
    return;
}


int (*Screen_get_height)();
int (*Screen_get_width)();

int (*o_inject_event)(JNIEnv *env, jobject thiz, jobject inputEvent);
int hook_input(JNIEnv *env, jobject __this, jobject input_event) {
    ImGuiIO &io = ImGui::GetIO();
    
    jclass motionEventClass = env->FindClass(OBFUSCATE("android/view/MotionEvent"));
    
    if (env->IsInstanceOf(input_event, motionEventClass)) {
        jmethodID getActionMethod = env->GetMethodID(motionEventClass, OBFUSCATE("getAction"), OBFUSCATE("()I"));
        jint getAction = env->CallIntMethod(input_event, getActionMethod);
        
        jmethodID getXMethod = env->GetMethodID(motionEventClass, OBFUSCATE("getX"), OBFUSCATE("()F"));
        jfloat getX = env->CallFloatMethod(input_event, getXMethod);
        
        jmethodID getYMethod = env->GetMethodID(motionEventClass, OBFUSCATE("getY"), OBFUSCATE("()F"));
        jfloat getY = env->CallFloatMethod(input_event, getYMethod);
        
        jmethodID getPointerCountMethod = env->GetMethodID(motionEventClass, OBFUSCATE("getPointerCount"), OBFUSCATE("()I"));
        jint getPointerCount = env->CallIntMethod(input_event, getPointerCountMethod);
        
        switch(getAction) {
            
        case 0:
            io.MouseDown[0] = true;
            break;
        case 1:
            io.MouseDown[0] = false;
            break;
        case 2:
            if (getPointerCount > 1) {
                io.MouseDown[0] = false;
            } else {
                io.MouseWheel = 0;
            }
            break;
        }
        io.MousePos = ImVec2(getX, getY);
    }
    
    jclass KeyEventClass = env->FindClass(OBFUSCATE("android/view/KeyEvent"));
    if (env->IsInstanceOf(input_event, KeyEventClass)) {
        jmethodID getActionMethod = env->GetMethodID(KeyEventClass, OBFUSCATE("getAction"), OBFUSCATE("()I"));
        if (env->CallIntMethod(input_event, getActionMethod) == 0) {
            jmethodID getKeyCodeMethod = env->GetMethodID(KeyEventClass, OBFUSCATE("getKeyCode"), OBFUSCATE("()I"));
            jmethodID getUnicodeCharMethod = env->GetMethodID(KeyEventClass, OBFUSCATE("getUnicodeChar"), OBFUSCATE("(I)I"));
            jmethodID getMetaStateMethod = env->GetMethodID(KeyEventClass, OBFUSCATE("getMetaState"), OBFUSCATE("()I"));
            
            jint keyCode = env->CallIntMethod(input_event, getKeyCodeMethod);
            io.AddInputCharacter(env->CallIntMethod(input_event, getUnicodeCharMethod, env->CallIntMethod(input_event, getMetaStateMethod)));
        }
	}
    
    return o_inject_event(env, __this, input_event);
}
int32_t (*orig_ANativeWindow_getWidth)(ANativeWindow* window);
int32_t _ANativeWindow_getWidth(ANativeWindow* window) {
	screenWidth = orig_ANativeWindow_getWidth(window);
	return orig_ANativeWindow_getWidth(window);
}

int32_t (*orig_ANativeWindow_getHeight)(ANativeWindow* window);
int32_t _ANativeWindow_getHeight(ANativeWindow* window) {
	screenHeight = orig_ANativeWindow_getHeight(window);
	return orig_ANativeWindow_getHeight(window);
}

void (*SetResolution)(int width, int height, bool fullscreen);
int Width, Height;
bool level50 = false;
static bool EnableESP = false;
static bool ESPLine = true;
static bool ESPBox = false;
static bool ESPLine1 = false;
static bool ESPBox1 = false;
float g_CameraFov = 10.0f;   
bool FovEnabled = false;     
static bool SetSightt = false;
bool InvisibleTest = false;
#pragma once



static bool drawinfo = true;




bool (*get_IsVisible)(void*) = nullptr;
bool (*get_IsDead)(void*) = nullptr;
bool (*get_IsMine)(void*) = nullptr;
std::vector<void*> players;
std::vector<void*> monsters;
void* myPlayer = nullptr;

Vector3 (*WorldToScreenPoint)(void* instance, Vector3);
Vector3 (*Transform_get_position)(void* instance);
void* (*get_main)();
void* (*get_transform)(void* instance);
void (*Transform_set_localScale)(void *transform, Vector3);

void (*old_PlayerUpdate)(void* player, float g, float t); 

// --- Helper Functions ---
Vector3 getPosition(void* player) {
    if (!player) return Vector3();
    void* t = get_transform(player);
    if (!t) return Vector3();
    return Transform_get_position(t);
}
uintptr_t offset_monsterRecord = 0;
void* getMonsterNameMethod = nullptr;
void* isMonsterDeadMethod  = nullptr;
bool IsMonsterDead(void* monster) {
    if (!monster || !isMonsterDeadMethod) return true;
    auto fn = (bool(*)(void*))isMonsterDeadMethod;
    return fn(monster);
}
bool IsPlayerDead(void* player) {
    if (player == NULL) return true;
    bool (*_get_IsDead)(void*) = (bool(*)(void*))get_IsDead;
    return _get_IsDead(player);
}
bool IsPlayerVisible(void* player) {
    if (player == NULL) return false;  
    bool (*_get_IsVisible)(void*) = (bool(*)(void*))get_IsVisible;
    return _get_IsVisible(player);
}

float GetDistance(Vector3 a, Vector3 b) {
    return sqrtf(
        powf(b.x - a.x, 2) +
        powf(b.y - a.y, 2) +
        powf(b.z - a.z, 2)
    );
}


ImVec4 GetColorByDistance(float distance) {
    if (distance < 10.0f) return ImVec4(1.0f, 0.0f, 0.0f, 1.0f); // Red (close)
    if (distance < 30.0f) return ImVec4(1.0f, 1.0f, 0.0f, 1.0f); // Yellow (medium)
    return ImVec4(0.0f, 1.0f, 0.0f, 1.0f); // Green (far)
}

// --- Player Management ---
#include <algorithm>
#include <vector>


// Cek apakah player ada
inline bool HasPlayer(void* pl) {
    return pl != nullptr && std::find(players.begin(), players.end(), pl) != players.end();
}

// Hapus player dari list
inline void RemovePlayer(void* pl) {
    if (pl != nullptr) {
        players.erase(std::remove(players.begin(), players.end(), pl), players.end());
    }
}

// Bersihkan player yang nullptr
inline void ClearPlayers() {
    players.erase(std::remove(players.begin(), players.end(), nullptr), players.end());
}
#include <vector>
#include <algorithm>

uintptr_t offset_isLocal = 0;

void InitOffsets() {
    offset_isLocal = Il2CppGetFieldOffset(
        OBFUSCATE("KradGame.dll"), 
        OBFUSCATE("KradGame"), 
        OBFUSCATE("PresentCharacter"), 
        OBFUSCATE("_isLocalEntity")
    );
}

bool IsLocalEntity(void* player) {
    if (!player || !offset_isLocal) return false;
    return *(bool*)((uintptr_t)player + offset_isLocal);
}
bool enebleentiity = false;
float isLocalPlayerSize;

//-----------HOOKING------------//



void SetPlayerSize(void *transform, Vector3 scale)
{
    return Transform_set_localScale(get_transform(transform), scale);
}

// --- Pointers ke fungsi Il2Cpp ---

void (*Transform_set_position)(void*, Vector3) = nullptr;

// Inisialisasi fungsi

// --- Method pointer get_localScale ---
Vector3 (*Transform_get_localScale)(void* transform);


// Logic high jump
// Global

static float jumpPower = 7.0f;
// Hook

Vector3 getLocalScale(void* instance) {
    void* t = get_transform(instance);
    
    return Transform_get_localScale(t);
}
void SetPlayerPosition(void* player, Vector3 pos) {

    void* t = get_transform(player);

    Transform_set_position(t, pos);
}



bool highJump = false;
bool highJump2 = false;
bool highJump3 = false;
void (*orig_PlayJumpStart)(void* instance);
void hk_PlayJumpStart(void* instance) {
    orig_PlayJumpStart(instance);
            if (IsLocalEntity(instance)) {
        if (highJump) {
    Vector3 pos = getPosition(instance);
    pos.y += jumpPower;
    SetPlayerPosition(instance, pos);
}
}

}
void* (*orig_JumpSmooth)(void* instance, Vector3 jumpVelocity);

void* hk_JumpSmooth(void* instance, Vector3 jumpVelocity) {
    if (highJump2) {
        jumpVelocity.y *= jumpPower;
    }
    return orig_JumpSmooth(instance, jumpVelocity);
}

void Install_JumpSmoothHook() {
    void* addr = (void*)Il2CppGetMethodOffset(
        OBFUSCATE("RootMotion.dll"),
        OBFUSCATE("RootMotion.Demos"),
        OBFUSCATE("CharacterThirdPerson"),
        OBFUSCATE("JumpSmooth"),
        1
    );
    if (addr) {
        Tools::Hook(addr, (void*)hk_JumpSmooth, (void**)&orig_JumpSmooth);
    }
}


void InitPlayJumpStartHook() {
   Install_JumpSmoothHook();
    void* method = Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame"),
        OBFUSCATE("PresentCharacter"),
        OBFUSCATE("PlayJumpStart"),
        0
    );

    if (method) {
        Tools::Hook((void*)method, (void*)hk_PlayJumpStart, (void**)&orig_PlayJumpStart);
    }
}

void InitTransforms() {
    InitOffsets();
    InitPlayJumpStartHook();
    Transform_get_localScale = (Vector3 (*)(void*)) Il2CppGetMethodOffset(
        OBFUSCATE("UnityEngine.CoreModule.dll"),
        OBFUSCATE("UnityEngine"),
        OBFUSCATE("Transform"),
        OBFUSCATE("get_localScale"),
        0
    );

    Transform_set_localScale = (void (*)(void*, Vector3)) Il2CppGetMethodOffset(
        OBFUSCATE("UnityEngine.CoreModule.dll"),
        OBFUSCATE("UnityEngine"),
        OBFUSCATE("Transform"),
        OBFUSCATE("set_localScale"),
        1
    );

    Transform_set_position = (void (*)(void*, Vector3)) Il2CppGetMethodOffset(
        OBFUSCATE("UnityEngine.CoreModule.dll"),
        OBFUSCATE("UnityEngine"),
        OBFUSCATE("Transform"),
        OBFUSCATE("set_localPosition"),
        1
    );

}



float followSpeed = 1.0f;

void FollowTarget(void* localPlayer, void* target) {
    if (!localPlayer || !target) return;

    // Ambil posisi target
    Vector3 targetPos = getPosition(target);

    // Langsung teleport
    SetPlayerPosition(localPlayer, targetPos);
}

// --- PlayerUpdate Hook ---
// --- Variable untuk toggle teleport ---
bool instantFollow = false;
// --- Pointer untuk LogicId ---
// ======================= GLOBAL VARIABEL =========================

// -------------------------------------------
// Item Hook System (Stealth + Duplication + No Durability Loss)
// -------------------------------------------

namespace Draw {
    void DrawLine(ImVec2 start, ImVec2 end, ImVec4 color, float thickness = 1.0f) {
        auto background = ImGui::GetBackgroundDrawList();
        if (background) {
            background->AddLine(start, end, ImColor(color.x, color.y, color.z, color.w), thickness);
        }
    }

    void DrawCircle(float X, float Y, float radius, bool filled, ImVec4 color) {
        auto background = ImGui::GetBackgroundDrawList();
        if (background) {
            if (filled) {
                background->AddCircleFilled(ImVec2(X, Y), radius, ImColor(color.x, color.y, color.z, color.w));
            } else {
                background->AddCircle(ImVec2(X, Y), radius, ImColor(color.x, color.y, color.z, color.w));
            }
        }
    }

    void DrawBox(Rect rect, ImVec4 color) {
        ImVec2 v1(rect.x, rect.y);
        ImVec2 v2(rect.x + rect.width, rect.y);
        ImVec2 v3(rect.x + rect.width, rect.y + rect.height);
        ImVec2 v4(rect.x, rect.y + rect.height);

        DrawLine(v1, v2, color);
        DrawLine(v2, v3, color);
        DrawLine(v3, v4, color);
        DrawLine(v4, v1, color);
    }
    
    
    void DrawText(float fontSize, ImVec2 position, ImVec4 color, const char* text) {
        auto background = ImGui::GetBackgroundDrawList();
        if (background) {
            background->AddText(NULL, fontSize, position, ImColor(color.x, color.y, color.z, color.w), text);
        }
    }
    
    void Draw3DBox(Vector3 top, Vector3 bottom, float width, ImVec4 color) {
        auto background = ImGui::GetBackgroundDrawList();
        if (!background) return;

        // Half width
        float half = width * 0.5f;

        // Delapan titik cube (4 atas, 4 bawah)
        Vector3 corners3D[8] = {
            {top.x - half, top.y, top.z - half},   // 0: top front left
            {top.x + half, top.y, top.z - half},   // 1: top front right
            {top.x + half, top.y, top.z + half},   // 2: top back right
            {top.x - half, top.y, top.z + half},   // 3: top back left
            {bottom.x - half, bottom.y, bottom.z - half}, // 4: bottom front left
            {bottom.x + half, bottom.y, bottom.z - half}, // 5: bottom front right
            {bottom.x + half, bottom.y, bottom.z + half}, // 6: bottom back right
            {bottom.x - half, bottom.y, bottom.z + half}  // 7: bottom back left
        };

        ImVec2 projected[8];
        bool valid[8];

        // WorldToScreen untuk semua titik
        for (int i = 0; i < 8; i++) {
            Vector3 screenPos = WorldToScreenPoint(get_main(), corners3D[i]);
            if (screenPos.z > 0.1f) {
                projected[i] = ImVec2(screenPos.x, glHeight - screenPos.y);
                valid[i] = true;
            } else {
                valid[i] = false;
            }
        }

        // Helper lambda buat gambar garis
        auto line = [&](int a, int b) {
            if (valid[a] && valid[b]) {
                background->AddLine(projected[a], projected[b],
                    ImColor(color.x, color.y, color.z, color.w), 1.5f);
            }
        };

        // Sambung top square
        line(0, 1); line(1, 2); line(2, 3); line(3, 0);
        // Sambung bottom square
        line(4, 5); line(5, 6); line(6, 7); line(7, 4);
        // Sambung vertikal
        line(0, 4); line(1, 5); line(2, 6); line(3, 7);
    }
}



    // Init field & method
    
    
__attribute__((visibility("hidden")))
void DrawChest3DBox(void* chest, ImVec4 color) {
    if (!chest) return;

    void* mainInstance = get_main();
    if (!mainInstance) return;

    Vector3 pos = getPosition(chest);
    Vector3 scale = getLocalScale(chest); // Ambil scale chest

    // Half extents dari scale
    float halfX = scale.x;
    float halfY = scale.y;
    float halfZ = scale.z;

    // 8 titik cube
    Vector3 corners[8] = {
        {pos.x - halfX, pos.y + halfY, pos.z - halfZ}, // top front left
        {pos.x + halfX, pos.y + halfY, pos.z - halfZ}, // top front right
        {pos.x + halfX, pos.y + halfY, pos.z + halfZ}, // top back right
        {pos.x - halfX, pos.y + halfY, pos.z + halfZ}, // top back left
        {pos.x - halfX, pos.y - halfY, pos.z - halfZ}, // bottom front left
        {pos.x + halfX, pos.y - halfY, pos.z - halfZ}, // bottom front right
        {pos.x + halfX, pos.y - halfY, pos.z + halfZ}, // bottom back right
        {pos.x - halfX, pos.y - halfY, pos.z + halfZ}  // bottom back left
    };

    ImVec2 projected[8];
    bool valid[8];

    // WorldToScreen semua titik
    for (int i = 0; i < 8; i++) {
        Vector3 screenPos = WorldToScreenPoint(mainInstance, corners[i]);
        if (screenPos.z > 0.1f) {
            projected[i] = ImVec2(screenPos.x, glHeight - screenPos.y);
            valid[i] = true;
        } else {
            valid[i] = false;
        }
    }

    auto drawLine = [&](int a, int b) {
        if (valid[a] && valid[b]) {
            ImGui::GetBackgroundDrawList()->AddLine(
                projected[a], projected[b], ImColor(color.x, color.y, color.z, color.w), 1.5f
            );
        }
    };

    // Sambung top
    drawLine(0, 1); drawLine(1, 2); drawLine(2, 3); drawLine(3, 0);
    // Sambung bottom
    drawLine(4, 5); drawLine(5, 6); drawLine(6, 7); drawLine(7, 4);
    // Sambung vertikal
    drawLine(0, 4); drawLine(1, 5); drawLine(2, 6); drawLine(3, 7);
}

// --- Aimbot Config ---
bool AimBotVisual   = true;       
bool aimbotV1       = false;
bool silent         = true;
bool multi       = false;
float AimFovRadius  = 150.0f;    
bool ShowFovCircle  = true;      
bool ShowAimLine    = true;      
float AimSmoothing  = 1.0f;   // smooth factor (1 = instant, <1 = lebih halus)
float AimTargetHeight = 1.5f; // tinggi target (kepala/badan)
float AimMaxRange   = 500.0f; // max jarak 3D

// --- Target Options ---
const char* targetOptions[] = { "Both", "Players Only", "Monsters Only" };
int selectedTargetOption = 0; // default: Both

// --- Global Target Pointers ---
void* nearestAimTarget = nullptr; 
void* nearestAimTargetMontester = nullptr;

typedef Vector3 (*t_GetBip001_HeadPos)(void* instance);
static t_GetBip001_HeadPos ptr_GetBip001_HeadPos_Char = nullptr;
static t_GetBip001_HeadPos ptr_GetBip001_HeadPos_Mon  = nullptr;

static Vector3 GetTargetHeadPos(void* target, bool isMonster) {
    if (!target)
        return Vector3{0, 0, 0};

    t_GetBip001_HeadPos fn = isMonster ? ptr_GetBip001_HeadPos_Mon : ptr_GetBip001_HeadPos_Char;
    if (fn) {
        Vector3 head = fn(target);
        if (!(head.x == 0.0f && head.y == 0.0f && head.z == 0.0f))
            return head;
    }
    Vector3 pos = getPosition(target);
    pos.y += AimTargetHeight;
    return pos;
}

// --- Hook Original ---
static bool (*orig_GetAssistantFinalRotation)(void* thiz, Quaternion origin, Quaternion* outTarget, bool hasLookingInput, float deltaTime);
// --- Math Helpers ---
Quaternion LookRotation(const Vector3& forward) {
    float fx = forward.x, fy = forward.y, fz = forward.z;
    float yaw = atan2f(fx, fz);
    float pitch = atan2f(-fy, sqrtf(fx*fx + fz*fz));

    float cy = cosf(yaw * 0.0f), sy = sinf(yaw * 0.0f);
    float cp = cosf(pitch * 0.0f), sp = sinf(pitch * 0.0f);

    Quaternion q;
    q.w = cp * cy;
    q.x = sp * cy;
    q.y = sp * sy;
    q.z = cp * sy;
    return q;
}

Vector3 Normalize(const Vector3& v) {
    float mag = sqrtf(v.x*v.x + v.y*v.y + v.z*v.z);
    return (mag > 1e-6f) ? Vector3(v.x/mag, v.y/mag, v.z/mag) : Vector3();
}


bool hk_GetAssistantFinalRotation(void* thiz, Quaternion origin, Quaternion* outTarget, bool hasLookingInput, float deltaTime) {
    void* finalTarget = nullptr;
    bool isMonster = false;

    if (aimbotV1) {
    if (selectedTargetOption == 0) {
        if (nearestAimTarget && nearestAimTargetMontester) {
            void* cam = get_main();
            if (cam) {
                Vector3 camPos = Transform_get_position(get_transform(cam));
                float distToPlayer  = GetDistance(camPos, getPosition(nearestAimTarget));
                float distToMonster = GetDistance(camPos, getPosition(nearestAimTargetMontester));
                if (distToPlayer < distToMonster) {
                    finalTarget = nearestAimTarget;
                    isMonster = false;
                } else {
                    finalTarget = nearestAimTargetMontester;
                    isMonster = true;
                }
            }
        } else if (nearestAimTarget) {
            finalTarget = nearestAimTarget;
            isMonster = false;
        } else if (nearestAimTargetMontester) {
            finalTarget = nearestAimTargetMontester;
            isMonster = true;
        }
    } else if (selectedTargetOption == 1) {
        finalTarget = nearestAimTarget;
        isMonster = false;
    } else if (selectedTargetOption == 2) {
        finalTarget = nearestAimTargetMontester;
        isMonster = true;
    }

        if (finalTarget) {
            void* cam = get_main();
            if (!cam) return false;
            void* camTransform = get_transform(cam);
            if (!camTransform) return false;

            Vector3 camPos    = Transform_get_position(camTransform);
            
            Vector3 tgtHead = GetTargetHeadPos(finalTarget, isMonster);

    Vector3 shootStart = tgtHead;
            Vector3 dir = Vector3::Normalized(shootStart - camPos);
            Quaternion targetRot = Quaternion::LookRotation(dir);

            
            Quaternion finalRot = Quaternion::Slerp(origin, targetRot, AimSmoothing);

            if (outTarget) {
                *outTarget = finalRot;
                return true;
            }
        }
    }

    return orig_GetAssistantFinalRotation 
        ? orig_GetAssistantFinalRotation(thiz, origin, outTarget, hasLookingInput, deltaTime) 
        : false;
}


struct LineRaycastIt {
    Vector3 _startTrace;
    Vector3 _dir;
    float _distance;
    int _layer_mask;

    LineRaycastIt() = default;
    LineRaycastIt(Vector3 startTrace, Vector3 dir, float distance, int layerMask)
        : _startTrace(startTrace), _dir(dir), _distance(distance), _layer_mask(layerMask) {}
};

LineRaycastIt (*orig_SingleLineCheckArrowAll)(Vector3 startTrace, Vector3 dir, float distance, int layerMask);

LineRaycastIt hk_SingleLineCheckArrowAll(Vector3 startTrace, Vector3 dir, float distance, int layerMask) {

    if (!EnableESP)
        return orig_SingleLineCheckArrowAll(startTrace, dir, distance, layerMask);

    if (!silent)
        return orig_SingleLineCheckArrowAll(startTrace, dir, distance, layerMask);

    if (!nearestAimTarget && !nearestAimTargetMontester)
        return orig_SingleLineCheckArrowAll(startTrace, dir, distance, layerMask);

    void* finalTarget = nullptr;
    bool isMonster = false;

   
    if (selectedTargetOption == 0) {
        if (nearestAimTarget) {
            finalTarget = nearestAimTarget;
        } else if (nearestAimTargetMontester) {
            finalTarget = nearestAimTargetMontester;
            isMonster = true;
        }
    } else if (selectedTargetOption == 1) {
        finalTarget = nearestAimTarget;
    } else if (selectedTargetOption == 2) {
        finalTarget = nearestAimTargetMontester;
        isMonster = true;
    }

    if (!finalTarget)
        return orig_SingleLineCheckArrowAll(startTrace, dir, distance, layerMask);

   
    Vector3 tgtHead = GetTargetHeadPos(finalTarget, isMonster);
    Vector3 shootDir = Vector3::Normalized(tgtHead - startTrace);
    
    
    float dist = Vector3::Distance(startTrace, tgtHead);
    
    float offset = fminf(dist * 0.1f, 999.0f);
    
    Vector3 startpos = startTrace + shootDir * offset;
    
LineRaycastIt result = orig_SingleLineCheckArrowAll(startpos, shootDir, 9999.0f, -1);
return result;
}

void Install_HitPhysicsUtil_SingleLineHook() {
    
    void* methodPtr = (void*)Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame"),
        OBFUSCATE("HitPhysicsUtil"),
        OBFUSCATE("SingleLineCheckArrowAll"),
        4
    );
    if (methodPtr) {
        Tools::Hook(methodPtr, (void*)hk_SingleLineCheckArrowAll, (void**)&orig_SingleLineCheckArrowAll);
    
    } else {
   
    }

 
    void* headChar = (void*)Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame"),
        OBFUSCATE("PresentCharacter"),
        OBFUSCATE("GetBip001_HeadPos"),
        0
    );
    if (headChar) {
        ptr_GetBip001_HeadPos_Char = (t_GetBip001_HeadPos)headChar;
        
    }

 
    void* headMon = (void*)Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame"),
        OBFUSCATE("PresentMonster"),
        OBFUSCATE("GetBip001_HeadPos"),
        0
    );
    if (headMon) {
        ptr_GetBip001_HeadPos_Mon = (t_GetBip001_HeadPos)headMon;
    
    } 
}
#include <unordered_map>
#include <mutex>
#include <string>
#include <sstream>

uintptr_t offset_genderId   = 0;
uintptr_t offset_classId    = 0;

uint32_t (*get_LogicId)(void* player) = nullptr;
bool (*get_IsBot)(void* player) = nullptr;

bool (*get_IsLocalTeammate)(uint32_t logicId) = nullptr;

void (*orig_OnPlayerCharacterHpChange)(void* instance, uint32_t logicId, float hp, float maxHp, float maxHpSealedPercentage) = nullptr;
void (*orig_InitPlayer)(void* instance, uint32_t logicId, void* playerId, void* nickName, uint64_t userId) = nullptr;
void (*orig_OnTeamIdChange)(void* instance, uint32_t logicId, uint8_t teamID) = nullptr;
void (*orig_OnAmmoChange)(void* instance, uint32_t logicId, uint8_t curAmmo) = nullptr;
void (*orig_OnPlayerCharacterEscaped)(void* instance, uint32_t logicId) = nullptr;
void (*orig_ChangeMainWeapon)(void* instance, uint32_t logicId, uint32_t itemId) = nullptr;
void (*orig_ChangeSubWeapon)(void* instance, uint32_t logicId, uint32_t itemId) = nullptr;
void (*orig_OnWeaponSlotChanged)(void* instance, uint32_t logicId, uint32_t weaponSlot) = nullptr;

void (*orig_OnCharacterAliveStatusChange)(void* instance, uint32_t logicID, uint8_t oldStatus, uint8_t newStatus) = nullptr;

struct HpInfo {
    float hp;
    float maxHp;
};

std::unordered_map<uint32_t, uint8_t> g_PlayerAliveStatusMap; 
std::mutex g_aliveStatusMutex;

struct PlayerInfo {
    uint32_t logicId;
    uint32_t gender;
    uint32_t classId;
    uint32_t mainWeapon;
    uint32_t subWeapon;
    uint32_t activeWeaponSlot;
    uint32_t activeWeaponItemId;
    std::string activeWeaponFullName;
    float hp;
    float maxHp;
    uint8_t currentAmmo;
    const char* className;
    std::string nickName;
    uint8_t teamId;
    uint64_t userId;
    bool isBot;
    bool isEscaped;
    uint8_t aliveStatus;
    bool isLocalTeammate;
};

std::unordered_map<uint32_t, HpInfo> g_PlayerHpMap;
std::unordered_map<uint32_t, std::string> g_PlayerNickMap;
std::unordered_map<uint32_t, uint8_t> g_PlayerTeamIdMap;
std::unordered_map<uint32_t, uint8_t> g_PlayerAmmoMap;
std::unordered_map<uint32_t, uint64_t> g_PlayerUserIdMap;
std::unordered_map<uint32_t, bool> g_PlayerEscapedMap;
std::unordered_map<uint32_t, uint32_t> g_PlayerMainWeaponMap;
std::unordered_map<uint32_t, uint32_t> g_PlayerSubWeaponMap;
std::unordered_map<uint32_t, uint32_t> g_PlayerActiveWeaponSlotMap;
std::unordered_map<void*, uint32_t> g_TargetLogicMap;
std::unordered_map<uint32_t, void*> g_PlayerMatchPlayerInstanceMap;
std::unordered_map<void*, uint32_t> g_PlayerMainWeaponInstanceMap;
std::unordered_map<void*, uint32_t> g_PlayerSubWeaponInstanceMap;
std::vector<PlayerInfo> g_PlayerList;

std::mutex g_PlayerInfoMutex;

std::mutex g_mainWeaponInstanceMutex;
std::mutex g_subWeaponInstanceMutex;
std::mutex g_hpMutex;
std::mutex g_nickMutex;
std::mutex g_teamIdMutex;
std::mutex g_ammoMutex;
std::mutex g_userIdMutex;
std::mutex g_escapedMutex;
std::mutex g_mainWeaponMutex;
std::mutex g_subWeaponMutex;
std::mutex g_activeWeaponSlotMutex;
std::mutex g_targetMapMutex;
std::mutex g_matchPlayerInstanceMutex;

const char* GetQualityNameForSuffix(uint32_t suffix) {
    switch (suffix) {
        case 0: return "NONE";
        case 1: return "JUNK";
        case 2: return "POOR";
        case 3: return "COMMON (ABU ABU)";
        case 4: return "UNCOMMON (HIJAU)";
        case 5: return "RARE (BIRU)";
        case 6: return "EPIC (UNGU)";
        case 7: return "LEGENDARY (EMAS)";
        case 8: return "UNIQUE (MERAH)";
        default: return "UNKNOWN";
    }
}

std::string BuildFullName(const char* baseName, uint32_t suffix) {
    std::string quality = GetQualityNameForSuffix(suffix);
    size_t start = quality.find('(');
    size_t end = quality.find(')');
    std::string simpleQuality = (start != std::string::npos && end != std::string::npos) 
                                ? quality.substr(start + 1, end - start - 1) 
                                : quality;
                                
    return std::string(baseName) + " " + simpleQuality;
}

std::unordered_map<uint32_t, const char*> g_WeaponBaseIdMap = {
    {10401, "STAFF"},
    {10110, "CRISTAL SWORD"},
    {10701, "BOOK"},
    {10604, "CROSSBOW"},
    {10203, "GIANT HAMMER"},
    {10602, "RECUVE"},
    {10601, "LONGBOW"},
    {10302, "GIANT HALBERD"},
    {10502, "HEAVY AXE"},
    {10301, "SPEAR"},
    {10112, "BROADSWORD CLEAVER"},
    {10111, "BALISONG"},
    {10107, "RAPIER"},
    {10804, "GIANT SHEILD"},
    {10605, "HEAVY CROSSBOW"},
    {10103, "TWO HAND SWORD"},
    {10201, "LIGHT HAMMER"},
    {10104, "DUAL DAGGERS"},
    {10101, "ARMING"}
};

std::unordered_map<uint32_t, std::string> g_FullItemNameMap;

void InitializeFullItemNameMap() {
    for (const auto& pair : g_WeaponBaseIdMap) {
        uint32_t baseId = pair.first;
        const char* baseName = pair.second;
        
        for (uint32_t suffix = 1; suffix <= 8; ++suffix) {
            std::string fullIdStr = std::to_string(baseId) + std::to_string(suffix);
            uint32_t fullId = std::stoul(fullIdStr);
            g_FullItemNameMap[fullId] = BuildFullName(baseName, suffix);
        }
    }
}

const std::string& GetFullWeaponName(uint32_t itemId) {
    auto it = g_FullItemNameMap.find(itemId);
    static const std::string unknown = "Unknown Weapon (Auto)";
    return (it != g_FullItemNameMap.end()) ? it->second : unknown;
}

const char* GetItemQualityName(uint32_t itemId) {
    uint32_t qualitySuffix = itemId % 10;
    return GetQualityNameForSuffix(qualitySuffix);
}

void hk_OnCharacterAliveStatusChange(void* instance, uint32_t logicID, uint8_t oldStatus, uint8_t newStatus) {
    {
        std::lock_guard<std::mutex> lock(g_aliveStatusMutex);
        g_PlayerAliveStatusMap[logicID] = newStatus;
    }
    if (orig_OnCharacterAliveStatusChange)
        orig_OnCharacterAliveStatusChange(instance, logicID, oldStatus, newStatus);
}

void hk_OnPlayerCharacterHpChange(void* instance, uint32_t logicId, float hp, float maxHp, float maxHpSealedPercentage) {
    {
        std::lock_guard<std::mutex> lock(g_hpMutex);
        g_PlayerHpMap[logicId] = { hp, maxHp };
    }
    if (orig_OnPlayerCharacterHpChange)
        orig_OnPlayerCharacterHpChange(instance, logicId, hp, maxHp, maxHpSealedPercentage);
}

void hk_InitPlayer(void* instance, uint32_t logicId, void* playerId, monoString* nickName, uint64_t userId) {
    if (nickName) {
        std::string name = nickName->getString();
        if (!name.empty()) {
            std::lock_guard<std::mutex> lock(g_nickMutex);
            g_PlayerNickMap[logicId] = name;
        }
    }
    {
        std::lock_guard<std::mutex> lock(g_userIdMutex);
        g_PlayerUserIdMap[logicId] = userId;
    }
    {
        std::lock_guard<std::mutex> lock(g_matchPlayerInstanceMutex);
        g_PlayerMatchPlayerInstanceMap[logicId] = instance;
    }
    if (orig_InitPlayer)
        orig_InitPlayer(instance, logicId, playerId, nickName, userId);
}

void hk_OnTeamIdChange(void* instance, uint32_t logicId, uint8_t teamID) {
    {
        std::lock_guard<std::mutex> lock(g_teamIdMutex);
        g_PlayerTeamIdMap[logicId] = teamID;
    }
    if (orig_OnTeamIdChange)
        orig_OnTeamIdChange(instance, logicId, teamID);
}

void hk_OnAmmoChange(void* instance, uint32_t logicId, uint8_t curAmmo) {
    {
        std::lock_guard<std::mutex> lock(g_ammoMutex);
        g_PlayerAmmoMap[logicId] = curAmmo;
    }
    if (orig_OnAmmoChange)
        orig_OnAmmoChange(instance, logicId, curAmmo);
}

void hk_OnPlayerCharacterEscaped(void* instance, uint32_t logicId) {
    {
        std::lock_guard<std::mutex> lock(g_escapedMutex);
        g_PlayerEscapedMap[logicId] = true;
    }
    if (orig_OnPlayerCharacterEscaped)
        orig_OnPlayerCharacterEscaped(instance, logicId);
}

void hk_ChangeMainWeapon(void* instance, uint32_t logicId, uint32_t itemId) {
    {
        std::lock_guard<std::mutex> lock(g_mainWeaponMutex);
        g_PlayerMainWeaponMap[logicId] = itemId;
    }
    {
        std::lock_guard<std::mutex> lock(g_mainWeaponInstanceMutex);
        g_PlayerMainWeaponInstanceMap[instance] = itemId;
    }
    if (orig_ChangeMainWeapon)
        orig_ChangeMainWeapon(instance, logicId, itemId);
}

void hk_ChangeSubWeapon(void* instance, uint32_t logicId, uint32_t itemId) {
    {
        std::lock_guard<std::mutex> lock(g_subWeaponMutex);
        g_PlayerSubWeaponMap[logicId] = itemId;
    }
    {
        std::lock_guard<std::mutex> lock(g_subWeaponInstanceMutex);
        g_PlayerSubWeaponInstanceMap[instance] = itemId;
    }
    if (orig_ChangeSubWeapon)
        orig_ChangeSubWeapon(instance, logicId, itemId);
}
void hk_OnWeaponSlotChanged(void* instance, uint32_t logicId, uint32_t weaponSlot) {
    {
        std::lock_guard<std::mutex> lock(g_activeWeaponSlotMutex);
        g_PlayerActiveWeaponSlotMap[logicId] = weaponSlot;
    }
    if (orig_OnWeaponSlotChanged)
        orig_OnWeaponSlotChanged(instance, logicId, weaponSlot);
}

uint32_t GetPlayerMainWeaponByLogic(uint32_t logicId) { std::lock_guard<std::mutex> lock(g_mainWeaponMutex); auto it = g_PlayerMainWeaponMap.find(logicId); return (it != g_PlayerMainWeaponMap.end()) ? it->second : 0; }
uint32_t GetPlayerSubWeaponByLogic(uint32_t logicId) { std::lock_guard<std::mutex> lock(g_subWeaponMutex); auto it = g_PlayerSubWeaponMap.find(logicId); return (it != g_PlayerSubWeaponMap.end()) ? it->second : 0; }
uint32_t GetPlayerActiveWeaponSlotByLogic(uint32_t logicId) { std::lock_guard<std::mutex> lock(g_activeWeaponSlotMutex); auto it = g_PlayerActiveWeaponSlotMap.find(logicId); return (it != g_PlayerActiveWeaponSlotMap.end()) ? it->second : 1; }
uint8_t GetPlayerAliveStatusByLogic(uint32_t logicId) { std::lock_guard<std::mutex> lock(g_aliveStatusMutex); auto it = g_PlayerAliveStatusMap.find(logicId); return (it != g_PlayerAliveStatusMap.end()) ? it->second : 0; }

void InitOffsetsPresentCharacter() {
    InitializeFullItemNameMap(); 
    
    offset_genderId   = Il2CppGetFieldOffset(OBFUSCATE("KradGame.dll"), OBFUSCATE("KradGame"), OBFUSCATE("PresentCharacter"), OBFUSCATE("_genderId"));
    offset_classId    = Il2CppGetFieldOffset(OBFUSCATE("KradGame.dll"), OBFUSCATE("KradGame"), OBFUSCATE("PresentCharacter"), OBFUSCATE("_classId"));
    
    get_LogicId = (uint32_t (*)(void*))Il2CppGetMethodOffset(OBFUSCATE("KradGame.dll"), OBFUSCATE("KradGame"), OBFUSCATE("PEntity"), OBFUSCATE("get_LogicId"), 0);
    get_IsBot   = (bool (*)(void*))Il2CppGetMethodOffset(OBFUSCATE("KradGame.dll"), OBFUSCATE("KradGame"), OBFUSCATE("MatchPlayer"), OBFUSCATE("get_IsBot"), 0);
    
    get_IsLocalTeammate = (bool (*)(uint32_t))Il2CppGetMethodOffset(OBFUSCATE("KradGame.dll"), OBFUSCATE("KradGame"), OBFUSCATE("GameFacade"), OBFUSCATE("IsLocalTeammate"), 1);

    void* hpPtr = (void*)Il2CppGetMethodOffset(OBFUSCATE("KradGame.dll"), OBFUSCATE("KradGame"), OBFUSCATE("PresentationManager"), OBFUSCATE("OnPlayerCharacterHpChange"), 4);
    if (hpPtr) Tools::Hook(hpPtr, (void*)hk_OnPlayerCharacterHpChange, (void**)&orig_OnPlayerCharacterHpChange);

    void* initPlayerPtr = (void*)Il2CppGetMethodOffset(OBFUSCATE("KradGame.dll"), OBFUSCATE("KradGame"), OBFUSCATE("MatchPlayer"), OBFUSCATE("InitPlayer"), 4);
    if (initPlayerPtr) Tools::Hook(initPlayerPtr, (void*)hk_InitPlayer, (void**)&orig_InitPlayer);

    void* teamIdPtr = (void*)Il2CppGetMethodOffset(OBFUSCATE("KradGame.dll"), OBFUSCATE("KradGame"), OBFUSCATE("PresentationManager"), OBFUSCATE("OnTeamIdChange"), 2);
    if (teamIdPtr) Tools::Hook(teamIdPtr, (void*)hk_OnTeamIdChange, (void**)&orig_OnTeamIdChange);

    void* ammoPtr = (void*)Il2CppGetMethodOffset(OBFUSCATE("KradGame.dll"), OBFUSCATE("KradGame"), OBFUSCATE("PresentationManager"), OBFUSCATE("OnAmmoChange"), 2);
    if (ammoPtr) Tools::Hook(ammoPtr, (void*)hk_OnAmmoChange, (void**)&orig_OnAmmoChange);

    void* escapedPtr = (void*)Il2CppGetMethodOffset(OBFUSCATE("KradGame.dll"), OBFUSCATE("KradGame"), OBFUSCATE("PresentationManager"), OBFUSCATE("OnPlayerCharacterEscaped"), 1);
    if (escapedPtr) Tools::Hook(escapedPtr, (void*)hk_OnPlayerCharacterEscaped, (void**)&orig_OnPlayerCharacterEscaped);

    void* mainWeaponPtr = (void*)Il2CppGetMethodOffset(OBFUSCATE("KradGame.dll"), OBFUSCATE("KradGame"), OBFUSCATE("PresentationManager"), OBFUSCATE("ChangeMainWeapon"), 2);
    if (mainWeaponPtr) Tools::Hook(mainWeaponPtr, (void*)hk_ChangeMainWeapon, (void**)&orig_ChangeMainWeapon);

    void* subWeaponPtr = (void*)Il2CppGetMethodOffset(OBFUSCATE("KradGame.dll"), OBFUSCATE("KradGame"), OBFUSCATE("PresentationManager"), OBFUSCATE("ChangeSubWeapon"), 2);
    if (subWeaponPtr) Tools::Hook(subWeaponPtr, (void*)hk_ChangeSubWeapon, (void**)&orig_ChangeSubWeapon);
    
    void* slotChangePtr = (void*)Il2CppGetMethodOffset(OBFUSCATE("KradGame.dll"), OBFUSCATE("KradGame"), OBFUSCATE("PresentationManager"), OBFUSCATE("OnWeaponSlotChanged"), 2);
    if (slotChangePtr) Tools::Hook(slotChangePtr, (void*)hk_OnWeaponSlotChanged, (void**)&orig_OnWeaponSlotChanged);
    
    void* aliveStatusPtr = (void*)Il2CppGetMethodOffset(OBFUSCATE("KradGame.dll"), OBFUSCATE("KradGame"), OBFUSCATE("PresentationManager"), OBFUSCATE("OnCharacterAliveStatusChange"), 3);
    if (aliveStatusPtr) Tools::Hook(aliveStatusPtr, (void*)hk_OnCharacterAliveStatusChange, (void**)&orig_OnCharacterAliveStatusChange);
}

float GetPlayerHpByLogic(uint32_t logicId) { std::lock_guard<std::mutex> lock(g_hpMutex); auto it = g_PlayerHpMap.find(logicId); return (it != g_PlayerHpMap.end()) ? it->second.hp : 0.0f; }
float GetPlayerMaxHpByLogic(uint32_t logicId) { std::lock_guard<std::mutex> lock(g_hpMutex); auto it = g_PlayerHpMap.find(logicId); return (it != g_PlayerHpMap.end()) ? it->second.maxHp : 0.0f; }
std::string GetPlayerNickByLogic(uint32_t logicId) { std::lock_guard<std::mutex> lock(g_nickMutex); auto it = g_PlayerNickMap.find(logicId); return (it != g_PlayerNickMap.end()) ? it->second : "Unknown"; }
uint8_t GetPlayerTeamIdByLogic(uint32_t logicId) { std::lock_guard<std::mutex> lock(g_teamIdMutex); auto it = g_PlayerTeamIdMap.find(logicId); return (it != g_PlayerTeamIdMap.end()) ? it->second : 0; }
uint8_t GetPlayerCurrentAmmoByLogic(uint32_t logicId) { std::lock_guard<std::mutex> lock(g_ammoMutex); auto it = g_PlayerAmmoMap.find(logicId); return (it != g_PlayerAmmoMap.end()) ? it->second : 0; }
uint64_t GetPlayerUserIdByLogic(uint32_t logicId) { std::lock_guard<std::mutex> lock(g_userIdMutex); auto it = g_PlayerUserIdMap.find(logicId); return (it != g_PlayerUserIdMap.end()) ? it->second : 0; }
bool GetPlayerEscapedByLogic(uint32_t logicId) { std::lock_guard<std::mutex> lock(g_escapedMutex); auto it = g_PlayerEscapedMap.find(logicId); return (it != g_PlayerEscapedMap.end()) ? it->second : false; }

const char* GetClassName(uint32_t id) {
    switch (id) {
        case 1: return "WARRIOR";
        case 3: return "RANGER";
        case 4: return "ROGUE";
        case 5: return "SAGE";
        case 6: return "WIZARD";
        case 7: return "PLAGUE";
        case 8: return "CRUST KNIGHT";
        default: return "UNKNOWN";
    }
}

bool IsLocalTeammate(uint32_t logicId) {
    if (get_IsLocalTeammate) {
        return get_IsLocalTeammate(logicId);
    }
    return false;
}

PlayerInfo GetPlayerInfo(void* player) {
    PlayerInfo info{};
    if (!player)
        return info;
    uint32_t logicId = get_LogicId(player);
    
    void* matchPlayerInstance = nullptr;
    {
        std::lock_guard<std::mutex> lock(g_matchPlayerInstanceMutex);
        auto it = g_PlayerMatchPlayerInstanceMap.find(logicId);
        if (it != g_PlayerMatchPlayerInstanceMap.end()) {
            matchPlayerInstance = it->second;
        }
    }
    
    info.logicId     = logicId;
    info.gender      = *(uint32_t*)((uintptr_t)player + offset_genderId);
    info.classId     = *(uint32_t*)((uintptr_t)player + offset_classId);
    info.mainWeapon  = GetPlayerMainWeaponByLogic(logicId);
    info.subWeapon   = GetPlayerSubWeaponByLogic(logicId);
    info.activeWeaponSlot = GetPlayerActiveWeaponSlotByLogic(logicId);
    info.activeWeaponItemId = info.subWeapon;
    if (info.activeWeaponItemId == 0) {
        info.activeWeaponItemId = info.mainWeapon;
    }
        
    

    const std::string& fullWeaponName = GetFullWeaponName(info.activeWeaponItemId);
    
    if (fullWeaponName != "Unknown Weapon (Auto)") {
        info.activeWeaponFullName = fullWeaponName;
    } else {
        const char* qualityName = GetItemQualityName(info.activeWeaponItemId);
        info.activeWeaponFullName = "ID: " + std::to_string(info.activeWeaponItemId) + " Quality: " + qualityName;
    }

    info.hp          = GetPlayerHpByLogic(logicId);
    info.maxHp       = GetPlayerMaxHpByLogic(logicId);
    info.currentAmmo = GetPlayerCurrentAmmoByLogic(logicId);
    info.className   = GetClassName(info.classId);
    info.nickName    = GetPlayerNickByLogic(logicId);
    info.teamId      = GetPlayerTeamIdByLogic(logicId);
    info.userId      = GetPlayerUserIdByLogic(logicId);
    info.isBot       = matchPlayerInstance ? get_IsBot(matchPlayerInstance) : false;
    info.isEscaped   = GetPlayerEscapedByLogic(logicId);
    info.aliveStatus = GetPlayerAliveStatusByLogic(logicId);
    info.isLocalTeammate = IsLocalTeammate(logicId);

    { std::lock_guard<std::mutex> lock(g_targetMapMutex); g_TargetLogicMap[player] = logicId; }
    return info;
}

void PlayerUpdate(void* player, float g, float t) {
    if (!player || !get_main()) {
        players.clear();
        {
            std::lock_guard<std::mutex> lock(g_PlayerInfoMutex);
            g_PlayerList.clear();
        }
        old_PlayerUpdate(player, g, t);
        return;
    }

    if (!EnableESP) {
        players.clear();
        {
            std::lock_guard<std::mutex> lock(g_PlayerInfoMutex);
            g_PlayerList.clear();
        }
        old_PlayerUpdate(player, g, t);
        return;
    }

    if (IsLocalEntity(player)) {
    myPlayer = player;
        RemovePlayer(player);
        {
            std::lock_guard<std::mutex> lock(g_PlayerInfoMutex);
            g_PlayerList.erase(
                std::remove_if(g_PlayerList.begin(), g_PlayerList.end(),
                    [&](const PlayerInfo& info) {
                        return info.logicId == get_LogicId(player);
                    }),
                g_PlayerList.end()
            );
        }
    } 
    else {
       
            if (!HasPlayer(player)) {
                players.push_back(player);
            }
        

        PlayerInfo info = GetPlayerInfo(player);

        Vector3 camPos = Transform_get_position(get_transform(get_main()));
        float dist3D = GetDistance(camPos, getPosition(player));
        {
            std::lock_guard<std::mutex> lock(g_PlayerInfoMutex);
            bool found = false;
            for (auto& existing : g_PlayerList) {
                if (existing.logicId == info.logicId) {
                    existing = info;
                    found = true;
                }
            }

            if (!found)
                g_PlayerList.push_back(info);
        }
    }

    old_PlayerUpdate(player, g, t);
}

__attribute__((visibility("hidden")))
void DrawEsp() {
    if (!EnableESP) {
        players.clear();
        return;
    }

    void* mainInstance = get_main();
    if (!mainInstance) {
        players.clear();
        return;
    }

    Vector3 localPos = getPosition(mainInstance);
    ImVec2 screenCenter(glWidth * 0.5f, glHeight * 0.5f);
    void* nearestTarget = nullptr;
    float nearestDistance = AimFovRadius;

    for (auto player : players) {
        if (!player) continue;
        PlayerInfo info = GetPlayerInfo(player);
        if (!IsPlayerDead(player)) continue;
        if (info.isEscaped) continue;
        Vector3 playerPos = getPosition(player);
        float dist3D = sqrtf(
            (playerPos.x - localPos.x) * (playerPos.x - localPos.x) +
            (playerPos.y - localPos.y) * (playerPos.y - localPos.y) +
            (playerPos.z - localPos.z) * (playerPos.z - localPos.z)
        );
        if (dist3D > 500.f) continue;

        Vector3 headPos(playerPos.x, playerPos.y + 1.6f, playerPos.z);
        Vector3 feetPos = playerPos;
        Vector3 headScreen = WorldToScreenPoint(mainInstance, headPos);
        Vector3 feetScreen = WorldToScreenPoint(mainInstance, feetPos);
        if (headScreen.z < 1.f || feetScreen.z < 1.f) continue;

        ImVec4 color(1,1,1,1);
        float boxHeight = abs(headScreen.y - feetScreen.y);
        float boxWidth = boxHeight * 0.65f;
        Rect playerRect(headScreen.x - boxWidth/2, glHeight - headScreen.y, boxWidth, boxHeight);
        if (ESPLine) {
            Vector3 tgtHead = GetTargetHeadPos(player, false);
            Vector3 headScreen = WorldToScreenPoint(mainInstance, tgtHead);
        
            if (headScreen.z > 0) {
                ImVec2 lineEnd(headScreen.x, glHeight - headScreen.y);
                Draw::DrawLine(ImVec2(glWidth * 0.5f, 50.f), lineEnd, color, 1.3f);
                Draw::DrawCircle(lineEnd.x, lineEnd.y, 6.f, true, color);
            }
        }
        
        if (ESPBox) {
            Vector3 tgtHead = GetTargetHeadPos(player, false);
            Vector3 top3D(playerPos.x, playerPos.y + 1.6f, playerPos.z);
            Vector3 bottom3D(playerPos.x, playerPos.y, playerPos.z);
            Draw::Draw3DBox(tgtHead, bottom3D, 0.6f, color);
        }
        
            if (drawinfo) {
            
            ImVec4 color_EMAS(1.0f, 0.84f, 0.0f, 1.0f);
            ImVec4 color_MERAH(1.0f, 0.0f, 0.0f, 1.0f);
            ImVec4 color_UNGU(0.5f, 0.0f, 0.5f, 1.0f);
            ImVec4 color_BIRU(0.0f, 0.5f, 1.0f, 1.0f);
            ImVec4 color_HIJAU(0.0f, 0.7f, 0.0f, 1.0f);
            ImVec4 color_ABUABU(0.4f, 0.4f, 0.4f, 1.0f);
            ImVec4 color_DEFAULT(0.6f, 0.6f, 0.6f, 1.0f);
        
            uint32_t id = info.teamId;
        
            float r = (float)((id * 100 + 50) % 256) / 255.0f;
            float g = (float)((id * 150 + 100) % 256) / 255.0f;
            float b = (float)((id * 200 + 150) % 256) / 255.0f;
            
            r = ImMax(0.2f, r);
            g = ImMax(0.2f, g);
            b = ImMax(0.2f, b);
        
            ImVec4 textColor(r, g, b, 1.0f); 
            ImVec4 hpColor(0.0f, 1.0f, 0.8f, 1.0f);
            ImVec4 ammoColor(1.0f, 1.0f, 0.0f, 1.0f);
            
            
            ImVec4 weaponColor = color_DEFAULT;
            
            /* SINKRONISASI WARNA SENJATA DENGAN activeWeaponFullName */
            /* Menggunakan find untuk mendeteksi kata kunci kualitas di string nama penuh */
            if (!info.activeWeaponFullName.empty()) {
                
                std::string upperName = info.activeWeaponFullName;
                std::transform(upperName.begin(), upperName.end(), upperName.begin(), ::toupper);

                if (upperName.find(OBFUSCATE("EMAS")) != std::string::npos || upperName.find(OBFUSCATE("LEGENDARY")) != std::string::npos) {
                    weaponColor = color_EMAS;
                } else if (upperName.find(OBFUSCATE("MERAH")) != std::string::npos || upperName.find(OBFUSCATE("UNIQUE")) != std::string::npos) {
                    weaponColor = color_MERAH;
                } else if (upperName.find(OBFUSCATE("UNGU")) != std::string::npos || upperName.find(OBFUSCATE("EPIC")) != std::string::npos) {
                    weaponColor = color_UNGU;
                } else if (upperName.find(OBFUSCATE("BIRU")) != std::string::npos || upperName.find(OBFUSCATE("RARE")) != std::string::npos) {
                    weaponColor = color_BIRU;
                } else if (upperName.find(OBFUSCATE("HIJAU")) != std::string::npos || upperName.find(OBFUSCATE("UNCOMMON")) != std::string::npos) {
                    weaponColor = color_HIJAU;
                } else if (upperName.find(OBFUSCATE("ABU ABU")) != std::string::npos || upperName.find(OBFUSCATE("COMMON")) != std::string::npos) {
                    weaponColor = color_ABUABU;
                }
            }
        
        
            if (!info.nickName.empty()) {
                std::string fullTitle;
                
                if (info.isBot) {
                    fullTitle = OBFUSCATE("(Bot) ");
                }
                
                fullTitle += info.nickName + " (" + std::to_string((int)info.teamId) + ")";
                
                ImVec2 titleSize = ImGui::CalcTextSize(fullTitle.c_str());
                
                float titleX = headScreen.x - titleSize.x / 2.0f;
                float titleY = glHeight - headScreen.y - titleSize.y - 4.0f;
        
                Draw::DrawText(22.f, ImVec2(titleX, titleY), 
                               textColor, fullTitle.c_str());
            }
        
            char hpText[64];
            snprintf(hpText, sizeof(hpText), OBFUSCATE("HP: %.0f / %.0f"), info.hp, info.maxHp);
            
            char ammoText[64];
            snprintf(ammoText, sizeof(ammoText), OBFUSCATE("Ammo: %d"), info.currentAmmo);
        
            std::vector<std::pair<std::string, ImVec4>> lines = {
                {
                    std::string(info.className) + " (" + std::to_string((int)dist3D) + OBFUSCATE("m)"),
                    ImVec4(1.0f, 1.0f, 1.0f, 1.0f) 
                },
                {
                    info.activeWeaponFullName, 
                    weaponColor 
                },
                {
                    std::string(hpText),
                    hpColor
                },
                {
                    std::string(ammoText),
                    ammoColor
                }
            };
            
            float startY = glHeight - feetScreen.y + 4.0f;
            float lineHeight = 18.0f;
        
            for (size_t j = 0; j < lines.size(); j++) {
                ImVec2 textSize = ImGui::CalcTextSize(lines[j].first.c_str());
                
                float textX = feetScreen.x - textSize.x / 2.0f; 
                float textY = startY + j * lineHeight; 
        
                Draw::DrawText(18.f, ImVec2(textX, textY),
                               lines[j].second, lines[j].first.c_str());
            }
        }
                        
                
        if (AimBotVisual) {
            Vector3 enemyPos3D = getPosition(player);
            float dist3D = sqrtf(
                (enemyPos3D.x - localPos.x)*(enemyPos3D.x - localPos.x) +
                (enemyPos3D.y - localPos.y)*(enemyPos3D.y - localPos.y) +
                (enemyPos3D.z - localPos.z)*(enemyPos3D.z - localPos.z)
            );
            Vector3 headScreen = WorldToScreenPoint(mainInstance, Vector3(enemyPos3D.x, enemyPos3D.y + 1.6f, enemyPos3D.z));
            if (headScreen.z < 1.f) continue;
            ImVec2 enemyPos2D(headScreen.x, glHeight - headScreen.y);
            float screenDist = sqrtf(powf(enemyPos2D.x - screenCenter.x, 2) + powf(enemyPos2D.y - screenCenter.y, 2));
            if (screenDist <= AimFovRadius) {
                float combinedDist = dist3D + screenDist;
                if (combinedDist < nearestDistance) {
                    nearestDistance = combinedDist;
                    nearestTarget = player;
                }
            }
        }
    }

    nearestAimTarget = nearestTarget;

    if (AimBotVisual && ShowFovCircle)
        Draw::DrawCircle(screenCenter.x, screenCenter.y, AimFovRadius, false, ImVec4(0.f,1.f,0.f,0.5f));

    if (AimBotVisual && ShowAimLine && nearestTarget) {
        Vector3 pos = getPosition(nearestTarget);
        Vector3 headScreen = WorldToScreenPoint(mainInstance, Vector3(pos.x, pos.y+1.6f, pos.z));
        Draw::DrawLine(screenCenter, ImVec2(headScreen.x, glHeight - headScreen.y), ImVec4(1,0,0,1), 2.f);
        Draw::DrawCircle(headScreen.x, glHeight - headScreen.y, 6.f, true, ImVec4(1,0,0,1));
    }
}

// Pointer ke original 
// --- Updated DrawEsp ---
// --- Updated DrawEsp ---

bool EnableChestESP = false;
bool ESPBoxChest    = false;
bool ESPLineChest   = false;
bool ESPInfoChest   = false;

// --- Chest ESP list ---
// --- Chest ESP list ---
std::vector<void*> chests;

void addChest(void* chest) {
    if (chest && std::find(chests.begin(), chests.end(), chest) == chests.end()) {
        chests.push_back(chest);
    }
}

void removeChest(void* chest) {
    if (!chest) return;
    chests.erase(std::remove(chests.begin(), chests.end(), chest), chests.end());
}

// --- hook PresentChestBox.OnUpdate ---
void (*old_ChestUpdate)(void* chest, float gameTime, float deltaTime);
void hk_ChestUpdate(void* chest, float gameTime, float deltaTime) {
    if (!chest) {
        // Kalau object chest NULL (misal keluar match), clear biar aman
        chests.clear();
        if (old_ChestUpdate) old_ChestUpdate(chest, gameTime, deltaTime);
        return;
    }

    // Kalau local player belum ada (misal di lobby), clear biar aman juga
    if (!get_main()) {
        chests.clear();
        if (old_ChestUpdate) old_ChestUpdate(chest, gameTime, deltaTime);
        return;
    }

    if (EnableChestESP && chest)
        addChest(chest);

    if (old_ChestUpdate)
        old_ChestUpdate(chest, gameTime, deltaTime);
}

// --- hook PresentChestBox.OnDestroy ---


// --- Init Hook ---
void InitChestEspHook() {
    void* chestOffset = (void*)Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame"),
        OBFUSCATE("PresentChestBox"),
        OBFUSCATE("OnUpdate"),
        2
    );

    if (chestOffset)
        Tools::Hook(chestOffset, (void*)hk_ChestUpdate, (void**)&old_ChestUpdate);

    
}
// --- Draw ESP untuk ChestBox ---
// --- Draw ESP untuk ChestBox (Safe & Clean Info Split) ---
__attribute__((visibility("hidden")))
void DrawChestEsp() {
    if (!EnableChestESP) {
        chests.clear();
        return;
    }

    void* mainInstance = get_main();
    if (!mainInstance) {
        chests.clear();
        return;
    }

    static size_t isOpenedOffset   = Il2CppGetFieldOffset(OBFUSCATE("KradGame.dll"), OBFUSCATE("KradGame"), OBFUSCATE("PresentChestBox"), OBFUSCATE("IsOpen"));
    static size_t lootImplOffset   = Il2CppGetFieldOffset(OBFUSCATE("KradGame.dll"), OBFUSCATE("KradGame"), OBFUSCATE("PresentChestBox"), OBFUSCATE("_searchLootEntityImplementation"));
    static void* getNameMethod    = Il2CppGetMethodOffset(OBFUSCATE("KradGame.dll"), OBFUSCATE("KradGame"), OBFUSCATE("PresentChestBox"), OBFUSCATE("GetName"), 0);
    static void* getLootMethod    = Il2CppGetMethodOffset(OBFUSCATE("KradGame.dll"), OBFUSCATE("KradGame"), OBFUSCATE("ISearchLootEntity"), OBFUSCATE("GetLootList"), 0);
    static size_t itemNameOffset   = Il2CppGetFieldOffset(OBFUSCATE("KradGame.dll"), OBFUSCATE("KradGame"), OBFUSCATE("LootItemLight"), OBFUSCATE("ItemName"));

    Vector3 localPos = getPosition(mainInstance);

    for (auto chest : chests) {
        if (!chest) continue;

        Vector3 pos = getPosition(chest);

        // --- Skip chest lebih dari 500 meter ---
        float dist3D = sqrtf(
            (pos.x - localPos.x) * (pos.x - localPos.x) +
            (pos.y - localPos.y) * (pos.y - localPos.y) +
            (pos.z - localPos.z) * (pos.z - localPos.z)
        );
        if (dist3D > 500.0f) continue;

        Vector3 screenPos = WorldToScreenPoint(mainInstance, pos);
        if (screenPos.z < 1.f) continue;

        ImVec4 color = ImVec4(0.0f, 1.0f, 0.0f, 1.0f);
        float boxSize = 20.0f;

        if (ESPBoxChest) {
            ImVec4 color = ImVec4(0.0f, 1.0f, 0.0f, 1.0f);
            DrawChest3DBox(chest, color);
        }

        if (ESPLineChest) {
            Draw::DrawLine(ImVec2(glWidth * 0.5f, 50.0f),
                           ImVec2(screenPos.x, glHeight - screenPos.y),
                           color, 2.0f);
        }

        // --- INFO SECTION (nama di atas, status di bawah) ---
        if (ESPInfoChest) {
            Il2CppString* chestName = nullptr;
            if (getNameMethod) {
                using GetNameFn = Il2CppString*(*)(void*);
                chestName = ((GetNameFn)getNameMethod)(chest);
            }

            bool isOpen = false;
            if (isOpenedOffset) {
                isOpen = *(bool*)((uint8_t*)chest + isOpenedOffset);
            }

            std::string nameText = chestName ? chestName->CString() : "Unknown";
            std::string stateText = isOpen ? "[Opened]" : "[Closed]";

            // Posisi kanan box
            float infoX = screenPos.x + boxSize + 8.0f;
            float infoY = glHeight - screenPos.y - boxSize - 5.0f;

            // Warna: putih untuk nama, hijau untuk open, putih untuk closed
            ImU32 nameColor = IM_COL32(255, 255, 255, 255);
            ImU32 stateColor = isOpen ? IM_COL32(80, 255, 120, 255) : IM_COL32(255, 255, 255, 255);

            // Nama chest
            ImGui::GetBackgroundDrawList()->AddText(
                ImVec2(infoX, infoY),
                nameColor,
                nameText.c_str()
            );

            // Status di bawah nama
            ImGui::GetBackgroundDrawList()->AddText(
                ImVec2(infoX, infoY + 14.0f),
                stateColor,
                stateText.c_str()
            );

            // --- Loot List di bawah status ---
            void* lootImpl = nullptr;
            if (lootImplOffset) lootImpl = *(void**)((uint8_t*)chest + lootImplOffset);
            if (!lootImpl || !getLootMethod) continue;

            using GetLootFn = Il2CppList<void*>*(*)(void*);
            Il2CppList<void*>* lootList = ((GetLootFn)getLootMethod)(lootImpl);
            if (!lootList || lootList->getSize() <= 0) continue;

            float textY = infoY + 28.0f;
            for (int i = 0; i < lootList->getSize(); i++) {
                void* loot = lootList->getItems()[i];
                if (!loot) continue;

                Il2CppString* itemName = nullptr;
                if (itemNameOffset) itemName = *(Il2CppString**)((uint8_t*)loot + itemNameOffset);
                if (!itemName) continue;

                ImGui::GetBackgroundDrawList()->AddText(
                    ImVec2(infoX, textY),
                    IM_COL32(230, 230, 230, 255),
                    itemName->CString()
                );
                textY += 13.0f;
            }
        }
    }
}
// --- Helpers Il2CppString ---


// --- ESP Monster ---
bool EnableMonsterESP = false;
bool ESPBoxMonster    = false;
bool ESPLineMonster   = false;
bool ESPInfoMonster   = false;

// =========================
// MONSTER ESP HOOK SYSTEM
// =========================


// --- Offsets ---

// --- Init Offset Monster ---
void InitOffsetsMonster() {
    offset_monsterRecord = Il2CppGetFieldOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame"),
        OBFUSCATE("PresentMonster"),
        OBFUSCATE("record")
    );

    getMonsterNameMethod = Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame"),
        OBFUSCATE("MonsterBaseRecord"),
        OBFUSCATE("GetName"),
        0
    );

    isMonsterDeadMethod  = Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame"),
        OBFUSCATE("PEntity"),
        OBFUSCATE("get_IsDead"),
        0
    );
}



std::string GetMonsterName(void* monster) {
    if (!monster || !offset_monsterRecord || !getMonsterNameMethod)
        return "Monster";

    void* record = *(void**)((uintptr_t)monster + offset_monsterRecord);
    if (!record) return "Monster";

    auto fn = (Il2CppString*(*)(void*))getMonsterNameMethod;
    Il2CppString* str = fn(record);
    if (!str || !str->start_char) return "Monster";

    return str->CString();
}

inline bool HasMonster(void* m) {
    return std::find(monsters.begin(), monsters.end(), m) != monsters.end();
}

inline void RemoveMonster(void* m) {
    monsters.erase(std::remove(monsters.begin(), monsters.end(), m), monsters.end());
}


void (*old_MonsterUpdate)(void* thiz, float gameTime, float deltaTime);
void hk_MonsterUpdate(void* thiz, float gameTime, float deltaTime) {
    if (!thiz) {
        monsters.clear();
        if (old_MonsterUpdate) old_MonsterUpdate(thiz, gameTime, deltaTime);
        return;
    }

    if (!get_main()) {
        monsters.clear();
        if (old_MonsterUpdate) old_MonsterUpdate(thiz, gameTime, deltaTime);
        return;
    }

    if (EnableMonsterESP) {
        if (!IsMonsterDead(thiz)) {
            if (!HasMonster(thiz))
                monsters.push_back(thiz);

        } else {
            RemoveMonster(thiz);
        }
    }

    if (old_MonsterUpdate) old_MonsterUpdate(thiz, gameTime, deltaTime);
}


void InitMonsterEspHook() {
    void* monsterUpdate = Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame"),
        OBFUSCATE("PresentMonster"),
        OBFUSCATE("OnUpdate"),
        2
    );

    if (monsterUpdate)
        Tools::Hook(monsterUpdate, (void*)hk_MonsterUpdate, (void**)&old_MonsterUpdate);

    


}
// --- Draw Monster ESP ---
void DrawMonsterEsp() {
    if (!EnableMonsterESP) {
        monsters.clear();
        return;
    }

    void* mainInstance = get_main();
    if (!mainInstance) {
        monsters.clear();
        return;
    }

    Vector3 localPos = getPosition(mainInstance);
ImVec2 screenCenter(glWidth * 0.5f, glHeight * 0.5f);

void* nearestTargetv = nullptr;
float nearestDistance = AimFovRadius;

    for (auto monster : monsters) {
        if (!monster || IsMonsterDead(monster)) continue;

        Vector3 pos = getPosition(monster);
        float dist3D = GetDistance(localPos, pos);
        if (dist3D > 600.0f) continue;
        Vector3 tgtHead = GetTargetHeadPos(monster, true);
        Vector3 headPos = Vector3(pos.x, pos.y + 2.0f, pos.z);
        Vector3 feetPos = pos;

        Vector3 headScreen = WorldToScreenPoint(mainInstance, headPos);
        Vector3 feetScreen = WorldToScreenPoint(mainInstance, feetPos);
        if (headScreen.z < 1.f || feetScreen.z < 1.f) continue;

        ImVec4 color = ImVec4(0,0,1,1); // putih
        float boxHeight = fabsf(headScreen.y - feetScreen.y);
        float boxWidth  = boxHeight * 0.7f;
        Rect r(headScreen.x - boxWidth/2, glHeight - headScreen.y, boxWidth, boxHeight);

        if (ESPBoxMonster) {
        
     Vector3 top3D = Vector3(pos.x, pos.y + 1.6f, pos.z);
    Vector3 bottom3D = Vector3(pos.x, pos.y, pos.z);
    Draw::Draw3DBox(top3D, bottom3D, 0.6f, color); // width = lebar badan player
}
if (ESPLineMonster) {
    ImVec2 lineStart(glWidth * 0.5f, 50.0f);

    // Ambil 4 corner bawah 3D box
    Vector3 b1 = WorldToScreenPoint(mainInstance, Vector3(pos.x - 0.5f, pos.y, pos.z - 0.6f));
    Vector3 b2 = WorldToScreenPoint(mainInstance, Vector3(pos.x + 0.6f, pos.y, pos.z - 0.6f));
    Vector3 b3 = WorldToScreenPoint(mainInstance, Vector3(pos.x - 0.5f, pos.y, pos.z + 0.6f));
    Vector3 b4 = WorldToScreenPoint(mainInstance, Vector3(pos.x + 0.6f, pos.y, pos.z + 0.6f));

    if (b1.z > 0 && b2.z > 0 && b3.z > 0 && b4.z > 0) {
        ImVec2 lineEnd(
            (b1.x + b2.x + b3.x + b4.x) / 4.0f, 
            glHeight - ((b1.y + b2.y + b3.y + b4.y) / 4.0f)
        );

        Draw::DrawLine(lineStart, lineEnd, color, 2.f);
        Draw::DrawCircle(lineEnd.x, lineEnd.y, 6.0f, true, color);
    }
}
        if (ESPInfoMonster) {
            std::string name = GetMonsterName(monster);

            char infoText[128];
            snprintf(infoText, sizeof(infoText), "%s [%.0fm]", name.c_str(), dist3D);

            Draw::DrawText(20.f,
                ImVec2(headScreen.x - boxWidth/2, glHeight - headScreen.y - 20.f),
                color,
                infoText
            );
        }
        

if (AimBotVisual) {
    Vector3 enemyPos3D = getPosition(monster);

    // Hitung jarak 3D ke local
    float dist3D = sqrtf(
        (enemyPos3D.x - localPos.x) * (enemyPos3D.x - localPos.x) +
        (enemyPos3D.y - localPos.y) * (enemyPos3D.y - localPos.y) +
        (enemyPos3D.z - localPos.z) * (enemyPos3D.z - localPos.z)
    );

    // Proyeksi ke layar
    Vector3 headScreen = WorldToScreenPoint(mainInstance, Vector3(enemyPos3D.x, enemyPos3D.y + 1.6f, enemyPos3D.z));
    if (headScreen.z < 1.f) continue;

    ImVec2 enemyPos2D(headScreen.x, glHeight - headScreen.y);

    // Hitung jarak ke crosshair (2D)
    float screenDist = sqrtf(
        powf(enemyPos2D.x - screenCenter.x, 2) +
        powf(enemyPos2D.y - screenCenter.y, 2)
    );

    // Cek dalam FOV
    if (screenDist <= AimFovRadius) {
        // Gabungan 3D + 2D (crosshair)
        float combinedDist = dist3D + screenDist;

        if (combinedDist < nearestDistance) {
            nearestDistance = combinedDist;
            nearestTargetv = monster;
        }
    }
}

}

// --- Update target global ---
nearestAimTargetMontester = nearestTargetv;

// --- Draw FOV Circle ---
if (AimBotVisual && ShowFovCircle) {
    Draw::DrawCircle(screenCenter.x, screenCenter.y, AimFovRadius, false, ImVec4(0.f, 1.f, 0.f, 0.5f));
}

// --- Draw Aim Line ---
if (AimBotVisual && ShowAimLine && nearestTargetv) {
    Vector3 pos = getPosition(nearestTargetv);
    Vector3 headScreen = WorldToScreenPoint(mainInstance, Vector3(pos.x, pos.y + 1.6f, pos.z));

    ImVec2 head2D(headScreen.x, glHeight - headScreen.y);

    // Garis dari center ke kepala target
    Draw::DrawLine(screenCenter, head2D, ImVec4(1.f, 0.f, 0.f, 1.f), 2.f);

    // Lingkaran di kepala target
    Draw::DrawCircle(head2D.x, head2D.y, 6.0f, true, ImVec4(1.f, 1.f, 0.f, 1.f));
}
}
// --- Draw ESP untuk ChestBox (Safe) ---
void DrawDynamicIsland()
{
    ImVec2 screenCenter(glWidth * 0.5f, 35.0f);
    float islandWidth  = 260.0f;
    float islandHeight = 42.0f;
    float rounding     = 16.0f;

    ImVec2 topLeft(screenCenter.x - islandWidth / 2, screenCenter.y - islandHeight / 2);
    ImVec2 bottomRight(screenCenter.x + islandWidth / 2, screenCenter.y + islandHeight / 2);

    ImDrawList* drawList = ImGui::GetBackgroundDrawList();

    // Warna tema: gelap matte + aksen biru muda
    ImU32 bgColor       = IM_COL32(25, 25, 25, 220);
    ImU32 borderColor   = IM_COL32(90, 140, 255, 200);
    ImU32 glowColor     = IM_COL32(90, 140, 255, 40);
    ImU32 textColor     = IM_COL32(235, 235, 245, 255);
    ImU32 shadowColor   = IM_COL32(0, 0, 0, 180);

    // Lapisan glow lembut di belakang island
    drawList->AddRectFilled(ImVec2(topLeft.x - 3, topLeft.y - 3),
                            ImVec2(bottomRight.x + 3, bottomRight.y + 3),
                            glowColor, rounding + 4);

    // Background dan border
    drawList->AddRectFilled(topLeft, bottomRight, bgColor, rounding);
    drawList->AddRect(topLeft, bottomRight, borderColor, rounding, 0, 1.5f);

    // Hitung entitas
    int playerCount = 0;
    for (auto player : players) {
        if (!player) continue;
    
        PlayerInfo info = GetPlayerInfo(player);
        if (!IsPlayerDead(player)) continue;
        if (info.isEscaped) continue;
    
        playerCount++;
    }

    int chestCount = 0;
    for (auto c : chests)
        if (c)
            chestCount++;

    int monsterCount = 0;
    for (auto m : monsters)
        if (m && !IsMonsterDead(m))
            monsterCount++;

    // Format teks
    std::string text =
        "P " + std::to_string(playerCount) +
        "  •  C " + std::to_string(chestCount) +
        "  •  M " + std::to_string(monsterCount);

    ImVec2 textSize = ImGui::CalcTextSize(text.c_str());
    ImVec2 textPos(screenCenter.x - textSize.x / 2, screenCenter.y - textSize.y / 2);

    // Shadow tipis + teks utama
    drawList->AddText(ImVec2(textPos.x + 1, textPos.y + 1), shadowColor, text.c_str());
    drawList->AddText(textPos, textColor, text.c_str());
}
void (*old_set_fieldOfView)(void* instance, float value) = nullptr;
void hk_set_fieldOfView(void* instance, float value) {
    if (FovEnabled) value = g_CameraFov;
    if (old_set_fieldOfView) old_set_fieldOfView(instance, value);
}
// ---------- Hook target ----------


bool AirJumpHackEnabled = false;


int (*old_GetMaxAirJumpCount)(void* instance, bool check) = nullptr;

int hk_GetMaxAirJumpCount(void* instance, bool check) {
    int result = 109;

    if (!AirJumpHackEnabled && old_GetMaxAirJumpCount) {
        result = old_GetMaxAirJumpCount(instance, check);
    }

    return result;
}

// Pasang hook

// pasang hook
// global pointer ke local player




void (*orig_setbantype_BlacklistOpReq)(Il2CppObject* _this, int value);
void Hook_setbantype_BlacklistOpReq(Il2CppObject* _this, int value) {
   
    orig_setbantype_BlacklistOpReq(_this, 2); // force UNBAN
}
void (*orig_setbantype_ProhibitOpReq)(Il2CppObject* _this, int value);
void Hook_setbantype_ProhibitOpReq(Il2CppObject* _this, int value) {
   
    orig_setbantype_ProhibitOpReq(_this, 2); // force UNBAN
}
int (*orig_get_ban_type)(void* self);

int Hook_get_ban_type(void* self) {
    return 2;
}
int (*orig_get_ban_type_prohibit)(void* self);

int Hook_get_ban_type_prohibit(void* self) {
    return 2; // UNBAN
}
void InitUnbanBypass() {
// // Hooks untuk ProhibitOpReq
// Tools::Hook(
    // (void*)Il2CppGetMethodOffset("Exported.dll", "proto", "ProhibitOpReq", "get_ban_type", 0),
    // (void*)Hook_get_ban_type_prohibit,
    // (void**)&orig_get_ban_type_prohibit
// );

// Tools::Hook(
    // (void*)Il2CppGetMethodOffset("Exported.dll", "proto", "ProhibitOpReq", "setbantype", 1),
    // (void*)Hook_setbantype_ProhibitOpReq,
    // (void**)&orig_setbantype_ProhibitOpReq
// );

// // Hooks untuk BlacklistOpReq
// Tools::Hook(
    // (void*)Il2CppGetMethodOffset("Exported.dll", "proto", "BlacklistOpReq", "get_ban_type", 0),
    // (void*)Hook_get_ban_type,
    // (void**)&orig_get_ban_type
// );

// Tools::Hook(
    // (void*)Il2CppGetMethodOffset("Exported.dll", "proto", "BlacklistOpReq", "setbantype", 1),
    // (void*)Hook_setbantype_BlacklistOpReq,
    // (void**)&orig_setbantype_BlacklistOpReq
// );

   
}

bool (*orig_CheckIsFinishBeginnerLevel)(Il2CppObject* _this);
bool Hook_CheckIsFinishBeginnerLevel(Il2CppObject* _this) {
   
    return true;
}
bool (*orig_get_CalculateRankPoint)(Il2CppObject* _this);
bool Hook_get_CalculateRankPoint(Il2CppObject* _this) {
   
    return true;
}
void (*orig_set_CalculateRankPoint)(Il2CppObject* _this, bool value);
void Hook_set_CalculateRankPoint(Il2CppObject* _this, bool value) {
    
    orig_set_CalculateRankPoint(_this, true);
}
uint32_t (*orig_get_PlayerLv)(Il2CppObject* _this);
uint32_t Hook_get_PlayerLv(Il2CppObject* _this) {
    if (level50) {
    
    return 50;
    }
    return orig_get_PlayerLv(_this);
}
bool (*orig_get_IsGuest)(Il2CppObject* _this);
bool Hook_get_IsGuest(Il2CppObject* _this) {
    
    return false;
}
void InitAccountServiceBypass() {
    

    // Tools::Hook(
        // (void*)Il2CppGetMethodOffset("KradGame.dll", "KradGame", "AccountService", "get_IsGuest", 0),
        // (void*)Hook_get_IsGuest,
        // (void**)&orig_get_IsGuest
    // );

    // Tools::Hook(
        // (void*)Il2CppGetMethodOffset("KradGame.dll", "KradGame", "AccountService", "CheckIsFinishBeginnerLevel", 0),
        // (void*)Hook_CheckIsFinishBeginnerLevel,
        // (void**)&orig_CheckIsFinishBeginnerLevel
    // );

    // Tools::Hook(
        // (void*)Il2CppGetMethodOffset("KradGame.dll", "KradGame", "AccountService", "get_CalculateRankPoint", 0),
        // (void*)Hook_get_CalculateRankPoint,
        // (void**)&orig_get_CalculateRankPoint
    // );

    // Tools::Hook(
        // (void*)Il2CppGetMethodOffset("KradGame.dll", "KradGame", "AccountService", "set_CalculateRankPoint", 1),
        // (void*)Hook_set_CalculateRankPoint,
        // (void**)&orig_set_CalculateRankPoint
    // );

    
}

Il2CppObject* (*orig_build_ace_account)(bool _sandbox, uint32_t _server_id, uint64_t LoginAccountID);
Il2CppObject* Hook_build_ace_account(bool _sandbox, uint32_t _server_id, uint64_t LoginAccountID) {
    
    return orig_build_ace_account(true, _server_id, LoginAccountID);
}
void InitBuildAceAccountBypass() {
    // Tools::Hook(
        // (void*)Il2CppGetMethodOffset("KradGame.dll", "KradGame", "AccountService", "build_ace_account", 3),
        // (void*)Hook_build_ace_account,
        // (void**)&orig_build_ace_account
    // );

    
}

float (*orig_get_AttackSpeed)(void* self);

float Hook_get_AttackSpeed(void* self) {
    float result = orig_get_AttackSpeed(self);

    // Clamp atau override
    result = 10.0f;
    // result = 99.99f; // optional override

    return result;
}
void (*orig_PlayAnim)(void* self, Il2CppString* animAliasName, int animType, float startPos, float speed, float blendPeriod, float fadeoutPeriod, bool alwaysAnimate);

void Hook_PlayAnim(void* self, Il2CppString* animAliasName, int animType, float startPos, float speed, float blendPeriod, float fadeoutPeriod, bool alwaysAnimate) {
    // Override speed
    speed = 10.0f;

    // Lanjut ke original
    orig_PlayAnim(self, animAliasName, animType, startPos, speed, blendPeriod, fadeoutPeriod, alwaysAnimate);
}
bool spoofNick = false; 
Il2CppString* (*orig_get_NickName)(void* self);
Il2CppString* (*orig_get_nickname)(void* self);

// Hook untuk NickName
Il2CppString* Hook_get_NickName(void* self) {
    if (!spoofNick) {// kalau toggle off -> balik ke ori
        return orig_get_NickName(self);
        } else {
    return Il2CppString::CreateMonoString("VENDORA");
    }
}

// Hook untuk nickname
Il2CppString* Hook_get_nickname(void* self) {
    if (!spoofNick) {
        return orig_get_nickname(self);
        } else {
    return Il2CppString::CreateMonoString("VENDORA");
    }
}
float g_SkillPlaySpeed = 1.0f;
bool g_OverrideSkillSpeed = false;
float (*orig_GetSkillPlaySpeed)(Il2CppObject* _this, float bonus, void* characterLogic, void* skillRecord);
float Hook_GetSkillPlaySpeed(Il2CppObject* _this, float bonus, void* characterLogic, void* skillRecord) {
    if (g_OverrideSkillSpeed) {

        return g_SkillPlaySpeed;
    }
    return orig_GetSkillPlaySpeed(_this, bonus, characterLogic, skillRecord);
}
void InitSkillLogicHook() {
    void* offset = Il2CppGetMethodOffset("KradGame.dll", "KradGame.Logic", "SkillLogic", "GetSkillPlaySpeed", 3);
    if (offset) {
        Tools::Hook(offset, (void*)Hook_GetSkillPlaySpeed, (void**)&orig_GetSkillPlaySpeed);
        
    } else {
        
    }
}
bool (*orig_get_IsLocked)(Il2CppObject* _this);
bool Hook_get_IsLocked(Il2CppObject* _this) {
    
    return false;
}
void InitSkillRepDataLockBypass() {
    void* offset = Il2CppGetMethodOffset("KradGame.dll", "KradGame.Logic", "CompLockable", "IsSkillLocked", 1);
    if (offset) {
        Tools::Hook(offset, (void*)Hook_get_IsLocked, (void**)&orig_get_IsLocked);
        
    } else {
        
    }
}

void (*orig_AttributeData_Init)(Il2CppObject* _this, int id, float initV, float maxV, float minV, float classBonus);

void Hook_AttributeData_Init(Il2CppObject* _this, int id, float initV, float maxV, float minV, float classBonus) {
    
    orig_AttributeData_Init(_this, id, 999.0f, 999.0f, 999.0f, 999.0f);
}
void InitAttributeDataHook() {
    void* offset = Il2CppGetMethodOffset("KradGame.dll", "KradGame.Logic", "AttributeData", "Init", 5);
    if (offset) {
        Tools::Hook(offset, (void*)Hook_AttributeData_Init, (void**)&orig_AttributeData_Init);
        
    } else {
        
    }
}
bool noCollision = true;

void (*orig_set_detectCollisions)(void* instance, bool value);
void (*orig_IgnoreCollision)(void* collider1, void* collider2, bool ignore);
void (*orig_ChangeIgnoreCollision_PEntity)(void* instance, bool isIgnore);
void (*orig_InitCollision_PEntity)(void* instance, void* root, bool enable);
void (*orig_ChangeIgnoreCollision_PresentationManager)(void* instance, uint32_t logicId, bool isIgnore);
void (*orig_ChangeIgnoreCollision_PresentCharacter)(void* instance, bool isIgnore);
void (*orig_InitCollision_PresentMonster)(void* instance, void* root, bool enable);
void (*orig_ChangeIgnoreCollision_PresentMonster)(void* instance, bool isIgnore);

void hk_set_detectCollisions(void* instance, bool value) {
    if (noCollision) value = false;
    orig_set_detectCollisions(instance, value);
}

void hk_IgnoreCollision(void* collider1, void* collider2, bool ignore) {
    if (noCollision) ignore = true;
    orig_IgnoreCollision(collider1, collider2, ignore);
}

void hk_ChangeIgnoreCollision_PEntity(void* instance, bool isIgnore) {
    if (noCollision) isIgnore = true;
    orig_ChangeIgnoreCollision_PEntity(instance, isIgnore);
}

void hk_InitCollision_PEntity(void* instance, void* root, bool enable) {
    if (noCollision) enable = false;
    orig_InitCollision_PEntity(instance, root, enable);
}

void hk_ChangeIgnoreCollision_PresentationManager(void* instance, uint32_t logicId, bool isIgnore) {
    if (noCollision) isIgnore = true;
    orig_ChangeIgnoreCollision_PresentationManager(instance, logicId, isIgnore);
}

void hk_ChangeIgnoreCollision_PresentCharacter(void* instance, bool isIgnore) {
    if (noCollision) isIgnore = true;
    orig_ChangeIgnoreCollision_PresentCharacter(instance, isIgnore);
}

void hk_InitCollision_PresentMonster(void* instance, void* root, bool enable) {
    if (noCollision) enable = false;
    orig_InitCollision_PresentMonster(instance, root, enable);
}

void hk_ChangeIgnoreCollision_PresentMonster(void* instance, bool isIgnore) {
    if (noCollision) isIgnore = true;
    orig_ChangeIgnoreCollision_PresentMonster(instance, isIgnore);
}

void InitNoCollisionHook() {
    

    void* m3 = (void*)Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame"),
        OBFUSCATE("PEntity"),
        OBFUSCATE("ChangeIgnoreCollision"),
        1
    );

    void* m4 = (void*)Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame"),
        OBFUSCATE("PEntity"),
        OBFUSCATE("InitCollision"),
        2
    );

    void* m5 = (void*)Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame"),
        OBFUSCATE("PresentationManager"),
        OBFUSCATE("ChangeIgnoreCollision"),
        2
    );

    void* m6 = (void*)Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame"),
        OBFUSCATE("PresentCharacter"),
        OBFUSCATE("ChangeIgnoreCollision"),
        1
    );

    void* m7 = (void*)Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame"),
        OBFUSCATE("PresentMonster"),
        OBFUSCATE("InitCollision"),
        2
    );

    void* m8 = (void*)Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame"),
        OBFUSCATE("PresentMonster"),
        OBFUSCATE("ChangeIgnoreCollision"),
        1
    );


    if (m3) Tools::Hook(m3, (void*)hk_ChangeIgnoreCollision_PEntity, (void**)&orig_ChangeIgnoreCollision_PEntity);
    if (m4) Tools::Hook(m4, (void*)hk_InitCollision_PEntity, (void**)&orig_InitCollision_PEntity);
    if (m5) Tools::Hook(m5, (void*)hk_ChangeIgnoreCollision_PresentationManager, (void**)&orig_ChangeIgnoreCollision_PresentationManager);
    if (m6) Tools::Hook(m6, (void*)hk_ChangeIgnoreCollision_PresentCharacter, (void**)&orig_ChangeIgnoreCollision_PresentCharacter);
    if (m7) Tools::Hook(m7, (void*)hk_InitCollision_PresentMonster, (void**)&orig_InitCollision_PresentMonster);
    if (m8) Tools::Hook(m8, (void*)hk_ChangeIgnoreCollision_PresentMonster, (void**)&orig_ChangeIgnoreCollision_PresentMonster);
}

bool infiniteAmmo = false;

bool unlimitedStats = false;

float (*orig_get_CurrEnergy1)(void*);
float (*orig_get_MaxEnergy1)(void*);
int   (*orig_get_CurrEnergyType2)(void*);
float (*orig_get_CurrEnergy2)(void*);
float (*orig_get_MaxEnergy2)(void*);
float (*orig_get_CurrStamina)(void*);
float (*orig_get_InitMaxStamina)(void*);
float (*orig_get_MaxStamina)(void*);

float hk_get_CurrEnergy1(void* self) {
    if (unlimitedStats)
        return orig_get_MaxEnergy1(self);
    return orig_get_CurrEnergy1(self);
}

float hk_get_CurrEnergy2(void* self) {
    if (unlimitedStats)
        return orig_get_MaxEnergy2(self);
    return orig_get_CurrEnergy2(self);
}

float hk_get_CurrStamina(void* self) {
    if (unlimitedStats)
        return orig_get_MaxStamina(self);
    return orig_get_CurrStamina(self);
}

void InitCharacterLogicHook() {
    void* ptrCurrEnergy1 = (void*)Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame.Logic"),
        OBFUSCATE("CharacterLogic"),
        OBFUSCATE("get_CurrEnergy1"),
        0
    );

    void* ptrMaxEnergy1 = (void*)Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame.Logic"),
        OBFUSCATE("CharacterLogic"),
        OBFUSCATE("get_MaxEnergy1"),
        0
    );

    void* ptrCurrEnergy2 = (void*)Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame.Logic"),
        OBFUSCATE("CharacterLogic"),
        OBFUSCATE("get_CurrEnergy2"),
        0
    );

    void* ptrMaxEnergy2 = (void*)Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame.Logic"),
        OBFUSCATE("CharacterLogic"),
        OBFUSCATE("get_MaxEnergy2"),
        0
    );

    void* ptrCurrStamina = (void*)Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame.Logic"),
        OBFUSCATE("CharacterLogic"),
        OBFUSCATE("get_CurrStamina"),
        0
    );

    void* ptrMaxStamina = (void*)Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame.Logic"),
        OBFUSCATE("CharacterLogic"),
        OBFUSCATE("get_MaxStamina"),
        0
    );

    if (ptrCurrEnergy1)
        Tools::Hook(ptrCurrEnergy1, (void*)hk_get_CurrEnergy1, (void**)&orig_get_CurrEnergy1);
    if (ptrMaxEnergy1)
        orig_get_MaxEnergy1 = (float (*)(void*))ptrMaxEnergy1;
    if (ptrCurrEnergy2)
        Tools::Hook(ptrCurrEnergy2, (void*)hk_get_CurrEnergy2, (void**)&orig_get_CurrEnergy2);
    if (ptrMaxEnergy2)
        orig_get_MaxEnergy2 = (float (*)(void*))ptrMaxEnergy2;
    if (ptrCurrStamina)
        Tools::Hook(ptrCurrStamina, (void*)hk_get_CurrStamina, (void**)&orig_get_CurrStamina);
    if (ptrMaxStamina)
        orig_get_MaxStamina = (float (*)(void*))ptrMaxStamina;
}
#include <mutex>
#include <algorithm>

// Cleanup
void GlobalCleanup() {
    players.clear();
    monsters.clear();
    chests.clear();

    myPlayer = nullptr;
    nearestAimTarget = nullptr;
    nearestAimTargetMontester = nullptr;

    {
        std::lock_guard<std::mutex> lockHp(g_hpMutex);
        g_PlayerHpMap.clear();
    }
    {
        std::lock_guard<std::mutex> lockNick(g_nickMutex);
        g_PlayerNickMap.clear();
    }
    {
        std::lock_guard<std::mutex> lockTeamId(g_teamIdMutex);
        g_PlayerTeamIdMap.clear();
    }
    {
        std::lock_guard<std::mutex> lockAmmo(g_ammoMutex);
        g_PlayerAmmoMap.clear();
    }
    {
        std::lock_guard<std::mutex> lockUserId(g_userIdMutex);
        g_PlayerUserIdMap.clear();
    }
    {
        std::lock_guard<std::mutex> lockEscaped(g_escapedMutex);
        g_PlayerEscapedMap.clear();
    }
    {
        std::lock_guard<std::mutex> lockMainWeapon(g_mainWeaponMutex);
        g_PlayerMainWeaponMap.clear();
    }
    {
        std::lock_guard<std::mutex> lockSubWeapon(g_subWeaponMutex);
        g_PlayerSubWeaponMap.clear();
    }
    {
        std::lock_guard<std::mutex> lockActiveWeaponSlot(g_activeWeaponSlotMutex);
        g_PlayerActiveWeaponSlotMap.clear();
    }
    {
        std::lock_guard<std::mutex> lockTarget(g_targetMapMutex);
        g_TargetLogicMap.clear();
    }
    {
        std::lock_guard<std::mutex> lockMatchPlayerInstance(g_matchPlayerInstanceMutex);
        g_PlayerMatchPlayerInstanceMap.clear();
    }
    {
        std::lock_guard<std::mutex> lockMainWeaponInstance(g_mainWeaponInstanceMutex);
        g_PlayerMainWeaponInstanceMap.clear();
    }
    {
        std::lock_guard<std::mutex> lockSubWeaponInstance(g_subWeaponInstanceMutex);
        g_PlayerSubWeaponInstanceMap.clear();
    }
    {
        std::lock_guard<std::mutex> lockPlayerInfo(g_PlayerInfoMutex);
        g_PlayerList.clear();
    }
}
void (*old_Player_OnDestroy)(void* thiz_);

void (*old_MatchGame_OnDestroy)(void* thiz_);
void (*old_MatchGame_FinishMatch)(void* thiz_);
void hk_PlayerDestroy(void* thiz_) {
    if (thiz_) {
        GlobalCleanup();
        
        if (old_Player_OnDestroy)
            old_Player_OnDestroy(thiz_);
    }
}

void hk_MatchGame_OnDestroy(void* thiz_) {
    if (thiz_) {
        GlobalCleanup();

        if (old_MatchGame_OnDestroy)
            old_MatchGame_OnDestroy(thiz_);
    }
}

// Hook FinishMatch (MatchGame::FinishMatch)
void hk_MatchGame_FinishMatch(void* thiz_) {
    if (thiz_) {
        GlobalCleanup();

        if (old_MatchGame_FinishMatch)
            old_MatchGame_FinishMatch(thiz_);
    }
}
void (*old_LobbyGame_OnDestroy)(void* thiz_);

void hk_LobbyGame_OnDestroy(void* thiz_) {
    if (thiz_) {
       GlobalCleanup();
        if (old_LobbyGame_OnDestroy)
            old_LobbyGame_OnDestroy(thiz_);
    }
}
void (*old_Chest_OnDestroy)(void* thiz_);
void hk_ChestDestroy(void* thiz_) {
    if (thiz_) {
                GlobalCleanup();
        if (old_Chest_OnDestroy)
            old_Chest_OnDestroy(thiz_);
    }
}
void (*old_MonsterDestroy)(void* thiz);
void hk_MonsterDestroy(void* thiz) {
    if (thiz) GlobalCleanup();
    if (old_MonsterDestroy) old_MonsterDestroy(thiz);
}

void InitPlayerDestroyHook() {
    void* playerDestroyOffset = (void*)Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame"),
        OBFUSCATE("PresentationManager"),
        OBFUSCATE("OnCleanUp"),
        0
    );

    if (playerDestroyOffset)
        Tools::Hook(playerDestroyOffset, (void*)hk_PlayerDestroy, (void**)&old_Player_OnDestroy);
     
    void* onDestroyOffset = (void*)Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame"),
        OBFUSCATE("MatchGame"),
        OBFUSCATE("OnDestroy"),
        0
    );

    void* finishMatchOffset = (void*)Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame"),
        OBFUSCATE("MatchGame"),
        OBFUSCATE("FinishMatch"),
        0
    );

    if (onDestroyOffset)
        Tools::Hook(onDestroyOffset, (void*)hk_MatchGame_OnDestroy, (void**)&old_MatchGame_OnDestroy);

    if (finishMatchOffset)
        Tools::Hook(finishMatchOffset, (void*)hk_MatchGame_FinishMatch, (void**)&old_MatchGame_FinishMatch);
        
    void* lobbyDestroyOffset = (void*)Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame"),
        OBFUSCATE("LobbyGame"),
        OBFUSCATE("OnDestroy"),
        0
    );

    if (lobbyDestroyOffset)
        Tools::Hook(lobbyDestroyOffset, (void*)hk_LobbyGame_OnDestroy, (void**)&old_LobbyGame_OnDestroy);
        
    void* chestDestroyOffset = (void*)Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame"),
        OBFUSCATE("PresentChestBox"),
        OBFUSCATE("OnDestroy"),
        0
    );

    if (chestDestroyOffset)
        Tools::Hook(chestDestroyOffset, (void*)hk_ChestDestroy, (void**)&old_Chest_OnDestroy);
        
    void* monsterDestroy = Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame"),
        OBFUSCATE("PresentMonster"),
        OBFUSCATE("OnDestroy"),
        0
    );
        if (monsterDestroy)
        Tools::Hook(monsterDestroy, (void*)hk_MonsterDestroy, (void**)&old_MonsterDestroy);
}
// ===== Global =====

bool UnlockFPS = true;

bool (*orig_SupportVeryHighFPS)(void* self);

bool hk_SupportVeryHighFPS(void* self) {
    if (UnlockFPS)
        return true;
    return orig_SupportVeryHighFPS(self);
}


void (*orig_SetFPSLevel)(void* self, int _lv); 

void hk_SetFPSLevel(void* self, int _lv) {
    orig_SetFPSLevel(self, 3);
}

void Hook_FPS_Level() {
    void* addr = Il2CppGetMethodOffset(
        OBFUSCATE("GCommon.dll"),
        OBFUSCATE("GCommon"),
        OBFUSCATE("QualityManager"),
        OBFUSCATE("SetFPSLevel"),
        1
    );

    if (addr)
        Tools::Hook(addr, (void*)hk_SetFPSLevel, (void**)&orig_SetFPSLevel);
}
void Hook_FPS() {
Hook_FPS_Level();
    void* addr = Il2CppGetMethodOffset(
        OBFUSCATE("GCommon.dll"),
        OBFUSCATE("GCommon"),
        OBFUSCATE("QualityManager"),
        OBFUSCATE("SupportVeryHighFPS"),
        0
    );

    if (addr)
        Tools::Hook(addr, (void*)hk_SupportVeryHighFPS, (void**)&orig_SupportVeryHighFPS);
}
void* (*orig_GetColliderHelper)(void* instance, int bodyPart);

void* hk_GetColliderHelper(void* instance, int bodyPart) {

    return orig_GetColliderHelper(instance, 1);
}
void Install_GetColliderHelperHook() {
    void* addr = (void*)Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame"),
        OBFUSCATE("PEntity"),
        OBFUSCATE("GetColliderHelper"),
        1
    );
    if (addr) {
        Tools::Hook(addr, (void*)hk_GetColliderHelper, (void**)&orig_GetColliderHelper);
    }
}

float customJump = 2.0f;

void (*orig_Jump2)(void* instance);
Vector3 (*GetPosition2)(void* instance);
void (*SetPosition2)(void* instance, Vector3 pos);

void hk_Jump2(void* instance) {
    if (!instance) return;

   
    orig_Jump2(instance);
    if (highJump2) {
  
    if (!GetPosition2) {
        GetPosition2 = (Vector3 (*)(void*))Il2CppGetMethodOffset(
            OBFUSCATE("KradGame.dll"),
            OBFUSCATE("KradGame.Logic"),
            OBFUSCATE("CharacterMovementProxy"),
            OBFUSCATE("GetPosition"),
            0
        );
    }

    if (!SetPosition2) {
        SetPosition2 = (void (*)(void*, Vector3))Il2CppGetMethodOffset(
            OBFUSCATE("KradGame.dll"),
            OBFUSCATE("KradGame.Logic"),
            OBFUSCATE("CharacterMovementProxy"),
            OBFUSCATE("OnTeleport"),
            1
        );
    }

   
    if (GetPosition2 && SetPosition2) {
        Vector3 pos = GetPosition2(instance);
        pos.y += customJump;
        SetPosition2(instance, pos);
    }
    }
}

void Hook_CharacterMovementProxy_Jump2() {

    void* addr = Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame.Logic"),
        OBFUSCATE("CharacterMovementProxy"),
        OBFUSCATE("Jump"),
        0
    );

    if (addr)
        Tools::Hook(addr, (void*)hk_Jump2, (void**)&orig_Jump2);
}

void Hook_CharacterMovementProxy_UpdateMovement() {
    Hook_CharacterMovementProxy_Jump2();
}
float customJump3 = 500.0f;
void* (*old_GameVarGetter_Getter)(void* instance);

void* GameVarGetter_Getter(void* instance) {
    if (!instance)
        return nullptr;

    void* cfg = old_GameVarGetter_Getter(instance);

  
    size_t dataOffset = Il2CppGetFieldOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame.Utils"),
        OBFUSCATE("GameVarGetter"),
        OBFUSCATE("Data")
    );

    if (!dataOffset)
        return cfg;

    uintptr_t dataPtr = *(uintptr_t*)((uintptr_t)instance + dataOffset);
    if (!dataPtr)
        return cfg;

    uintptr_t o_CharacterJumpSpeed       = 0x10;
    uintptr_t o_CharacterJumpUpGravity   = 0x14;
    uintptr_t o_CharacterJumpDownGravity = 0x18;
    uintptr_t o_MaximumJumpHeightLimit   = 0x50;
    uintptr_t o_airjumdown1   = 0x98;
    uintptr_t o_airjumdown   = 0x1c;
    

    if (highJump3) {
       *(float*)(dataPtr + o_CharacterJumpSpeed)       = 9999.0f;
        *(float*)(dataPtr + o_CharacterJumpUpGravity)   = -9999.0f;
        *(float*)(dataPtr + o_CharacterJumpDownGravity) = -9999.0f;
        *(float*)(dataPtr + o_MaximumJumpHeightLimit)   = customJump3;
        *(float*)(dataPtr + o_airjumdown1) = -9999.0f;
        *(float*)(dataPtr + o_airjumdown) = -9999.0f;
    } else {
    }
    

    return cfg;
}



void Hook_GameVarGetter_Getter() {
    Tools::Hook(
        (void*)(uintptr_t)Il2CppGetMethodOffset(
            OBFUSCATE("KradGame.dll"),
            OBFUSCATE("KradGame.Utils"),
            OBFUSCATE("GameVarGetter"),
            OBFUSCATE("Getter"),
            0
        ),
        (void*)GameVarGetter_Getter,
        (void**)&old_GameVarGetter_Getter
    );
}
// Original function pointer
void (*orig_CullStateChanged)(void* instance, bool _vis, int _lod);

// Hook function
void hk_CullStateChanged(void* instance, bool _vis, int _lod) {
    // Paksa vis selalu true
    _vis = true;

    // Bisa juga kalau mau nonaktifkan LOD otomatis:
    _lod = 0;

    // Lanjut ke original biar sistem gak curiga
    orig_CullStateChanged(instance, _vis, _lod);
}

// Panggil hook ini di inisialisasi kamu
void Hook_PEntity_CullStateChanged() {
    Tools::Hook(
        (void*)(uintptr_t)Il2CppGetMethodOffset(
            OBFUSCATE("KradGame.dll"),
            OBFUSCATE("KradGame"),
            OBFUSCATE("PresentCharacter"),
            OBFUSCATE("CullStateChanged"),
            2 // param count: bool, int
        ),
        (void*)hk_CullStateChanged,
        (void**)&orig_CullStateChanged
    );
}


typedef void (*PlayHitEffect_t)(void* instance, uint32_t casterID, uint32_t targetID,
                                int hitEffectType, Vector3 rayStartPoint,
                                int hitPart, Vector3 fxConfigAngle,
                                float time, float speed);

PlayHitEffect_t orig_PlayHitEffect = nullptr;

void hk_PlayHitEffect(void* instance, uint32_t casterID, uint32_t targetID,
                      int hitEffectType, Vector3 rayStartPoint,
                      int hitPart, Vector3 fxConfigAngle,
                      float time, float speed)
{
    if (!instance) {
        if (orig_PlayHitEffect)
            orig_PlayHitEffect(instance, casterID, targetID, hitEffectType, rayStartPoint, hitPart, fxConfigAngle, time, speed);
        return;
    }

    // Jalankan efek untuk semua player
    for (auto* player : players) {
        if (!player) continue;

        uint32_t logicId = get_LogicId(player); // pastikan kamu punya fungsi ini
        orig_PlayHitEffect(instance, casterID, logicId, hitEffectType, rayStartPoint, 1, fxConfigAngle, time, 999.0f);
    }

    // Jalankan efek untuk semua monster
    for (auto* monster : monsters) {
        if (!monster) continue;

        uint32_t logicId = get_LogicId(monster); // sama seperti player
        orig_PlayHitEffect(instance, casterID, logicId, hitEffectType, rayStartPoint, 1, fxConfigAngle, time, 999.0f);
    }
}

void InitPlayHitEffectHook() {
    void* playHitEffectOffset = Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame"),
        OBFUSCATE("CompHit"),
        OBFUSCATE("PlayHitEffect"),
        8 // jumlah argumen
    );

    if (playHitEffectOffset) {
        Tools::Hook((void*)playHitEffectOffset, (void*)hk_PlayHitEffect, (void**)&orig_PlayHitEffect);
    }
}


static bool g_EnableSkillTrue = false;
static bool g_DisableSkillHold = false;

bool (*orig_IsSkillEnableWithWeapon)(void* instance, int skillSlot);
bool (*orig_GetSkillIsHolding)(int skillSlot);

bool hook_IsSkillEnableWithWeapon(void* instance, int skillSlot) {
    if (g_EnableSkillTrue)
        return true;
    return orig_IsSkillEnableWithWeapon(instance, skillSlot);
}

bool hook_GetSkillIsHolding(int skillSlot) {
    if (g_DisableSkillHold)
        return false;
    return orig_GetSkillIsHolding(skillSlot);
}



void InitSkillHook() {
    void* addrEnable = (void*)Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame"),
        OBFUSCATE("InGameSkillService"),
        OBFUSCATE("IsSkillEnableWithWeapon"),
        1
    );

    void* addrHold = (void*)Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame"),
        OBFUSCATE("InGameSkillService"),
        OBFUSCATE("GetSkillIsHolding"),
        1
    );

    Tools::Hook(addrEnable, (void*)&hook_IsSkillEnableWithWeapon, (void**)&orig_IsSkillEnableWithWeapon);
    Tools::Hook(addrHold, (void*)&hook_GetSkillIsHolding, (void**)&orig_GetSkillIsHolding);
}

bool g_DurabilityToggle = false;

void (*orig_set_Durablity)(void* instance, uint32_t value);
void hook_set_Durablity(void* instance, uint32_t value) {
    if (g_DurabilityToggle)
        value = 999;
    orig_set_Durablity(instance, value);
}

uint32_t (*orig_get_Durablity)(void* instance);
uint32_t hook_get_Durablity(void* instance) {
    if (g_DurabilityToggle)
        return 999;
    return orig_get_Durablity(instance);
}

void (*orig_OnDurablityChange)(void* instance, uint8_t varID, uint32_t oldvalue, uint32_t newvalue);
void hook_OnDurablityChange(void* instance, uint8_t varID, uint32_t oldvalue, uint32_t newvalue) {
    if (g_DurabilityToggle) {
        oldvalue = 999;
        newvalue = 999;
    }
    orig_OnDurablityChange(instance, varID, oldvalue, newvalue);
}

void HookDurability() {
    const char* dll = OBFUSCATE("KradGame.dll");
    const char* ns = OBFUSCATE("KradGame.Logic");

    void* setRepDataFunc = (void*)Il2CppGetMethodOffset(dll, ns, OBFUSCATE("ItemRepData"), OBFUSCATE("set_Durablity"), 1); 
    void* getRepDataFunc = (void*)Il2CppGetMethodOffset(dll, ns, OBFUSCATE("ItemRepData"), OBFUSCATE("get_Durablity"), 0); 
    void* changeLogicFunc = (void*)Il2CppGetMethodOffset(dll, ns, OBFUSCATE("ItemLogic"), OBFUSCATE("OnDurablityChange"), 3);

    if (setRepDataFunc)
        Tools::Hook(setRepDataFunc, (void*)&hook_set_Durablity, (void**)&orig_set_Durablity);
    
    if (getRepDataFunc)
        Tools::Hook(getRepDataFunc, (void*)&hook_get_Durablity, (void**)&orig_get_Durablity);
    
    if (changeLogicFunc)
        Tools::Hook(changeLogicFunc, (void*)&hook_OnDurablityChange, (void**)&orig_OnDurablityChange);
}
std::unordered_map<uint32_t, void*> g_PresentPickupItems;

void (*orig_OnUpdate_PresentPickupItem)(void* instance, float gameTime, float deltaTime);
void (*set_Position_PresentPickupItem)(void* instance, Vector3 value);
uint32_t (*get_RefItemLogicId)(void* instance);

// tambahan: pointer ke SetNeedFallShow
void (*set_NeedFallShow_PresentPickupItem)(void* instance);

void hook_OnUpdate_PresentPickupItem(void* instance, float gameTime, float deltaTime)
{
    if (!instance || !get_RefItemLogicId || !orig_OnUpdate_PresentPickupItem)
    {
        if (orig_OnUpdate_PresentPickupItem)
            orig_OnUpdate_PresentPickupItem(instance, gameTime, deltaTime);
        return;
    }

    uint32_t id = get_RefItemLogicId(instance);
    if (id != 0)
        g_PresentPickupItems[id] = instance;

    // panggil SetNeedFallShow setiap update

    // tetap jalankan original
    orig_OnUpdate_PresentPickupItem(instance, gameTime, deltaTime);
}



void InitPresentPickupItemHooks()
{
    void* onUpdate = Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"), OBFUSCATE("KradGame"),
        OBFUSCATE("PresentPickupItem"), OBFUSCATE("OnUpdate"), 2);

    void* setPos   = Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"), OBFUSCATE("KradGame"),
        OBFUSCATE("PresentPickupItem"), OBFUSCATE("set_Position"), 1);

    void* getLogic = Il2CppGetMethodOffset(
        OBFUSCATE("Exported.dll"), OBFUSCATE("proto"),
        OBFUSCATE("Item"), OBFUSCATE("get_id"), 0);

    

    Tools::Hook(onUpdate, (void*)hook_OnUpdate_PresentPickupItem, (void**)&orig_OnUpdate_PresentPickupItem);
    set_Position_PresentPickupItem     = (decltype(set_Position_PresentPickupItem))setPos;
    get_RefItemLogicId                 = (decltype(get_RefItemLogicId))getLogic;
    
}

static bool tripleDamage = false;
static int damageMultiplier = 3;

typedef void (*OnDamageOut_t)(void* instance, void* msg);
static OnDamageOut_t orig_OnDamageOut = nullptr;

void hook_OnDamageOut(void* instance, void* msg) {
    if (!orig_OnDamageOut) return;
    if (!tripleDamage || damageMultiplier <= 1) {
        orig_OnDamageOut(instance, msg);
        return;
    }
    for (int i = 0; i < damageMultiplier; ++i) {
        orig_OnDamageOut(instance, msg);
    }
}

void InstallHook_DamageFunctions() {
    void* addr1 = Il2CppGetMethodOffset(OBFUSCATE("KradGame.dll"),
                                        OBFUSCATE("KradGame"),
                                        OBFUSCATE("Match"),
                                        OBFUSCATE("OnDamageOut"), 1);
    

    if (addr1)
        DobbyHook(addr1, (void*)hook_OnDamageOut, (void**)&orig_OnDamageOut);

}
bool (*old_PresentInteractCharacter_CanOperationDisplay)(void* instance, int interactType);

bool PresentInteractCharacter_CanOperationDisplay(void* instance, int interactType) {
    // langsung paksa true
    return true;
}

void Hook_PresentInteractCharacter_CanOperationDisplay() {
    Tools::Hook(
        (void*)(uintptr_t)Il2CppGetMethodOffset(
            OBFUSCATE("KradGame.dll"),
            OBFUSCATE("KradGame"),
            OBFUSCATE("PresentInteractCharacter"),
            OBFUSCATE("CanOperationDisplay"),
            1 // overload index, biasanya 0 kalau cuma satu
        ),
        (void*)PresentInteractCharacter_CanOperationDisplay,
        (void**)&old_PresentInteractCharacter_CanOperationDisplay
    );
}
void (*old_EntityEdgeManager_OnUpdate)(void* instance);

void EntityEdgeManager_OnUpdate(void* instance) {
    if (instance) {
        size_t pickupDistOffset = Il2CppGetFieldOffset(
            OBFUSCATE("KradGame.dll"),
            OBFUSCATE("KradGame"),
            OBFUSCATE("EntityEdgeManager"),
            OBFUSCATE("PickupItemDistance")
        );

        size_t pickupDistSqrOffset = Il2CppGetFieldOffset(
            OBFUSCATE("KradGame.dll"),
            OBFUSCATE("KradGame"),
            OBFUSCATE("EntityEdgeManager"),
            OBFUSCATE("PickupItemDistanceSqr")
        );

        if (pickupDistOffset && pickupDistSqrOffset) {
            float* dist = (float*)((uintptr_t)instance + pickupDistOffset);
            float* distSqr = (float*)((uintptr_t)instance + pickupDistSqrOffset);

            *dist = 999999.0f;
            *distSqr = 999999.0f;
        }
    }
    old_EntityEdgeManager_OnUpdate(instance);
}

void Hook_EntityEdgeManager_OnUpdate() {
    Tools::Hook(
        (void*)(uintptr_t)Il2CppGetMethodOffset(
            OBFUSCATE("KradGame.dll"),
            OBFUSCATE("KradGame"),
            OBFUSCATE("EntityEdgeManager"),
            OBFUSCATE("OnUpdate"),
            0
        ),
        (void*)EntityEdgeManager_OnUpdate,
        (void**)&old_EntityEdgeManager_OnUpdate
    );
}
void (*old_PickupItemSuccessHint)(void* instance, uint64_t itemUId, int result);

void PickupItemSuccessHint(void* instance, uint64_t itemUId, int result) {
    // paksa result jadi 0
    result = 0;

    // panggil original dengan result yang sudah diubah
    old_PickupItemSuccessHint(instance, itemUId, result);
}

void Hook_PickupItemSuccessHint() {
    Tools::Hook(
        (void*)(uintptr_t)Il2CppGetMethodOffset(
            OBFUSCATE("KradGame.dll"),
            OBFUSCATE("KradGame"),
            OBFUSCATE("InventoryService"),
            OBFUSCATE("PickupItemSuccessHint"),
            2 // overload index, sesuaikan jika ada lebih dari satu
        ),
        (void*)PickupItemSuccessHint,
        (void**)&old_PickupItemSuccessHint
    );
}
// pointer ke original
float (*orig_GetConsumableGroupCD)(void* instance, int itemID);

// hook function
float hook_GetConsumableGroupCD(void* instance, int itemID)
{
    // langsung override return value
    return 0.2f;
}

void InitCharacterLogicHooks()
{
    void* getCD = Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame.Logic"),
        OBFUSCATE("CharacterLogic"),
        OBFUSCATE("GetConsumableGroupCD"),
        1 // param count: int itemID
    );

    Tools::Hook(getCD, (void*)hook_GetConsumableGroupCD, (void**)&orig_GetConsumableGroupCD);
}
__attribute__((visibility("hidden")))
void EspPointers() {
Hook_FPS();
InitCharacterLogicHooks();
Hook_PickupItemSuccessHint();
Hook_EntityEdgeManager_OnUpdate();
InstallHook_DamageFunctions();
HookDurability();
InitSkillHook();
Hook_PresentInteractCharacter_CanOperationDisplay();
Hook_GameVarGetter_Getter();
Hook_CharacterMovementProxy_UpdateMovement();
InitPlayerDestroyHook();
InitNoCollisionHook();
// Tools::Hook(
    // (void*)Il2CppGetMethodOffset("Exported.dll", "proto", "GroupMemberInfo", "get_nickname", 0),
    // (void*)Hook_get_nickname,
    // (void**)&orig_get_nickname
// );
// Tools::Hook(
    // (void*)Il2CppGetMethodOffset("KradGame.dll", "KradGame", "AccountService", "get_NickName", 0),
    // (void*)Hook_get_NickName,
    // (void**)&orig_get_NickName
// );

Tools::Hook(
    (void*)Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame.Logic"),
        OBFUSCATE("CharacterLogic"),
        OBFUSCATE("GetMaxAirJumpCount"),
        1 // overload index: karena ada 1 argumen (bool)
    ),
    (void*)hk_GetMaxAirJumpCount,
    (void**)&old_GetMaxAirJumpCount
);
    
	Tools::Hook(
    (void*)Il2CppGetMethodOffset(
        OBFUSCATE("UnityEngine.CoreModule.dll"),
        OBFUSCATE("UnityEngine"),
        OBFUSCATE("Camera"),
        OBFUSCATE("set_fieldOfView"),
        1  
    ),
    (void*)hk_set_fieldOfView,
    (void**)&old_set_fieldOfView
);
	
	


    // ... pointer lain tetap

    get_IsVisible = (bool(*)(void*)) Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame"),  // Namespace
        OBFUSCATE("PEntity"), // Class
        OBFUSCATE("get_IsVisible"),
        0
    );

    // ... hook PlayerUpdate dan lain-lain tetap

	
    get_IsDead = (bool(*)(void*)) Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame"),
        OBFUSCATE("PresentCharacter"),
        OBFUSCATE("IsAliveEnemy"),
        0
    );
	
	
	Screen_get_width = (int (*)()) Il2CppGetMethodOffset(
        OBFUSCATE("UnityEngine.CoreModule.dll"),
        OBFUSCATE("UnityEngine"),
        OBFUSCATE("Screen"),
        OBFUSCATE("get_width"),
        0
    );

    Screen_get_height = (int (*)()) Il2CppGetMethodOffset(
        OBFUSCATE("UnityEngine.CoreModule.dll"),
        OBFUSCATE("UnityEngine"),
        OBFUSCATE("Screen"),
        OBFUSCATE("get_height"),
        0
    );

    get_transform = (void *(*)(void *)) Il2CppGetMethodOffset(
        OBFUSCATE("UnityEngine.CoreModule.dll"),
        OBFUSCATE("UnityEngine"),
        OBFUSCATE("Component"),
        OBFUSCATE("get_transform"),
        0
    );
    
    Transform_get_position = (Vector3 (*)(void *)) Il2CppGetMethodOffset(
        OBFUSCATE("UnityEngine.CoreModule.dll"),
        OBFUSCATE("UnityEngine"),
        OBFUSCATE("Transform"),
        OBFUSCATE("get_position"),
        0
    );
    
    
    
    get_main = (void *(*)()) Il2CppGetMethodOffset(
        OBFUSCATE("UnityEngine.CoreModule.dll"),
        OBFUSCATE("UnityEngine"),
        OBFUSCATE("Camera"),
        OBFUSCATE("get_main"),
        0
    );

    WorldToScreenPoint = (Vector3 (*)(void *, Vector3)) Il2CppGetMethodOffset(
        OBFUSCATE("UnityEngine.CoreModule.dll"),
        OBFUSCATE("UnityEngine"),
        OBFUSCATE("Camera"),
        OBFUSCATE("WorldToScreenPoint"),
        1
    );

	
	// Use Your Game Namespace , class name , Method name 
	Tools::Hook(
        (void *)(uintptr_t) Il2CppGetMethodOffset(
            OBFUSCATE("KradGame.dll"),
            OBFUSCATE("KradGame"), 
            OBFUSCATE("PresentCharacter"), 
            OBFUSCATE("OnUpdate"),
            2
        ),
        (void *)PlayerUpdate,
        (void **)&old_PlayerUpdate

    );
    
	// --- Get offset method Is1PView ---


// --- Wrapper biar gampang dipakai ---


InitChestEspHook();
InitTransforms();
InitOffsetsPresentCharacter();
InitMonsterEspHook();
InitOffsetsMonster();

    Tools::Hook(
        (void*)Il2CppGetMethodOffset("KradGame.dll", "KradGame", "AccountService", "get_PlayerLv", 0),
        (void*)Hook_get_PlayerLv,
        (void**)&orig_get_PlayerLv
    );
    
    // Hook_CampInfo();
    // Hook_CampFacilityInfo();
    // Hook_MatchmakingNewBieDesc();
    void* methodPtr = (void*)Il2CppGetMethodOffset(
        OBFUSCATE("KradGame.dll"),
        OBFUSCATE("KradGame"),
        OBFUSCATE("FocusAssistantService"),
        OBFUSCATE("GetAssistantFinalRotation"),
        4
    );
    if (methodPtr) {
        Tools::Hook(methodPtr, (void*)hk_GetAssistantFinalRotation, (void**)&orig_GetAssistantFinalRotation);
       
    }
 Install_HitPhysicsUtil_SingleLineHook();

InitPresentPickupItemHooks();


	}
