#pragma once
#include <cstdint>
#include "Tool/IL2CppSDKGenerator/Il2cpp.h"
#include "Includes/Macros.h"

#define TouchCount (uintptr_t) IL2Cpp::Il2CppGetMethodOffset("UnityEngine.InputLegacyModule.dll", "UnityEngine", "Input", "get_touchCount", 0)
#define TouchInput (uintptr_t) IL2Cpp::Il2CppGetMethodOffset("UnityEngine.InputLegacyModule.dll", "UnityEngine", "Input", "GetTouch", 1)

#pragma once

enum TouchPhase {
    Began = 0,
    Moved = 1,
    Stationary = 2,
    Ended = 3,
    Canceled = 4,
};

enum TouchType {
    Direct = 0,
    Indirect = 1,
    Stylus = 2,
};

struct Touch {
    int m_FingerId;
    Vector2 m_Position;
    Vector2 m_RawPosition;
    Vector2 m_PositionDelta;
    float m_TimeDelta;
    int m_TapCount;
    int m_Phase;
    int m_Type;
    float m_Pressure;
    float m_MaximumPossiblePressure;
    float m_Radius;
    float m_RadiusVariance;
    float m_AltitudeAngle;
    float m_AzimuthAngle;
};

auto _Input__get_touchCount = (int (*)()) (TouchCount);
auto _Input__GetTouch = (Touch (*)(void *, int)) (TouchInput);

int get_touchCount() {
    return _Input__get_touchCount();
}

Touch get_touch(int index) {
    return _Input__GetTouch(nullptr, index);
}

namespace Globals { extern int glHeight; }

void OnTouchEvent() {
    ImGuiIO& io = ImGui::GetIO();

    int count = get_touchCount();
    if (count <= 0) {
        io.MouseDown[0] = false;
        return;
    }

    for (int i = 0; i < count; i++) {
        Touch touch = get_touch(i);
        float x = touch.m_Position.x;
        float y = Globals::glHeight - touch.m_Position.y;

        switch (touch.m_Phase) {
            case TouchPhase::Began:
                io.MouseDown[0] = true;
                io.MousePos = ImVec2(x, y);
                break;

            case TouchPhase::Moved:
            case TouchPhase::Stationary:
                io.MouseDown[0] = true;
                io.MousePos = ImVec2(x, y);
                break;

            case TouchPhase::Ended:
            case TouchPhase::Canceled:
                io.MouseDown[0] = false;
                break;
        }
    }
}
