#pragma once

#include "Font.h"
#include "Themes.h"
#include "imgui.h"
#include "imgui_impl_android.h"
#include "imgui_impl_opengl3.h"
#include "imgui_internal.h"
#include "ImguiPP.h"
#include "stb_image.h"
#include "Icon.h"
#include "Iconcpp.h"


void ImGui_RunningText(const char* text, float speed, ImU32 textColor = 0)
{
    static float offset = 0.0f;
    static float textWidth = 0.0f;
    static bool initialized = false;

    if (!initialized)
    {
        ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[0]);
        textWidth = ImGui::CalcTextSize(text).x;
        ImGui::PopFont();
        initialized = true;
    }

    offset -= speed;

    if (offset < -textWidth)
    {
        offset = ImGui::GetWindowWidth();
    }

    ImGui::SetCursorPosX(offset);

    ImVec4 color;
    if (textColor == 0)
    {
        color = ImGui::ColorConvertU32ToFloat4(ImGui::GetColorU32(ImGuiCol_Text));
    }
    else
    {
        color = ImGui::ColorConvertU32ToFloat4(textColor);
    }

    ImGui::TextColored(color, "%s", text);
}

static void MetricsHelpMarker(const char* desc)
{
    ImGui::TextDisabled("(?)");
    if (ImGui::IsItemHovered(ImGuiHoveredFlags_DelayShort) && ImGui::BeginTooltip())
    {
        ImGui::PushTextWrapPos(ImGui::GetFontSize() * 35.0f);
        ImGui::TextUnformatted(desc);
        ImGui::PopTextWrapPos();
        ImGui::EndTooltip();
    }
}

const char* GetCurrentTime(bool date = false) {
    std::time_t currentTime = std::time(nullptr);
    std::tm* timeInfo = std::localtime(&currentTime);

    std::ostringstream oss;
    if (date) {
        oss << std::put_time(timeInfo, "%Y-%m-%d %H:%M:%S");
    } else {
        oss << std::put_time(timeInfo, "%H:%M:%S");
    }
    std::string timeString = oss.str();
    return strdup(timeString.c_str());
}

struct TextureInfo{
    ImTextureID textureId;
    int x;
    int y;
    int w;
    int h;
};

TextureInfo createTexture(char *ImagePath) {
    int w, h, n;
    stbi_uc *data = stbi_load(ImagePath, &w, &h, &n, 0);
    GLuint texture;
    TextureInfo textureInfo;
    glGenTextures(1, &texture);
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    if (n == 3) {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, w, h, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
    } else {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
    }
    stbi_image_free(data);
    textureInfo.textureId = (GLuint *) texture;
    textureInfo.w = w;
    textureInfo.h = h;
    return textureInfo;
}

void DrawImage(ImDrawList *draw, int x, int y, int w, int h, ImTextureID Texture)
{
    draw->AddImage(Texture, ImVec2(x, y), ImVec2(x + w, y + h));
}

long GetEpochTime()
{
    auto duration = std::chrono::system_clock::now().time_since_epoch();
    return std::chrono::duration_cast<std::chrono::milliseconds>(duration).count();
}

ImColor GetRainbowColor(float speed, float num1)
{
    speed = 0.002f * speed;
    long now = GetEpochTime();
    float hue = (now * (int)(num1 / speed)) * speed;
    return ImColor::HSV(hue, 1.0f, 1.0f);
}

ImColor SwitchColor(float speed,int num1)
{
    speed = 0.002f * speed;
	long now = GetEpochTime();
	float hue = (now % (int)(num1 / speed)) * speed;
	return ImColor::HSV(hue,1.0f, 1.0f);//57,98,100(yellow) 0,98,100(red)
}
